"""Synthetic meshes for tests."""
import math
from trimsnap.core.meshmodel import Mesh


def grid(nx, ny, size=1.0, plane="xy"):
    points = []
    for j in range(ny + 1):
        for i in range(nx + 1):
            x, y = i * size, j * size
            points.append((x, y, 0.0) if plane == "xy" else (x, 0.0, -y))
    faces = []
    for j in range(ny):
        for i in range(nx):
            a = j * (nx + 1) + i
            faces.append((a, a + 1, a + nx + 2, a + nx + 1))
    return Mesh("grid", points, faces)


def box(w=1.0, h=1.0, d=1.0):
    p = [(0, 0, 0), (w, 0, 0), (w, h, 0), (0, h, 0), (0, 0, d), (w, 0, d), (w, h, d), (0, h, d)]
    # outward-facing counter-clockwise faces
    f = [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4), (3, 7, 6, 2), (0, 4, 7, 3), (1, 2, 6, 5)]
    return Mesh("box", p, f)


def cylinder(n=8, rings=3, radius=1.0, height=2.0, caps=False):
    points, faces = [], []
    for r in range(rings + 1):
        for i in range(n):
            a = 2 * math.pi * i / n
            points.append((radius * math.cos(a), height * r / rings, radius * math.sin(a)))
    for r in range(rings):
        for i in range(n):
            a = r * n + i
            b = r * n + (i + 1) % n
            faces.append((a, a + n, b + n, b))
    return Mesh("cyl", points, faces)


def uv_sphere(n=8, rings=6, radius=1.0):
    points = [(0.0, radius, 0.0)]
    for r in range(1, rings):
        phi = math.pi * r / rings
        for i in range(n):
            a = 2 * math.pi * i / n
            points.append((radius * math.sin(phi) * math.cos(a), radius * math.cos(phi),
                           radius * math.sin(phi) * math.sin(a)))
    points.append((0.0, -radius, 0.0))
    faces = []
    for i in range(n):
        faces.append((0, 1 + (i + 1) % n, 1 + i))
    for r in range(rings - 2):
        for i in range(n):
            a = 1 + r * n + i
            b = 1 + r * n + (i + 1) % n
            faces.append((a, b, b + n, a + n))
    last = len(points) - 1
    base = 1 + (rings - 2) * n
    for i in range(n):
        faces.append((last, base + i, base + (i + 1) % n))
    return Mesh("sphere", points, faces)


def torus(major=8, minor=6, R=2.0, r=0.5):
    points, faces = [], []
    for i in range(major):
        a = 2 * math.pi * i / major
        for j in range(minor):
            b = 2 * math.pi * j / minor
            points.append(((R + r * math.cos(b)) * math.cos(a), r * math.sin(b),
                           (R + r * math.cos(b)) * math.sin(a)))
    for i in range(major):
        for j in range(minor):
            a = i * minor + j
            b = i * minor + (j + 1) % minor
            c = ((i + 1) % major) * minor + (j + 1) % minor
            d = ((i + 1) % major) * minor + j
            faces.append((a, d, c, b))
    return Mesh("torus", points, faces)


def with_uvs(mesh, values):
    """Copy of mesh whose corners carry the given {corner: (u, v)} (one id per corner)."""
    uu, vv, corner_uv = [], [], []
    for f, verts in enumerate(mesh.faces):
        ids = []
        for i in range(len(verts)):
            u, v = values[(f, i)]
            uu.append(u)
            vv.append(v)
            ids.append(len(uu) - 1)
        corner_uv.append(ids)
    return Mesh(mesh.name, mesh.points, mesh.faces, uu, vv, corner_uv)
