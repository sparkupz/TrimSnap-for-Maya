"""A small stateful stand-in for Maya, enough to run TrimSnap's Maya layer.

It models polygon meshes with UV sets, the active selection and the handful of
cmds / OpenMaya calls TrimSnap uses.  It checks *our* data flow (indices,
arrays, undo chunks, selection restore) - it cannot prove Maya's real behavior.
"""
import math
import re
import sys
import types

from trimsnap_path import setup  # noqa: F401  (adds scripts/ to sys.path)

SCENE = None


class FakeMeshData:
    def __init__(self, points, faces):
        self.points = [tuple(p) for p in points]
        self.faces = [tuple(f) for f in faces]
        self.sets = {"map1": ([], [], [0] * len(faces), [])}
        self.current = "map1"


class FakeScene:
    def __init__(self):
        self.meshes = {}          # shape long path -> FakeMeshData
        self.selection = []       # list of strings
        self.log = []
        self.undo_depth = 0
        self.unfold_calls = 0
        self.history_baked = 0

    def add_mesh(self, name, points, faces, uv=None):
        shape = f"|{name}|{name}Shape"
        data = FakeMeshData(points, faces)
        if uv is not None:                      # {(f, i): (u, v)} one id per corner
            u, v, counts, ids = [], [], [], []
            for f, verts in enumerate(faces):
                for i in range(len(verts)):
                    u.append(uv[(f, i)][0])
                    v.append(uv[(f, i)][1])
                    ids.append(len(u) - 1)
                counts.append(len(verts))
            data.sets["map1"] = (u, v, counts, ids)
        self.meshes[shape] = data
        return shape


def uv_ids_used(data, uvset, faces):
    _, _, counts, ids = data.sets[uvset]
    pos, used, offsets = 0, set(), []
    for c in counts:
        offsets.append(pos)
        pos += c
    for f in faces:
        used.update(ids[offsets[f]:offsets[f] + counts[f]])
    return used


def _ranges(ids):
    ids = sorted(ids)
    out, start, prev = [], None, None
    for i in ids:
        if start is None:
            start = prev = i
        elif i == prev + 1:
            prev = i
        else:
            out.append((start, prev))
            start = prev = i
    if start is not None:
        out.append((start, prev))
    return out


# ------------------------------------------------------------------ OpenMaya fakes
class FakeArray(list):
    pass


class MPoint:
    def __init__(self, x=0.0, y=0.0, z=0.0, w=1.0):
        self.x, self.y, self.z = x, y, z

    def __mul__(self, matrix):
        return MPoint(*matrix.apply((self.x, self.y, self.z)))


class MVector(MPoint):
    def __mul__(self, matrix):
        return MVector(*matrix.apply_direction((self.x, self.y, self.z)))


class MMatrix:
    def __init__(self, offset=(0.0, 0.0, 0.0)):
        self.offset = offset

    def apply(self, p):
        return (p[0] + self.offset[0], p[1] + self.offset[1], p[2] + self.offset[2])

    def apply_direction(self, p):
        return tuple(p)


class FakeDag:
    def __init__(self, path):
        self.path = path

    def apiType(self):
        return om.MFn.kMesh if self.path.endswith("Shape") else om.MFn.kTransform

    def extendToShape(self):
        if self.path.endswith("Shape"):
            return
        name = self.path.split("|")[-1]
        candidate = f"{self.path}|{name}Shape"
        if candidate not in SCENE.meshes:
            raise RuntimeError("no shape")
        self.path = candidate

    def fullPathName(self):
        return self.path

    def inclusiveMatrix(self):
        return MMatrix()

    def inclusiveMatrixInverse(self):
        return MMatrix()


class FakeComp:
    def __init__(self, api, elements=(), complete=False):
        self.api, self.elements, self.complete = api, list(elements), complete

    def isNull(self):
        return self.api is None

    def apiType(self):
        return self.api


class MFnSingleIndexedComponent:
    def __init__(self, comp):
        self.comp = comp
        self.isComplete = comp.complete

    def getElements(self):
        return FakeArray(self.comp.elements)


class MFnDoubleIndexedComponent(MFnSingleIndexedComponent):
    def getElements(self):
        return FakeArray([0]), FakeArray(self.comp.elements)


class MSelectionList:
    def __init__(self):
        self.items = []

    def add(self, path):
        if path not in SCENE.meshes and not any(k.startswith(path + "|") for k in SCENE.meshes):
            raise RuntimeError("not found")
        self.items.append(path)

    def getDagPath(self, i):
        return FakeDag(self.items[i])

    def length(self):
        return len(self.items)


class FakeActiveSelection:
    def length(self):
        return len(SCENE.selection)

    def getComponent(self, i):
        text = SCENE.selection[i]
        match = re.match(r"^(.*)\.(f|e|vtx|map)\[(\d+)(?::(\d+))?\]$", text)
        if not match:
            return FakeDag(text), FakeComp(None)
        path, kind, a, b = match.groups()
        elements = range(int(a), int(b or a) + 1)
        api = {"f": om.MFn.kMeshPolygonComponent, "e": om.MFn.kMeshEdgeComponent,
               "vtx": om.MFn.kMeshVertComponent, "map": om.MFn.kMeshMapComponent}[kind]
        return FakeDag(path), FakeComp(api, elements)


class MFnMesh:
    def __init__(self, dag):
        self.data = SCENE.meshes[dag.path]

    def currentUVSetName(self):
        return self.data.current

    def getPoints(self, space):
        return [MPoint(*p) for p in self.data.points]

    def getVertices(self):
        counts = FakeArray(len(f) for f in self.data.faces)
        ids = FakeArray(v for f in self.data.faces for v in f)
        return counts, ids

    def getUVs(self, uvset=None):
        if uvset not in self.data.sets:
            raise RuntimeError("no such uv set")
        u, v, _, _ = self.data.sets[uvset]
        return FakeArray(u), FakeArray(v)

    def getAssignedUVs(self, uvset=None):
        if uvset not in self.data.sets:
            raise RuntimeError("no such uv set")
        _, _, counts, ids = self.data.sets[uvset]
        return FakeArray(counts), FakeArray(ids)

    def clearUVs(self, uvset=None):
        self.data.sets[uvset] = ([], [], [0] * len(self.data.faces), [])

    def setUVs(self, u, v, uvset=None):
        _, _, counts, ids = self.data.sets[uvset]
        self.data.sets[uvset] = (list(u), list(v), counts, ids)

    def assignUVs(self, counts, ids, uvset=None):
        u, v, _, _ = self.data.sets[uvset]
        counts, ids = list(counts), list(ids)
        assert sum(counts) == len(ids), "counts/ids mismatch"
        assert all(0 <= i < len(u) for i in ids), "uv id out of range"
        self.data.sets[uvset] = (u, v, counts, ids)

    def updateSurface(self):
        pass

    def getEdgeVertices(self, edge):
        raise NotImplementedError


class MFnDagNode:
    def __init__(self, dag):
        self.isIntermediateObject = False


class MFnCamera:
    def __init__(self, dag):
        self.isOrtho = False
        self.orthoWidth = 10.0

    def horizontalFieldOfView(self):
        return 1.2

    def verticalFieldOfView(self):
        return 0.9


class FakeView:
    def getCamera(self):
        return FakeDag("|persp|perspShape")

    def portWidth(self):
        return 1600

    def portHeight(self):
        return 900


class MFn:
    kMesh, kTransform = 1, 2
    kMeshPolygonComponent, kMeshEdgeComponent, kMeshVertComponent = 10, 11, 12
    kMeshMapComponent, kMeshVtxFaceComponent = 13, 14


# ------------------------------------------------------------------ cmds fake
class Cmds(types.ModuleType):
    def __init__(self):
        super().__init__("maya.cmds")

    # selection
    def ls(self, *args, **kw):
        if kw.get("selection"):
            return list(SCENE.selection)
        if kw.get("type") == "mesh":
            return list(SCENE.meshes)
        if args:
            return [a for a in args]
        return []

    def select(self, items=None, replace=True, clear=False, **kw):
        if clear:
            SCENE.selection = []
        else:
            SCENE.selection = [items] if isinstance(items, str) else list(items)

    def filterExpand(self, *args, **kw):
        return []

    def polyListComponentConversion(self, comps, toUV=False, **kw):
        assert toUV
        out = []
        for text in comps:
            path, kind, a, b = re.match(r"^(.*)\.(f)\[(\d+)(?::(\d+))?\]$", text).groups()
            data = SCENE.meshes[path]
            ids = uv_ids_used(data, data.current, range(int(a), int(b or a) + 1))
            out += [f"{path}.map[{lo}:{hi}]" if lo != hi else f"{path}.map[{lo}]"
                    for lo, hi in _ranges(ids)]
        return out

    def undoInfo(self, openChunk=False, closeChunk=False, **kw):
        SCENE.undo_depth += 1 if openChunk else -1 if closeChunk else 0
        assert SCENE.undo_depth >= 0

    def loadPlugin(self, *a, **k):
        return []

    def upAxis(self, q=False, axis=False):
        return "y"

    def bakePartialHistory(self, path, **kw):
        SCENE.history_baked += 1

    def listConnections(self, *a, **k):
        return []

    def deformableShape(self, *a, **k):
        return []

    # uv sets
    def polyUVSet(self, path, **kw):
        data = SCENE.meshes[path]
        if kw.get("query"):
            if kw.get("allUVSets"):
                return list(data.sets)
            if kw.get("currentUVSet"):
                return [data.current]
        elif kw.get("create"):
            data.sets[kw["uvSet"]] = ([], [], [0] * len(data.faces), [])
            data.current = kw["uvSet"]
        elif kw.get("delete"):
            assert data.current != kw["uvSet"], "cannot delete the current set"
            del data.sets[kw["uvSet"]]
        elif kw.get("currentUVSet"):
            assert kw["uvSet"] in data.sets
            data.current = kw["uvSet"]

    def u3dUnfold(self, **kw):
        """Fake Unfold3D: lay every selected UV shell out planarly (isometric for flat shells)."""
        from trimsnap.core import cuts
        from trimsnap.core.meshmodel import Mesh, uv_shells
        SCENE.unfold_calls += 1
        by_path = {}
        for text in SCENE.selection:
            path, a, b = re.match(r"^(.*)\.map\[(\d+)(?::(\d+))?\]$", text).groups()
            by_path.setdefault(path, set()).update(range(int(a), int(b or a) + 1))
        for path, selected in by_path.items():
            data = SCENE.meshes[path]
            u, v, counts, ids = data.sets[data.current]
            mesh = Mesh(path, data.points, data.faces, u, v,
                        [list(ids[sum(counts[:f]):sum(counts[:f]) + counts[f]]) for f in range(len(counts))])
            shells, _ = uv_shells(mesh)
            groups = []
            for shell in shells:
                if not any(i in selected for f in shell for i in mesh.corner_uv[f]):
                    continue
                values = cuts.planar_layout(mesh, [shell])
                groups.append({k: (x * 3.0, y * 3.0) for k, (x, y) in values.items()})
            from trimsnap.core.uvwrite import build_uv_arrays
            nu, nv, ncounts, nids = build_uv_arrays(mesh, groups)
            data.sets[data.current] = (nu, nv, ncounts, nids)

    # unused-but-called helpers
    def polyMapCut(self, edges):
        SCENE.log.append(("cut", edges))

    def polyMapSew(self, edges):
        SCENE.log.append(("sew", edges))

    def listRelatives(self, node, parent=False, **kw):
        return [node.rsplit("|", 1)[0] or node]

    def getPanel(self, **kw):
        return []


class FakeMayaNamespace:
    pass


def install(scene):
    """Register fake `maya` modules in sys.modules and return the Cmds fake."""
    global SCENE, om
    SCENE = scene
    for name in [m for m in sys.modules if m == "maya" or m.startswith("maya.") or m.startswith("trimsnap")]:
        del sys.modules[name]

    om = types.ModuleType("maya.api.OpenMaya")
    om.MFn = MFn
    om.MSpace = types.SimpleNamespace(kWorld=0, kObject=1)
    om.MPoint, om.MVector, om.MMatrix = MPoint, MVector, MMatrix
    om.MFloatArray = om.MIntArray = FakeArray
    om.MDagPath = lambda dag: FakeDag(dag.path)
    om.MFnDagNode, om.MFnMesh, om.MFnCamera = MFnDagNode, MFnMesh, MFnCamera
    om.MFnSingleIndexedComponent = MFnSingleIndexedComponent
    om.MFnDoubleIndexedComponent = MFnDoubleIndexedComponent
    om.MSelectionList = MSelectionList
    om.MGlobal = types.SimpleNamespace(getActiveSelectionList=lambda: FakeActiveSelection(),
                                       displayInfo=lambda m: None, displayWarning=lambda m: None,
                                       displayError=lambda m: None)

    class MPxCommand:
        pass
    om.MPxCommand = MPxCommand
    om.MSyntax = types.SimpleNamespace(kString=1)

    omui = types.ModuleType("maya.api.OpenMayaUI")
    omui.M3dView = types.SimpleNamespace(active3dView=lambda: FakeView())

    cmds = Cmds()
    maya = types.ModuleType("maya")
    api = types.ModuleType("maya.api")
    maya.cmds, maya.api = cmds, api
    api.OpenMaya, api.OpenMayaUI = om, omui
    sys.modules.update({"maya": maya, "maya.cmds": cmds, "maya.api": api,
                        "maya.api.OpenMaya": om, "maya.api.OpenMayaUI": omui})
    return cmds
