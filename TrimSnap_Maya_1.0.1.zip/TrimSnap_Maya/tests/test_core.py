import json
import math
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
sys.path.insert(0, os.path.dirname(__file__))

import meshes  # noqa: E402
from trimsnap.core import automation, cuts, hotspot, specs, texel, trimpreset, unwrap  # noqa: E402
from trimsnap.core.meshmodel import Mesh, uv_shells, shells_with_seeds, corner_faces_edge_border  # noqa: E402


def planar_values(mesh):
    """Each face gets its own identical-scale planar UVs (one chart per face, spread out)."""
    return cuts.planar_layout(mesh, [[f] for f in range(len(mesh.faces))])


class TexelTests(unittest.TestCase):
    def test_density_unit_square(self):
        # 100 cm square mapped to the whole UV square = 1024 px per metre on a 1024 map.
        self.assertAlmostEqual(texel.density(100 * 100, 1.0, 1024, "M"), 1024.0)
        self.assertAlmostEqual(texel.density(100 * 100, 1.0, 1024, "CM"), 10.24)
        self.assertAlmostEqual(texel.density(100 * 100, 1.0, 2048, "IN"), 2048 / 100 * 2.54)

    def test_shell_scaling_hits_target(self):
        g = meshes.grid(2, 2, size=50.0)
        uv = {(f, i): ((g.points[g.faces[f][i]][0]) / 100.0 * 0.25,
                       (g.points[g.faces[f][i]][1]) / 100.0 * 0.25)
              for f in range(4) for i in range(4)}
        m = meshes.with_uvs(g, uv)
        shells, _ = uv_shells(m)
        # whole grid shares no UV ids here, so every face is its own shell
        self.assertEqual(len(shells), 4)
        data, skipped = texel.measure_shells(m, shells, 1024, "M")
        self.assertEqual(skipped, 0)
        d = data[0][1]
        self.assertAlmostEqual(d, 1024 * 0.25 * 1.0)  # 0.25 uv per 100 cm
        scaled = texel.scale_shell(m, data[0][0], 2.0)
        m2 = meshes.with_uvs(g, {**m.uv_values(range(4)), **scaled})
        d2, _ = texel.measure_shells(m2, [data[0][0]], 1024, "M")
        self.assertAlmostEqual(d2[0][1], 2 * d)

    def test_average_vs_individual(self):
        self.assertEqual(texel.target_factors([100, 300], 200, "AVERAGE"), [1.0, 1.0])
        self.assertEqual(texel.target_factors([100, 400], 200, "INDIVIDUAL"), [2.0, 0.5])


class ShellTests(unittest.TestCase):
    def test_shells_follow_uv_ids(self):
        g = meshes.grid(2, 1)
        # shared uv ids between the two faces along their common edge -> one shell
        m = Mesh("g", g.points, g.faces, [0, 1, 1, 0, 2, 2], [0, 0, 1, 1, 0, 1],
                 [[0, 1, 2, 3], [1, 4, 5, 2]])
        shells, invalid = uv_shells(m)
        self.assertEqual((len(shells), invalid), (1, []))
        self.assertEqual(corner_faces_edge_border(m, [0, 1]), set())
        m2 = Mesh("g", g.points, g.faces, [0] * 8, [0] * 8, [[0, 1, 2, 3], [4, 5, 6, 7]])
        shells, _ = uv_shells(m2)
        self.assertEqual(len(shells), 2)
        self.assertEqual(corner_faces_edge_border(m2, [0, 1]), {(1, 4)})
        chosen, missing = shells_with_seeds(m2, {1})
        self.assertEqual((chosen, missing), ([[1]], 0))

    def test_missing_uvs_reported(self):
        g = meshes.grid(1, 1)
        shells, invalid = uv_shells(g)
        self.assertEqual((shells, invalid), ([], [0]))


class HotspotTests(unittest.TestCase):
    TRIMS = [
        {"position": [0.0, 0.5], "scale": [1.0, 0.1], "behavior": "HORIZONTAL_TILING"},
        {"position": [0.0, 0.7], "scale": [1.0, 0.25], "behavior": "HORIZONTAL_TILING"},
        {"position": [0.1, 0.1], "scale": [0.2, 0.2], "behavior": "FIXED"},
        {"position": [0.5, 0.1], "scale": [0.4, 0.1], "behavior": "FIXED"},
    ]

    def test_matching(self):
        preset = {"trims": self.TRIMS + [{"position": [0, 0], "scale": [0, 1], "behavior": "FIXED"}]}
        self.assertEqual(len(hotspot.matching_trims(preset, "FIXED")), 2)
        self.assertEqual(len(hotspot.matching_trims(preset, "HORIZONTAL_TILING")), 2)

    def test_horizontal_picks_closest_height_and_keeps_shape(self):
        coords = [(0.0, 0.0), (0.4, 0.0), (0.4, 0.2), (0.0, 0.2)]
        out = hotspot.transform(coords, self.TRIMS[:2], "HORIZONTAL_TILING")
        vs = [p[1] for p in out]
        self.assertAlmostEqual(max(vs) - min(vs), 0.25)       # closest height 0.25
        us = [p[0] for p in out]
        self.assertAlmostEqual(max(us) - min(us), 0.5)        # uniform scale 1.25
        self.assertAlmostEqual((max(vs) + min(vs)) / 2, 0.7 + 0.125)

    def test_fixed_matches_aspect_then_stretches(self):
        coords = [(0.0, 0.0), (0.8, 0.0), (0.8, 0.2), (0.0, 0.2)]   # 4:1
        out = hotspot.transform(coords, self.TRIMS[2:], "FIXED")
        us = [p[0] for p in out]
        vs = [p[1] for p in out]
        self.assertAlmostEqual(max(us) - min(us), 0.4)
        self.assertAlmostEqual(max(vs) - min(vs), 0.1)

    def test_inset_cannot_collapse(self):
        coords = [(0, 0), (1, 0), (1, 1), (0, 1)]
        out = hotspot.transform(coords, self.TRIMS[2:3], "FIXED", inset=-5.0)
        us = [p[0] for p in out]
        self.assertGreater(max(us) - min(us), 0.0)

    def test_random_is_stable_and_seeded(self):
        coords = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
        a = hotspot.random_flip(coords, 7, "k", True, True)
        b = hotspot.random_flip(coords, 7, "k", True, True)
        self.assertEqual(a, b)
        flips = {hotspot.random_flip([(0.0, 0.0), (1.0, 1.0)], s, "k", True, False)[0][0]
                 for s in range(40)}
        self.assertEqual(flips, {0.0, 1.0})
        off = hotspot.random_axis_offset(coords, 3, "k", "HORIZONTAL_TILING", 0.5)
        self.assertTrue(all(o[1] == c[1] for o, c in zip(off, coords)))
        self.assertTrue(all(abs(o[0] - c[0]) <= 0.5 for o, c in zip(off, coords)))
        self.assertEqual(hotspot.random_axis_offset(coords, 3, "k", "FIXED", 0.5), coords)

    def test_plan_shell(self):
        g = meshes.grid(1, 1)
        m = meshes.with_uvs(g, {(0, 0): (0, 0), (0, 1): (.5, 0), (0, 2): (.5, .5), (0, 3): (0, .5)})
        plan = hotspot.plan_shell(m, [0], self.TRIMS[2:], "FIXED", {}, seed=1)
        self.assertEqual(set(plan), {(0, 0), (0, 1), (0, 2), (0, 3)})


class CutTests(unittest.TestCase):
    def assert_all_disks(self, mesh, faces, cut):
        charts = cuts.split_charts(mesh, faces, cut)
        for chart in charts:
            chi, loops, genus = cuts.chart_topology(mesh, chart, cut)
            self.assertEqual((chi, loops, genus), (1, 1, 0), f"chart not a disk: {chi},{loops},{genus}")
        return charts

    def test_grid_is_already_disk(self):
        g = meshes.grid(4, 3)
        faces = list(range(len(g.faces)))
        cut, charts = cuts.plan_cuts(g, faces, math.pi)
        self.assertEqual((cut, len(charts)), (set(), 1))

    def test_cylinder_gets_one_seam(self):
        c = meshes.cylinder(8, 3)
        faces = list(range(len(c.faces)))
        cut, charts = cuts.plan_cuts(c, faces, math.pi)
        self.assertEqual(len(charts), 1)
        self.assert_all_disks(c, faces, cut)
        self.assertEqual(len(cut), 3)           # one seam edge per ring row

    def test_closed_sphere_becomes_disk(self):
        s = meshes.uv_sphere(8, 6)
        faces = list(range(len(s.faces)))
        cut, charts = cuts.plan_cuts(s, faces, math.pi)
        self.assertTrue(cut)
        self.assertEqual(len(charts), 1)
        self.assert_all_disks(s, faces, cut)

    def test_torus_becomes_disk(self):
        t = meshes.torus(8, 6)
        faces = list(range(len(t.faces)))
        cut, charts = cuts.plan_cuts(t, faces, math.pi)
        self.assertEqual(len(charts), 1)
        self.assert_all_disks(t, faces, cut)

    def test_box_angle_cuts(self):
        b = meshes.box()
        faces = list(range(6))
        cut, charts = cuts.plan_cuts(b, faces, math.radians(60))
        self.assertEqual((len(cut), len(charts)), (12, 6))
        cut, charts = cuts.plan_cuts(b, faces, math.pi)    # no angle cuts: cube must still open up
        self.assertEqual(len(charts), 1)
        self.assert_all_disks(b, faces, cut)

    def test_existing_borders_are_respected(self):
        g = meshes.grid(4, 1)
        faces = list(range(4))
        border = {g.face_edge_keys(1)[1]}        # edge between face 1 and 2
        cut, charts = cuts.plan_cuts(g, faces, math.pi, border)
        self.assertEqual(len(charts), 2)

    def test_partial_selection_is_chart_boundary(self):
        g = meshes.grid(4, 1)
        cut, charts = cuts.plan_cuts(g, [0, 1], math.pi)
        self.assertEqual(len(charts), 1)

    def test_planar_layout_covers_all_corners(self):
        s = meshes.uv_sphere(6, 4)
        faces = list(range(len(s.faces)))
        cut, charts = cuts.plan_cuts(s, faces, math.radians(60))
        values = cuts.planar_layout(s, charts)
        self.assertEqual(len(values), sum(len(f) for f in s.faces))


class UnwrapTests(unittest.TestCase):
    def two_quad_values(self, rotate_second=0.0, scale_second=1.0):
        g = meshes.grid(2, 1)
        a, b = g.faces
        pos = {v: (g.points[v][0], g.points[v][1]) for v in range(6)}
        values = {(0, i): pos[v] for i, v in enumerate(a)}
        c, s = math.cos(rotate_second), math.sin(rotate_second)
        for i, v in enumerate(b):
            x, y = pos[v][0] - 1.0, pos[v][1]
            values[(1, i)] = (5 + scale_second * (c * x - s * y), 5 + scale_second * (s * x + c * y))
        return g, values

    def test_stitch_joins_rotated_neighbor(self):
        g, values = self.two_quad_values(rotate_second=math.radians(90))
        charts = unwrap.result_charts(g, [0, 1], values)
        self.assertEqual(len(charts), 2)
        joined = unwrap.stitch(g, charts)
        self.assertEqual(len(joined), 1)
        # the joined chart keeps the original planar layout up to a rigid motion
        ch = joined[0]
        self.assertAlmostEqual(unwrap.signed_uv_area(g, ch), 2.0)
        self.assertEqual(len(unwrap.result_charts(g, [0, 1], unwrap.flatten(joined))), 1)

    def test_stitch_translation_only_rejects_rotation(self):
        g, values = self.two_quad_values(rotate_second=math.radians(90))
        charts = unwrap.result_charts(g, [0, 1], values)
        self.assertEqual(len(unwrap.stitch(g, charts, translation_only=True)), 2)
        g, values = self.two_quad_values(rotate_second=0.0)
        charts = unwrap.result_charts(g, [0, 1], values)
        self.assertEqual(len(unwrap.stitch(g, charts, translation_only=True)), 1)

    def test_stitch_rejects_protected_scaled_and_overlapping(self):
        g, values = self.two_quad_values()
        charts = unwrap.result_charts(g, [0, 1], values)
        self.assertEqual(len(unwrap.stitch(g, charts, protected={g.face_edge_keys(0)[1]})), 2)
        g, values = self.two_quad_values(scale_second=2.0)
        charts = unwrap.result_charts(g, [0, 1], values)
        self.assertEqual(len(unwrap.stitch(g, charts)), 2)

    def test_concave_only(self):
        # an L-shaped folded strip: floor + wall meeting at a concave (inside) corner
        points = [(0, 0, 0), (1, 0, 0), (1, 0, -1), (0, 0, -1), (0, 1, 0), (1, 1, 0)]
        floor = (0, 1, 2, 3)       # normal +y (viewed from above, counter-clockwise)
        wall = (0, 4, 5, 1)        # normal +z : faces into the room -> concave edge (0,1)
        m = Mesh("L", points, [floor, wall])
        angle = unwrap.signed_dihedral(m, (0, 1))
        self.assertIsNotNone(angle)
        self.assertLess(angle, 0)
        # a wall going down from the same edge (box corner) is convex
        convex = Mesh("L2", points + [(0, -1, 0), (1, -1, 0)], [floor, (1, 0, 6, 7)])
        self.assertGreater(unwrap.signed_dihedral(convex, (0, 1)), 0)
        # a flat continuation has no angle
        flat = meshes.grid(2, 1)
        self.assertAlmostEqual(unwrap.signed_dihedral(flat, (1, 4)), 0.0)

    def test_fix_winding_mirrors_flipped_chart(self):
        g = meshes.grid(1, 1)
        values = {(0, 0): (1, 0), (0, 1): (0, 0), (0, 2): (0, 1), (0, 3): (1, 1)}  # mirrored
        charts = unwrap.result_charts(g, [0], values)
        self.assertLess(unwrap.signed_uv_area(g, charts[0]), 0)
        unwrap.fix_winding(g, charts)
        self.assertGreater(unwrap.signed_uv_area(g, charts[0]), 0)

    def test_orient_world_points_up_to_plus_v(self):
        # vertical wall in the XY plane; world up is +Y
        g = meshes.grid(2, 2)
        angle = math.radians(37)
        c, s = math.cos(angle), math.sin(angle)
        values = {}
        for f, face in enumerate(g.faces):
            for i, v in enumerate(face):
                x, y = g.points[v][0], g.points[v][1]
                values[(f, i)] = (c * x - s * y, s * x + c * y)
        charts = unwrap.result_charts(g, list(range(4)), values)
        unwrap.orient_world(g, charts)
        ch = charts[0]
        for f, face in enumerate(g.faces):
            for i, v in enumerate(face):
                for j, w in enumerate(face):
                    dy = g.points[w][1] - g.points[v][1]
                    dv = ch[(f, j)][1] - ch[(f, i)][1]
                    self.assertAlmostEqual(dy, dv, places=6)

    def test_orient_floor_uses_flat_reference(self):
        g = meshes.grid(2, 2, plane="xz")   # points (x, 0, -y): floor
        values = {(f, i): (g.points[v][0], -g.points[v][2]) for f, face in enumerate(g.faces)
                  for i, v in enumerate(face)}
        charts = unwrap.result_charts(g, list(range(4)), values)
        unwrap._rotate_chart(charts[0], 1.0)
        unwrap.orient_world(g, charts, flat_up=(0, 0, -1))
        ch = charts[0]
        # world -Z must map onto +V
        for f, face in enumerate(g.faces):
            for i, v in enumerate(face):
                for j, w in enumerate(face):
                    self.assertAlmostEqual(-(g.points[w][2] - g.points[v][2]),
                                           ch[(f, j)][1] - ch[(f, i)][1], places=6)

    def test_longest_edge(self):
        g = meshes.grid(3, 1)      # 3 wide, 1 high: longest edge is horizontal
        values = {(f, i): (g.points[v][0], g.points[v][1]) for f, face in enumerate(g.faces)
                  for i, v in enumerate(face)}
        charts = unwrap.result_charts(g, [0, 1, 2], values)
        unwrap._rotate_chart(charts[0], 0.7)
        unwrap.orient_longest_edge(g, charts, vertical=True)
        xs = [p[0] for p in charts[0].values()]
        ys = [p[1] for p in charts[0].values()]
        self.assertAlmostEqual(max(xs) - min(xs), 1.0, places=6)
        self.assertAlmostEqual(max(ys) - min(ys), 3.0, places=6)

    def test_pack_fits_unit_square(self):
        s = meshes.box()
        faces = list(range(6))
        cut, charts_faces = cuts.plan_cuts(s, faces, math.radians(60))
        values = cuts.planar_layout(s, charts_faces)
        charts = unwrap.finish_auto(s, faces, values, set(), False, (0, 1, 0), (0, 0, -1))
        # unit squares fold out rigidly, so the cube may legitimately end up as one cross
        self.assertGreaterEqual(len(charts), 1)
        flat = unwrap.flatten(charts)
        self.assertEqual(len(flat), 24)
        us = [p[0] for p in flat.values()]
        vs = [p[1] for p in flat.values()]
        self.assertGreaterEqual(min(us + vs), 0.0)
        self.assertLessEqual(max(us + vs), 1.0)

    def test_world_scale_gives_uniform_density(self):
        # a 1x1 chart and a 3x3 chart: after rescale both have the same density
        big = meshes.grid(1, 1, size=3.0)
        small = meshes.grid(1, 1, size=1.0)
        points = big.points + [(x + 10, y, z) for x, y, z in small.points]
        faces = [big.faces[0], tuple(v + 4 for v in small.faces[0])]
        m = Mesh("two", points, faces)
        values = {(0, i): (0.1 * i, 0.2) for i in range(4)}
        values = {(0, 0): (0, 0), (0, 1): (1, 0), (0, 2): (1, 1), (0, 3): (0, 1),
                  (1, 0): (3, 0), (1, 1): (4, 0), (1, 2): (4, 1), (1, 3): (3, 1)}
        charts = unwrap.result_charts(m, [0, 1], values)
        unwrap.world_rescale(m, charts)
        d = [math.sqrt(abs(unwrap.signed_uv_area(m, c)) / m.world_area({k[0] for k in c})) for c in charts]
        self.assertAlmostEqual(d[0], d[1])

    def test_finish_trim_orients_and_packs(self):
        b = meshes.box(2, 1, 1)
        faces = list(range(6))
        cut, charts_faces = cuts.plan_cuts(b, faces, math.radians(60))
        values = cuts.planar_layout(b, charts_faces)
        charts = unwrap.finish_trim(b, faces, values, set(), "LONGEST_HORIZONTAL", True,
                                    (0, 1, 0), (0, 0, -1))
        self.assertGreaterEqual(len(charts), 1)
        flat = unwrap.flatten(charts)
        self.assertEqual(len(flat), 24)
        for u, v in flat.values():
            self.assertTrue(0.0 <= u <= 1.0 and 0.0 <= v <= 1.0)


class UVWriteTests(unittest.TestCase):
    def test_merges_within_group_only(self):
        from trimsnap.core.uvwrite import build_uv_arrays
        g = meshes.grid(2, 1)
        m = Mesh("g", g.points, g.faces, [0.9], [0.9], [[0, 0, 0, 0], [-1] * 4])
        # shared mesh vertices 1 and 4 get identical UVs in one group -> shared index
        group = {(0, 0): (0, 0), (0, 1): (1, 0), (0, 2): (1, 1), (0, 3): (0, 1),
                 (1, 0): (1, 0), (1, 1): (2, 0), (1, 2): (2, 1), (1, 3): (1, 1)}
        u, v, counts, ids = build_uv_arrays(m, [group])
        self.assertEqual(counts, [4, 4])
        self.assertEqual(len(u), 6)
        self.assertEqual(ids[1], ids[4])       # vertex 1: face0 corner1 == face1 corner0
        self.assertEqual(ids[2], ids[7])       # vertex 4
        # split the same data into two groups -> no merging across them
        a = {k: x for k, x in group.items() if k[0] == 0}
        b = {k: x for k, x in group.items() if k[0] == 1}
        u, v, counts, ids = build_uv_arrays(m, [a, b])
        self.assertEqual(len(u), 8)
        self.assertNotEqual(ids[1], ids[4])

    def test_untouched_faces_keep_ids_and_missing_become_empty(self):
        from trimsnap.core.uvwrite import build_uv_arrays
        g = meshes.grid(3, 1)
        m = Mesh("g", g.points, g.faces, [0.1, 0.2, 0.3, 0.4], [0.5] * 4,
                 [[0, 1, 2, 3], [-1, -1, -1, -1], [3, 2, 1, 0]])
        u, v, counts, ids = build_uv_arrays(m, [])
        self.assertEqual(counts, [4, 0, 4])
        self.assertEqual(u, [0.1, 0.2, 0.3, 0.4])
        self.assertEqual(ids, [0, 1, 2, 3, 3, 2, 1, 0])
        u, v, counts, ids = build_uv_arrays(m, [{(1, i): (0.5, 0.5 + i) for i in range(4)}])
        self.assertEqual(counts, [4, 4, 4])
        self.assertEqual(len(u), 8)


class TrimPresetTests(unittest.TestCase):
    def plane(self):
        # 2x2 plane in XZ (Maya default: normal +Y), uneven columns
        xs = [0.0, 1.0, 2.0]
        zs = [0.0, 1.0, 2.0]
        pts = [(x, 0.0, z) for z in zs for x in xs]
        faces = [(0, 1, 4, 3), (1, 2, 5, 4), (3, 4, 7, 6), (4, 5, 8, 7)]
        return pts, faces

    def test_capture_orders_top_left_first(self):
        pts, faces = self.plane()
        cap = trimpreset.capture_plane("pPlane1", pts, faces, lambda v: (v[0] * 2, v[1] * 2, v[2] * 2))
        self.assertEqual(len(cap["trims"]), 4)
        first = cap["trims"][0]
        self.assertEqual(first["name"], "Trim 1")
        self.assertAlmostEqual(first["position"][1], 0.5)   # top row first
        self.assertAlmostEqual(first["position"][0], 0.0)
        self.assertEqual(cap["plane_dimensions"], [4.0, 4.0])
        self.assertAlmostEqual(first["dimensions"][0], 2.0)

    def test_rejects_non_planar(self):
        pts, faces = self.plane()
        pts[4] = (1.0, 0.5, 1.0)
        with self.assertRaises(ValueError):
            trimpreset.capture_plane("p", pts, faces)

    def test_storage_roundtrip_and_edit(self):
        pts, faces = self.plane()
        cap = trimpreset.capture_plane("pPlane1", pts, faces)
        with tempfile.TemporaryDirectory() as d:
            data = trimpreset.save_new(d, "Sheet A", False, cap)
            with self.assertRaises(ValueError):
                trimpreset.save_new(d, "sheet a", False, cap)
            presets, paths, errors = trimpreset.load_all(d)
            self.assertEqual((len(presets), errors), (1, []))
            updated = trimpreset.update_trims(d, data["id"], {0: ([0.0, 0.5], [0.25, 0.25], "HORIZONTAL_TILING")})
            self.assertEqual(updated["trims"][0]["behavior"], "HORIZONTAL_TILING")
            self.assertAlmostEqual(updated["trims"][0]["scale"][0], 0.25)
            xs = [v[0] for v in updated["trims"][0]["vertices"]]
            self.assertAlmostEqual(max(xs) - min(xs), 0.25)
            with self.assertRaises(ValueError):
                trimpreset.update_trims(d, data["id"], {0: ([0.9, 0.9], [0.5, 0.5], None)})
            trimpreset.delete(d, data["id"])
            self.assertEqual(trimpreset.load_all(d)[0], [])

    def test_name_errors(self):
        self.assertTrue(trimpreset.name_error(""))
        self.assertTrue(trimpreset.name_error("a/b"))
        self.assertTrue(trimpreset.name_error("CON"))
        self.assertEqual(trimpreset.name_error("Fine Name"), "")

    def test_geometry_centroid(self):
        pts, center = trimpreset.trim_geometry({"position": [0, 0], "scale": [0.5, 0.25]})
        self.assertEqual(len(pts), 4)
        self.assertAlmostEqual(center[0], 0.25)
        self.assertAlmostEqual(center[1], 0.125)


class AutomationTests(unittest.TestCase):
    def blocks(self):
        return [{"uv_map": "map1", "steps": [
            {"action": "UNMARK_SEAM", "settings": automation.default_settings("UNMARK_SEAM")},
            {"action": "AUTO_UNWRAP", "settings": automation.default_settings("AUTO_UNWRAP")},
            {"action": "SET_TD", "settings": dict(automation.default_settings("SET_TD"), density=512.0)},
            {"action": "HOTSPOT_FIXED", "settings": automation.default_settings("HOTSPOT_FIXED")},
        ]}]

    def test_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            data = automation.save(d, "My Flow", self.blocks())
            presets, paths, errors = automation.load_all(d)
            self.assertEqual((len(presets), errors), (1, []))
            self.assertEqual(presets[0]["uv_blocks"][0]["steps"][2]["settings"]["density"], 512.0)
            blocks = automation.to_blocks(presets[0])
            self.assertEqual(blocks[0]["steps"][1]["action"], "AUTO_UNWRAP")
            # rename + edit in place keeps the id
            blocks[0]["steps"].pop(0)
            again = automation.save(d, "Renamed", blocks, existing_id=data["id"])
            self.assertEqual(again["id"], data["id"])
            self.assertEqual([p["name"] for p in automation.load_all(d)[0]], ["Renamed"])
            with self.assertRaises(ValueError):
                automation.save(d, "bad/name", blocks)
            automation.delete(d, data["id"])
            self.assertEqual(automation.load_all(d)[0], [])

    def test_rejects_unknown_and_bad_values(self):
        with self.assertRaises(ValueError):
            automation.normalize_settings("AUTO_UNWRAP", {"angle_threshold": 99}, "map1")
        with self.assertRaises(ValueError):
            automation.normalize_settings("AUTO_UNWRAP", {"bogus": 1}, "map1")
        with self.assertRaises(ValueError):
            automation.normalize_settings("SET_TD", {"density": float("nan")}, "map1")
        data = {"schema_version": 1, "id": "x", "enum_id": 1, "name": "n",
                "execution": automation.EXECUTION,
                "uv_blocks": [{"uv_map": "a", "steps": [{"action": "AUTO_UNWRAP", "code": "x"}]}]}
        with self.assertRaises(ValueError):
            automation.validate(data)

    def test_loads_blender_edition_presets(self):
        blender_style = {
            "schema_version": 1, "id": "bc6b8e029bab4ff88d3addffa2b02a1a", "enum_id": 1013681668,
            "name": "2UV", "execution": dict(automation.EXECUTION),
            "uv_blocks": [{"uv_map": "UVMap.001", "steps": [
                {"action": "PROJECT_FROM_VIEW", "label": "Project From View",
                 "settings": {"orthographic": False, "camera_bounds": True, "correct_aspect": True,
                              "clip_to_bounds": False, "scale_to_bounds": False}},
                {"action": "UNWRAP_FOR_TRIM", "label": "x",
                 "settings": {"angle_threshold": 1.0471975803375244, "orientation": "LONGEST_HORIZONTAL",
                              "stitch_concave_face_pairs": True, "respect_existing_seams": True}},
                {"action": "SELECT_TRIM_PRESET", "label": "x",
                 "settings": {"trim_preset": {"id": "01bf", "name": "Trim_A"}}},
                {"action": "HOTSPOT_HORIZONTAL", "label": "x",
                 "settings": {"island_scale_multiplier": 1.0, "island_offset": 0.0,
                              "allow_horizontal_flip": True, "allow_vertical_flip": True,
                              "random_seed": -1, "axis_offset_randomization": 2.0,
                              "use_active_trim_preset": True}}]}]}
        automation.validate(json.loads(json.dumps(blender_style)))

    def test_specs_check(self):
        self.assertTrue(specs.check_value("angle_threshold", 1.0))
        self.assertFalse(specs.check_value("angle_threshold", -1.0))
        self.assertFalse(specs.check_value("allow_vertical_flip", 1))
        self.assertEqual(specs.coerce("trim_number", "x"), 1)
        self.assertEqual(specs.coerce("trim_number", "4"), 4)


if __name__ == "__main__":
    unittest.main()
