"""Runs TrimSnap's Maya layer against the stateful fake in fakemaya.py."""
import importlib
import math
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import fakemaya  # noqa: E402
import meshes  # noqa: E402


class MayaLayerCase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        os.environ["TRIMSNAP_USER_DIR"] = self.tmp.name
        self.scene = fakemaya.FakeScene()
        self.cmds = fakemaya.install(self.scene)
        for name in ("maya_io", "commands", "state", "ops", "uvsets", "runner", "visualize"):
            pass
        self.mio = importlib.import_module("trimsnap.maya_io")
        self.ops = importlib.import_module("trimsnap.ops")
        self.state = importlib.import_module("trimsnap.state")
        self.uvsets = importlib.import_module("trimsnap.uvsets")
        self.runner = importlib.import_module("trimsnap.runner")
        self.state.settings.values["bake_history"] = True

    def tearDown(self):
        self.tmp.cleanup()

    # helpers ------------------------------------------------------------
    def add_box(self, name="box", size=100.0, with_uv=True):
        b = meshes.box(size, size, size)
        uv = None
        if with_uv:
            from trimsnap.core import cuts
            values = cuts.planar_layout(b, [[f] for f in range(6)])
            uv = {k: (u * 0.2, v * 0.2) for k, (u, v) in values.items()}
        return self.scene.add_mesh(name, b.points, b.faces, uv)

    def mesh(self, shape, uvset=None):
        return self.mio.read_mesh(shape, uvset)

    def all_uvs_inside(self, mesh):
        for f in range(len(mesh.faces)):
            for i in range(len(mesh.faces[f])):
                uv = mesh.uv((f, i))
                self.assertIsNotNone(uv, f"corner {(f, i)} lost its UV")
                self.assertTrue(-1e-6 <= uv[0] <= 1 + 1e-6 and -1e-6 <= uv[1] <= 1 + 1e-6, uv)


class SelectionTests(MayaLayerCase):
    def test_object_and_face_selection(self):
        shape = self.add_box()
        self.scene.selection = ["|box"]
        targets = self.mio.selected_targets()
        self.assertEqual([t.path for t in targets], [shape])
        mesh = self.mesh(shape)
        self.assertEqual(targets[0].seed_faces(mesh), set(range(6)))
        self.scene.selection = [shape + ".f[1:2]", shape + ".f[4]"]
        targets = self.mio.selected_targets()
        self.assertEqual(targets[0].seed_faces(mesh), {1, 2, 4})

    def test_uv_selection_loose_and_strict(self):
        shape = self.add_box()
        mesh = self.mesh(shape)
        # uv ids 0-3 belong to face 0, 4-7 to face 1 ...; pick 3 of face 0's 4 and all of face 1
        self.scene.selection = [shape + ".map[0:2]", shape + ".map[4:7]"]
        target = self.mio.selected_targets()[0]
        self.assertEqual(target.seed_faces(mesh, strict=True), {1})
        self.assertEqual(target.seed_faces(mesh, strict=False), {0, 1})

    def test_face_components_compress(self):
        self.assertEqual(self.mio.face_components("s", [0, 1, 2, 5, 7, 8]), ["s.f[0:2]", "s.f[5]", "s.f[7:8]"])

    def test_read_mesh_matches_scene(self):
        shape = self.add_box()
        mesh = self.mesh(shape)
        self.assertEqual(len(mesh.faces), 6)
        self.assertEqual(len(mesh.uv_u), 24)
        self.assertTrue(all(mesh.has_uvs(f) for f in range(6)))


class TexelTests(MayaLayerCase):
    def test_get_and_set_td(self):
        shape = self.add_box()
        self.scene.selection = ["|box"]
        st = self.state.settings
        st.values.update(units="M", texture_size="1024", mode="INDIVIDUAL", density=512.0)
        result = self.ops.get_td()
        self.assertEqual(result.level, "info")
        # each face: 100cm square mapped to 0.2 uv -> 0.2*1024 px per metre
        self.assertAlmostEqual(st.density, 0.2 * 1024, places=3)
        st.values["density"] = 512.0
        self.ops.set_td()
        mesh = self.mesh(shape)
        from trimsnap.core import texel
        from trimsnap.core.meshmodel import uv_shells
        shells, _ = uv_shells(mesh)
        self.assertEqual(len(shells), 6)
        for faces, density in texel.measure_shells(mesh, shells, 1024, "M")[0]:
            self.assertAlmostEqual(density, 512.0, places=3)
        self.assertEqual(self.scene.undo_depth, 0)

    def test_set_td_only_touches_selected_shells(self):
        shape = self.add_box()
        before = self.mesh(shape)
        self.scene.selection = [shape + ".f[0]"]
        self.state.settings.values.update(density=100.0, mode="INDIVIDUAL")
        self.ops.set_td()
        after = self.mesh(shape)
        for f in range(1, 6):
            for i in range(4):
                self.assertEqual(before.uv((f, i)), after.uv((f, i)))
        self.assertNotEqual(before.uv((0, 0)), after.uv((0, 0)))

    def test_missing_uvs_is_reported(self):
        self.add_box(with_uv=False)
        self.scene.selection = ["|box"]
        with self.assertRaises(self.mio.MayaToolError):
            self.ops.get_td()


class HotspotTests(MayaLayerCase):
    PRESET = {"id": "p1", "name": "Sheet", "trims": [
        {"position": [0.0, 0.5], "scale": [1.0, 0.25], "behavior": "HORIZONTAL_TILING"},
        {"position": [0.1, 0.1], "scale": [0.2, 0.2], "behavior": "FIXED"}]}

    def test_fixed_and_horizontal(self):
        shape = self.add_box()
        self.scene.selection = ["|box"]
        self.state.library.trims = [self.PRESET]
        self.state.settings.values["trim_preset"] = "p1"
        self.ops.hotspot("FIXED")
        mesh = self.mesh(shape)
        for f in range(6):
            for i in range(4):
                u, v = mesh.uv((f, i))
                self.assertTrue(0.1 - 1e-6 <= u <= 0.3 + 1e-6 and 0.1 - 1e-6 <= v <= 0.3 + 1e-6)
        self.ops.hotspot("HORIZONTAL_TILING")
        mesh = self.mesh(shape)
        vs = [mesh.uv((0, i))[1] for i in range(4)]
        self.assertAlmostEqual(max(vs) - min(vs), 0.25)

    def test_explicit_trim_and_errors(self):
        shape = self.add_box()
        self.scene.selection = [shape + ".f[2]"]
        self.state.library.trims = [self.PRESET]
        self.state.settings.values["trim_preset"] = "p1"
        self.ops.hotspot("FIXED", trim_index=1)
        mesh = self.mesh(shape)
        us = [mesh.uv((2, i))[0] for i in range(4)]
        self.assertAlmostEqual(max(us) - min(us), 0.2)
        with self.assertRaises(self.mio.MayaToolError):
            self.ops.hotspot("FIXED", trim_index=9)
        self.state.settings.values["trim_preset"] = "NONE"
        with self.assertRaises(self.mio.MayaToolError):
            self.ops.hotspot("FIXED")


class UnwrapTests(MayaLayerCase):
    def test_auto_unwrap_box(self):
        shape = self.add_box()
        self.scene.selection = ["|box"]
        result = self.ops.auto_unwrap()
        self.assertTrue(result.message.startswith("Unwrapped into"))
        self.assertEqual(self.scene.unfold_calls, 1)
        self.assertGreater(self.scene.history_baked, 0)
        self.assertEqual(self.scene.undo_depth, 0)
        self.assertEqual(self.scene.selection, ["|box"])          # selection restored
        mesh = self.mesh(shape)
        self.all_uvs_inside(mesh)
        # no overlap check here; just that world density is uniform
        from trimsnap.core import texel
        from trimsnap.core.meshmodel import uv_shells
        shells, _ = uv_shells(mesh)
        densities = [d for _, d in texel.measure_shells(mesh, shells, 1024, "M")[0]]
        self.assertAlmostEqual(min(densities), max(densities), places=3)

    def test_unwrap_for_trim_with_options(self):
        shape = self.add_box()
        self.scene.selection = ["|box"]
        options = self.state.settings.operator_options("UNWRAP_FOR_TRIM")
        options.update(orientation="LONGEST_HORIZONTAL", stitch_concave_face_pairs=True)
        self.ops.unwrap_for_trim(options=options)
        self.all_uvs_inside(self.mesh(shape))

    def test_cylinder_and_two_meshes_pack_together(self):
        c = meshes.cylinder(8, 3, radius=40, height=100)
        shape_c = self.scene.add_mesh("cyl", c.points, c.faces)
        shape_b = self.add_box("box")
        self.scene.selection = ["|cyl", "|box"]
        self.ops.auto_unwrap()
        for shape in (shape_c, shape_b):
            self.all_uvs_inside(self.mesh(shape))

    def test_partial_face_selection_leaves_rest_alone(self):
        shape = self.add_box()
        before = self.mesh(shape)
        self.scene.selection = [shape + ".f[0:1]"]
        self.ops.auto_unwrap()
        after = self.mesh(shape)
        for f in range(2, 6):
            for i in range(4):
                self.assertEqual(before.uv((f, i)), after.uv((f, i)))

    def test_requires_selection(self):
        self.add_box()
        self.scene.selection = []
        with self.assertRaises(self.mio.MayaToolError):
            self.ops.auto_unwrap()

    def test_project_from_view(self):
        b = meshes.grid(2, 2, size=50.0)
        points = [(x - 50, y - 50, z - 400) for x, y, z in b.points]
        shape = self.scene.add_mesh("wall", points, b.faces)
        self.scene.selection = ["|wall"]
        self.ops.project_from_view()
        mesh = self.mesh(shape)
        shells_count = len(__import__("trimsnap.core.meshmodel", fromlist=["x"]).uv_shells(mesh)[0])
        self.assertEqual(shells_count, 1)                       # connected projection
        us = [mesh.uv((f, i))[0] for f in range(4) for i in range(4)]
        self.assertTrue(all(0.0 <= u <= 1.0 for u in us))

    def test_seam_marking_uses_polymap_commands(self):
        shape = self.add_box()
        self.ops.mark_seam(True, [self.mio.Target.everything(shape)])
        self.ops.mark_seam(False, [self.mio.Target.everything(shape)])
        self.assertEqual([entry[0] for entry in self.scene.log], ["cut", "sew"])


class UVSetTests(MayaLayerCase):
    def test_resolve_names(self):
        r = self.uvsets.resolve_name
        self.assertEqual(r(["map1"], "UVMap"), "map1")
        self.assertEqual(r(["map1"], "UVMap.001"), "UVMap_001")
        self.assertEqual(r(["UVMap"], "UVMap"), "UVMap")
        self.assertEqual(r(["map1", "map2"], "map2"), "map2")
        self.assertEqual(self.uvsets.next_free_name({"map1", "map2"}), "map3")

    def test_add_copy_sync_remove(self):
        shape = self.add_box()
        other = self.scene.add_mesh("second", *[(meshes.box().points), meshes.box().faces])
        self.scene.selection = ["|box"]
        name = self.uvsets.add_set([shape])
        self.assertEqual(name, "map2")
        a, b = self.mesh(shape, "map1"), self.mesh(shape, "map2")
        self.assertEqual(a.uv_u, b.uv_u)
        self.assertEqual(self.uvsets.current_name([shape]), "map2")
        self.uvsets.sync([shape, other], "map2")
        self.assertEqual(self.uvsets.count_with([shape, other], "map2"), 2)
        self.uvsets.remove_set([shape, other], "map2")
        self.assertEqual(self.uvsets.names_of(shape), ["map1"])
        self.assertEqual(self.uvsets.names_of(other), ["map1"])


class RunnerTests(MayaLayerCase):
    def write_trim_preset(self):
        import json
        self.state.trim_dir().mkdir(parents=True, exist_ok=True)
        data = dict(HotspotTests.PRESET, schema_version=1, enum_id=1)
        (self.state.trim_dir() / "Sheet.json").write_text(json.dumps(data), encoding="utf-8")

    def preset(self):
        from trimsnap.core import automation as auto
        steps_a = [{"action": a, "settings": auto.default_settings(a)}
                   for a in ("PROJECT_FROM_VIEW", "AUTO_UNWRAP")]
        steps_a.append({"action": "SET_TD", "settings": dict(auto.default_settings("SET_TD"), density=256.0,
                                                             mode="INDIVIDUAL")})
        steps_b = [{"action": "UNWRAP_FOR_TRIM", "settings": auto.default_settings("UNWRAP_FOR_TRIM")},
                   {"action": "SELECT_TRIM_PRESET",
                    "settings": {"trim_preset": "p1"}},
                   {"action": "HOTSPOT_FIXED", "settings": auto.default_settings("HOTSPOT_FIXED")}]
        return auto.build("Two UV", [{"uv_map": "UVMap", "steps": steps_a},
                                     {"uv_map": "UVMap.001", "steps": steps_b}],
                          "a" * 32, 5, [{"id": "p1", "name": "Sheet"}])

    def test_full_run(self):
        shape = self.add_box()
        # put the box in front of the fake camera for Project From View
        data = self.scene.meshes[shape]
        data.points = [(x - 50, y - 50, z - 400) for x, y, z in data.points]
        self.scene.selection = ["|box"]
        self.write_trim_preset()
        count = self.runner.run(self.preset())
        self.assertEqual(count, 6)
        self.assertEqual(self.scene.undo_depth, 0)
        self.assertEqual(self.scene.selection, ["|box"])
        self.assertEqual(sorted(data.sets), ["UVMap_001", "map1"])
        self.assertEqual(data.current, "UVMap_001")
        mesh = self.mesh(shape, "UVMap_001")
        for f in range(6):
            for i in range(4):
                u, v = mesh.uv((f, i))
                self.assertTrue(0.1 - 1e-6 <= u <= 0.3 + 1e-6 and 0.1 - 1e-6 <= v <= 0.3 + 1e-6)
        first = self.mesh(shape, "map1")
        self.all_uvs_inside(first)

    def test_preflight_errors_before_any_change(self):
        shape = self.add_box()
        self.scene.selection = ["|box"]
        self.state.library.trims = []
        before = list(self.scene.meshes[shape].sets["map1"][0])
        with self.assertRaises(self.runner.RunError) as ctx:
            self.runner.run(self.preset())
        self.assertFalse(ctx.exception.partial)
        self.assertEqual(self.scene.meshes[shape].sets["map1"][0], before)
        self.assertEqual(self.scene.undo_depth, 0)

    def test_requires_a_selection(self):
        self.add_box()
        self.scene.selection = []
        with self.assertRaises(self.runner.RunError):
            self.runner.run(self.preset())

    def test_partial_failure_closes_undo_chunk(self):
        shape = self.add_box()
        self.scene.selection = ["|box"]
        self.state.library.trims = [HotspotTests.PRESET]
        from trimsnap.core import automation as auto
        data = auto.build("X", [{"uv_map": "map1", "steps": [
            {"action": "AUTO_UNWRAP", "settings": auto.default_settings("AUTO_UNWRAP")}]}],
            "b" * 32, 6)
        original = self.cmds.u3dUnfold

        def boom(**kw):
            raise RuntimeError("unfold exploded")
        self.cmds.u3dUnfold = boom
        try:
            with self.assertRaises(self.runner.RunError) as ctx:
                self.runner.run(data)
        finally:
            self.cmds.u3dUnfold = original
        self.assertTrue(ctx.exception.partial)
        self.assertEqual(self.scene.undo_depth, 0)
        self.assertEqual(self.scene.selection, ["|box"])


class StateTests(MayaLayerCase):
    def test_default_presets_install_and_settings_roundtrip(self):
        lib = self.state.library
        lib.reload()
        self.assertGreaterEqual(len(lib.trims), 1)
        self.assertGreaterEqual(len(lib.autos), 1)
        self.assertEqual(lib.trim_errors + lib.auto_errors, [])
        s = self.state.settings
        s.set("density", 777.0)
        s.set_operator_options("AUTO_UNWRAP", {"angle_threshold": 1.0, "prioritize_world_orientation": True,
                                               "respect_existing_seams": False, "mark_resulting_seams": True})
        again = self.state.Settings()
        again.load()
        self.assertEqual(again.density, 777.0)
        self.assertEqual(again.operator_options("AUTO_UNWRAP")["angle_threshold"], 1.0)
        self.assertEqual(again.operator_options("HOTSPOT_FIXED")["island_offset"], 0.0)


if __name__ == "__main__":
    unittest.main()
