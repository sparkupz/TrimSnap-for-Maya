# TrimSnap for Maya 1.0.0

Blender 애드온 TrimSnap과 같은 워크플로를 Maya에서 쓰기 위해 처음부터 새로 작성한 플러그인입니다.
(Blender 코드나 에셋은 사용하지 않았습니다.)

## 설치
1. 압축을 풀고 `install.py`를 Maya 뷰포트에 드래그 앤 드롭합니다.
2. 플러그인이 로드되고 자동 로드가 설정되며 메뉴 **TrimSnap**이 생깁니다.
   (수동 설치: 폴더를 Maya 모듈 경로에 두면 `TrimSnap.mod`가 인식됩니다.)
3. Maya 2022 이상(Python 3, PySide2/6) 기준입니다.

## 기능
- **Texel Density**: Get / Set (월드 스케일 기준, 셸 단위)
- **Hotspot**: Horizontal / Vertical Tiling, Fixed, 특정 Trim 번호 지정, 랜덤 플립/오프셋
- **Auto Unwrap / Unwrap for Trim**: 각도 컷 + 트리/코트리 컷으로 모든 차트를 디스크로 만든 뒤 Unfold3D로 펼치고, 월드 방향 정렬·스티치·패킹 후처리
- **Mark / Unmark Seam**, **Project from View**
- **UV Set** 추가/삭제/동기화/선택
- **UV Checker / Custom Debug 텍스처** 토글 (원래 셰이더 할당 자동 백업·복원)
- **Trim Preset** 만들기(평면 메쉬 선택 → 캡처), UV 에디터에 Trim 윤곽 오버레이
- **Automation Preset**: 여러 단계를 JSON 프리셋으로 만들어 한 번에 실행 (Undo 한 번으로 되돌림). 프리셋 JSON 스키마는 Blender 버전과 호환되도록 맞췄습니다.

실행: 메뉴 **TrimSnap > Open TrimSnap** (도킹 가능한 패널).
프리셋 저장 위치는 사용자 폴더이며 환경변수 `TRIMSNAP_USER_DIR`로 바꿀 수 있습니다.
기본 프리셋(Trim: Trim_A, OBJM_A / Automation: 2UV - OBJM_Hotspot, 2UV - Trim_A_Horizontal)이 처음 실행 시 복사됩니다.

## Blender 버전과의 차이
- Ministry of Flat 대신 Maya 내장 **Unfold3D**(`u3dUnfold`)를 사용합니다.
- UV 셸은 Maya 방식(공유 UV id)으로 정의됩니다.
- UV 에디터 오버레이는 실험 기능이라 기본으로 꺼져 있습니다(UV 에디터가 열려 있을 때 일부 Maya에서 불안정할 수 있음). 패널의 "Overlay (exp.)" 버튼으로만 켜집니다.
- Seam은 Maya의 하드 엣지가 아닌 TrimSnap 내부 컷 데이터로 처리됩니다.

## 한계 / 테스트 상태
- 핵심 알고리즘(`scripts/trimsnap/core`)과 가짜 Maya 환경 기반 흐름 테스트(총 64개)는 통과했습니다: `python3 -m unittest discover -s tests`
- **실제 Maya에서는 실행해보지 못했습니다.** Maya API 호출, `u3dUnfold` 플래그, PySide UI, 오버레이는 검증되지 않았으므로 오류가 나면 Script Editor 메시지를 알려주세요.
