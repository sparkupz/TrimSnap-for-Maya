"""UV checker / custom debug texture toggle with exact restore of the old shading."""
import json
from pathlib import Path

import maya.cmds as cmds

from . import maya_io as mio, state

MODES = {"CHECKER": ("TrimSnapChecker", "UV Checkers Texture"),
         "CUSTOM": ("TrimSnapCustomDebug", "Custom Debug Texture")}
BACKUP_ATTR = "trimsnapOriginalShading"
MODE_ATTR = "trimsnapDebugMode"

_PLACE2D = ["coverage", "translateFrame", "rotateFrame", "mirrorU", "mirrorV", "stagger", "wrapU",
            "wrapV", "repeatUV", "offset", "rotateUV", "noiseUV", "vertexUvOne", "vertexUvTwo",
            "vertexUvThree", "vertexCameraOne"]
_viewport_state = {}


# ---------------------------------------------------------------- material
def _image_for(mode):
    if mode == "CHECKER":
        path = state.CHECKER_TEXTURE
    else:
        value = state.settings.custom_debug_path.strip()
        if not value:
            raise mio.MayaToolError("Choose a custom debug image first")
        path = Path(value)
    if not path.is_file():
        raise mio.MayaToolError(f"Debug texture not found: {path}")
    return str(path).replace("\\", "/")


def debug_shading_group(mode):
    """Create (or update) the debug lambert + file texture and return its shading group."""
    base, _ = MODES[mode]
    image = _image_for(mode)
    material, group = base + "_MAT", base + "_SG"
    file_node, place = base + "_FILE", base + "_PLACE2D"
    if not cmds.objExists(material):
        cmds.shadingNode("lambert", asShader=True, name=material)
    if not cmds.objExists(group):
        cmds.sets(renderable=True, noSurfaceShader=True, empty=True, name=group)
        cmds.connectAttr(material + ".outColor", group + ".surfaceShader", force=True)
    if not cmds.objExists(file_node):
        cmds.shadingNode("file", asTexture=True, isColorManaged=True, name=file_node)
        cmds.shadingNode("place2dTexture", asUtility=True, name=place)
        cmds.connectAttr(place + ".outUV", file_node + ".uvCoord", force=True)
        cmds.connectAttr(place + ".outUvFilterSize", file_node + ".uvFilterSize", force=True)
        for name in _PLACE2D:
            cmds.connectAttr(f"{place}.{name}", f"{file_node}.{name}", force=True)
        cmds.connectAttr(file_node + ".outColor", material + ".color", force=True)
    cmds.setAttr(file_node + ".fileTextureName", image, type="string")
    return group


# ---------------------------------------------------------------- state per mesh
def mode_of(path):
    if cmds.attributeQuery(MODE_ATTR, node=path, exists=True):
        return cmds.getAttr(f"{path}.{MODE_ATTR}")
    return None


def _members_for(path):
    """{shading group: [member strings]} for the faces/object of this shape."""
    shape_long = cmds.ls(path, long=True)[0]
    transform = (cmds.listRelatives(shape_long, parent=True, fullPath=True) or [shape_long])[0]
    result = {}
    for group in dict.fromkeys(cmds.listConnections(shape_long, type="shadingEngine") or []):
        mine = []
        for member in cmds.sets(group, query=True) or []:
            node = member.split(".")[0]
            longs = cmds.ls(node, long=True) or []
            if longs and longs[0] in (shape_long, transform):
                mine.append(member)
        if mine:
            result[group] = mine
    return result


def _set_attr_string(path, name, value):
    if not cmds.attributeQuery(name, node=path, exists=True):
        cmds.addAttr(path, longName=name, dataType="string")
    cmds.setAttr(f"{path}.{name}", value, type="string")


def link_current_uv_set(path):
    """Make this mesh's debug texture follow its current UV set (best effort).

    Maya textures are not tied to the current set by themselves, so without a
    link the viewport can show another set (e.g. the first one).
    """
    mode = mode_of(path)
    if mode is None:
        return
    file_node = MODES[mode][0] + "_FILE"
    if not cmds.objExists(file_node):
        return
    try:
        shape = cmds.ls(path, long=True)[0]
        current = cmds.polyUVSet(shape, query=True, currentUVSet=True)[0]
        names = cmds.polyUVSet(shape, query=True, allUVSets=True) or []
        indices = cmds.polyUVSet(shape, query=True, allUVSetsIndices=True) or []
        if current not in names or len(indices) != len(names):
            return
        target = "%s.uvSet[%d].uvSetName" % (shape, indices[names.index(current)])
        for link in cmds.uvLink(query=True, texture=file_node) or []:
            if link.startswith(shape + ".") and link != target:
                cmds.uvLink(uvSet=link, texture=file_node, **{"break": True})
        cmds.uvLink(uvSet=target, texture=file_node, make=True)
    except (RuntimeError, AttributeError, TypeError, IndexError, ValueError):
        pass


def enable(path, mode):
    group = debug_shading_group(mode)
    if mode_of(path) is None:
        _set_attr_string(path, BACKUP_ATTR, json.dumps(_members_for(path)))
    _set_attr_string(path, MODE_ATTR, mode)
    cmds.sets(path, edit=True, forceElement=group)
    link_current_uv_set(path)


def disable(path):
    if mode_of(path) is None:
        return
    try:
        backup = json.loads(cmds.getAttr(f"{path}.{BACKUP_ATTR}"))
    except (ValueError, TypeError):
        backup = {}
    restored = False
    for group, members in backup.items():
        if cmds.objExists(group):
            existing = [m for m in members if cmds.objExists(m.split(".")[0])]
            if existing:
                cmds.sets(existing, edit=True, forceElement=group)
                restored = True
    if not restored:
        cmds.sets(path, edit=True, forceElement="initialShadingGroup")
    for name in (BACKUP_ATTR, MODE_ATTR):
        if cmds.attributeQuery(name, node=path, exists=True):
            cmds.deleteAttr(f"{path}.{name}")


def any_enabled():
    for shape in cmds.ls(type="mesh", long=True) or []:
        if mode_of(shape) is not None:
            return True
    return False


# ---------------------------------------------------------------- viewport textures
def _show_textures():
    for panel in cmds.getPanel(type="modelPanel") or []:
        if panel in _viewport_state:
            continue
        try:
            _viewport_state[panel] = (cmds.modelEditor(panel, query=True, displayTextures=True),
                                      cmds.modelEditor(panel, query=True, displayAppearance=True))
            cmds.modelEditor(panel, edit=True, displayTextures=True)
            if _viewport_state[panel][1] in ("wireframe", "boundingBox"):
                cmds.modelEditor(panel, edit=True, displayAppearance="smoothShaded")
        except RuntimeError:
            _viewport_state.pop(panel, None)


def _restore_viewports():
    for panel, (textures, appearance) in list(_viewport_state.items()):
        try:
            if cmds.modelEditor(panel, exists=True):
                cmds.modelEditor(panel, edit=True, displayTextures=textures, displayAppearance=appearance)
        except RuntimeError:
            pass
    _viewport_state.clear()


# ---------------------------------------------------------------- toggle
def selected_paths():
    return mio.selected_mesh_paths()


def is_active(mode):
    paths = selected_paths()
    return bool(paths) and all(mode_of(p) == mode for p in paths)


def toggle(mode, paths=None):
    paths = selected_paths() if paths is None else paths
    if not paths:
        raise mio.MayaToolError("Select a mesh first")
    turn_off = all(mode_of(p) == mode for p in paths)
    cmds.undoInfo(openChunk=True, chunkName="TrimSnap " + MODES[mode][1])
    try:
        if turn_off:
            for path in paths:
                disable(path)
            if not any_enabled():
                _restore_viewports()
        else:
            _image_for(mode)
            for path in paths:
                enable(path, mode)
            _show_textures()
    finally:
        cmds.undoInfo(closeChunk=True)
    return not turn_off
