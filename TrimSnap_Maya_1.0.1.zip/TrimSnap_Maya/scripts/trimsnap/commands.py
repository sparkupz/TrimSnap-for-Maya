"""Undoable UV write command (``trimSnapSetUV``) built on OpenMaya 2.0.

Python code cannot hand arrays to an MPxCommand through flags, so payloads are
parked in ``PAYLOADS`` under a token that is passed instead.  Redo/undo simply
re-apply the stored arrays, which keeps every UV edit in Maya's undo queue.
"""
import itertools

import maya.api.OpenMaya as om
import maya.cmds as cmds

COMMAND_NAME = "trimSnapSetUV"
PAYLOADS = {}
_tokens = itertools.count(1)


def _dag(path):
    sel = om.MSelectionList()
    sel.add(path)
    return sel.getDagPath(0)


def capture(path, uv_set):
    """Current UV arrays of a mesh set as plain lists: (u, v, counts, ids)."""
    fn = om.MFnMesh(_dag(path))
    try:
        u, v = fn.getUVs(uv_set)
        counts, ids = fn.getAssignedUVs(uv_set)
    except RuntimeError:
        return [], [], [], []
    return list(u), list(v), list(counts), list(ids)


def apply_arrays(path, uv_set, data):
    u, v, counts, ids = data
    fn = om.MFnMesh(_dag(path))
    fn.clearUVs(uv_set)
    fn.setUVs(om.MFloatArray(u), om.MFloatArray(v), uv_set)
    fn.assignUVs(om.MIntArray(counts), om.MIntArray(ids), uv_set)
    fn.updateSurface()


class SetUVCommand(om.MPxCommand):
    def __init__(self):
        om.MPxCommand.__init__(self)
        self._path = None
        self._uv_set = None
        self._old = None
        self._new = None

    @staticmethod
    def creator():
        return SetUVCommand()

    @staticmethod
    def newSyntax():
        syntax = om.MSyntax()
        syntax.addFlag("-m", "-mesh", om.MSyntax.kString)
        syntax.addFlag("-t", "-token", om.MSyntax.kString)
        syntax.addFlag("-s", "-uvSet", om.MSyntax.kString)
        return syntax

    def doIt(self, args):
        parser = om.MArgParser(self.syntax(), args)
        self._path = parser.flagArgumentString("-m", 0)
        self._uv_set = parser.flagArgumentString("-s", 0)
        token = parser.flagArgumentString("-t", 0)
        self._new = PAYLOADS.pop(token, None)
        if self._new is None:
            raise RuntimeError("trimSnapSetUV: unknown payload token")
        self._old = capture(self._path, self._uv_set)
        self.redoIt()

    def redoIt(self):
        apply_arrays(self._path, self._uv_set, self._new)

    def undoIt(self):
        apply_arrays(self._path, self._uv_set, self._old)

    def isUndoable(self):
        return True


def register(plugin_fn):
    plugin_fn.registerCommand(COMMAND_NAME, SetUVCommand.creator, SetUVCommand.newSyntax)


def deregister(plugin_fn):
    plugin_fn.deregisterCommand(COMMAND_NAME)


def write_uvs(path, uv_set, u, v, counts, ids):
    """Write UV arrays (undoable when the TrimSnap plug-in is loaded)."""
    if hasattr(cmds, COMMAND_NAME):
        token = f"t{next(_tokens)}"
        PAYLOADS[token] = (list(u), list(v), list(counts), list(ids))
        try:
            getattr(cmds, COMMAND_NAME)(m=path, t=token, s=uv_set)
        finally:
            PAYLOADS.pop(token, None)
    else:
        apply_arrays(path, uv_set, (u, v, counts, ids))
