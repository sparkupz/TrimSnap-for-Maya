"""UV set management for the selected meshes (name based, like the sidebar list)."""
import re

import maya.cmds as cmds

from . import commands, maya_io as mio


def maya_uv_name(name):
    """Maya UV set names allow letters, digits and underscores."""
    clean = re.sub(r"[^A-Za-z0-9_]", "_", name)
    return clean if re.match(r"[A-Za-z_]", clean) else "_" + clean


def resolve_name(existing, requested):
    """Map a (possibly Blender-style) name onto this mesh's UV sets.

    'UVMap' lands on the default 'map1' when that is all the mesh has, and
    'UVMap.001' becomes 'UVMap_001'.
    """
    if requested in existing:
        return requested
    clean = maya_uv_name(requested)
    if clean in existing:
        return clean
    if requested == "UVMap" and "map1" in existing:
        return "map1"
    return clean


def next_free_name(used):
    index = 2
    while f"map{index}" in used:
        index += 1
    return f"map{index}"


def names_of(path):
    return list(cmds.polyUVSet(path, query=True, allUVSets=True) or [])


def names_for(paths):
    seen = []
    for path in paths:
        for name in names_of(path):
            if name not in seen:
                seen.append(name)
    return seen


def current_of(path):
    result = cmds.polyUVSet(path, query=True, currentUVSet=True)
    return result[0] if result else ""


def current_name(paths):
    if not paths:
        return ""
    return current_of(paths[0])


def activate(path, name):
    if name in names_of(path):
        cmds.polyUVSet(path, currentUVSet=True, uvSet=name)
        try:
            from . import visualize
            visualize.link_current_uv_set(path)
        except Exception:   # the debug-texture link is cosmetic; never block UV set changes
            pass


def create_copy(path, name, source=None):
    """New UV set holding a copy of `source` (default: the current set)."""
    source = source or current_of(path)
    cmds.polyUVSet(path, create=True, uvSet=name)
    try:
        if source:
            mesh = mio.read_mesh(path, source)
            from .core.uvwrite import build_uv_arrays
            u, v, counts, ids = build_uv_arrays(mesh, [])
            commands.write_uvs(mio.editable_path(path), name, u, v, counts, ids)
    finally:
        if source:
            cmds.polyUVSet(path, currentUVSet=True, uvSet=source)


def ensure_sets(paths, names):
    """Make sure every mesh has all `names`, copying the mesh's own current set."""
    created = []
    try:
        for path in paths:
            existing = names_of(path)
            for name in names:
                if name in existing:
                    continue
                create_copy(path, name)
                created.append((path, name))
                existing.append(name)
    except RuntimeError:
        for path, name in reversed(created):
            try:
                cmds.polyUVSet(path, delete=True, uvSet=name)
            except RuntimeError:
                pass
        raise mio.MayaToolError("Could not add the UV set (UV set limit reached?)")


def add_set(paths):
    name = next_free_name(set(names_for(paths)))
    ensure_sets(paths, [name])
    for path in paths:
        activate(path, name)
    return name


def remove_set(paths, name):
    names = names_for(paths)
    if name not in names:
        raise mio.MayaToolError(f"UV set {name} does not exist")
    remaining = [n for n in names if n != name]
    fallback = remaining[min(names.index(name), len(remaining) - 1)] if remaining else ""
    for path in paths:
        if name not in names_of(path):
            continue
        if len(names_of(path)) == 1:
            continue                      # Maya keeps at least one UV set
        if current_of(path) == name:
            other = fallback if fallback in names_of(path) else next(n for n in names_of(path) if n != name)
            cmds.polyUVSet(path, currentUVSet=True, uvSet=other)
        cmds.polyUVSet(path, delete=True, uvSet=name)
    return fallback


def sync(paths, name, scope="SET"):
    names = names_for(paths) if scope == "ALL" else [name]
    ensure_sets(paths, names)
    for path in paths:
        activate(path, name)


def count_with(paths, name):
    return sum(1 for p in paths if name in names_of(p))
