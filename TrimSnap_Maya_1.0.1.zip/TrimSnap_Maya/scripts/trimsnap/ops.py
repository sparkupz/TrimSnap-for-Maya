"""TrimSnap operators.  Each takes an optional list of ``Target`` (default: the
current selection) and returns a ``Result``; UI code only has to display it.
"""
import math
import secrets
from contextlib import contextmanager

import maya.api.OpenMaya as om
import maya.api.OpenMayaUI as omui
import maya.cmds as cmds

from . import maya_io as mio, state
from .core import cuts, hotspot as hs, texel, trimpreset, unwrap
from .core.meshmodel import corner_faces_edge_border, shells_with_seeds

MayaToolError = mio.MayaToolError


class Result:
    def __init__(self, message, level="info", ok=True):
        self.message, self.level, self.ok = message, level, ok

    def __repr__(self):
        return f"Result({self.level}: {self.message})"


@contextmanager
def undo_chunk(name):
    cmds.undoInfo(openChunk=True, chunkName=name)
    try:
        yield
    finally:
        cmds.undoInfo(closeChunk=True)


class Job:
    """A mesh snapshot plus the faces an operator should act on."""

    def __init__(self, path, mesh, uv_set, seeds):
        self.path, self.mesh, self.uv_set, self.seeds = path, mesh, uv_set, seeds


def make_jobs(targets=None, strict=True):
    targets = mio.selected_targets() if targets is None else targets
    if not targets:
        raise MayaToolError("Select a mesh object or some faces first")
    jobs = []
    for target in targets:
        mesh = mio.read_mesh(target.path)
        seeds = target.seed_faces(mesh, strict)
        if seeds:
            jobs.append(Job(target.path, mesh, mio.current_uv_set(target.path), seeds))
    if not jobs:
        raise MayaToolError("Nothing selected on the mesh")
    return jobs


def _bake():
    return bool(state.settings.bake_history)


def _suffix(skipped=0, missing=0):
    text = ""
    if skipped:
        text += f"; skipped {skipped} degenerate island(s)"
    if missing:
        text += f"; {missing} face(s) without UVs"
    return text


def _commit_all(per_job):
    for job, groups in per_job:
        if groups:
            mio.commit(job.path, job.uv_set, job.mesh, groups, bake=_bake())


# ======================================================================= texel density
def _measure(jobs, td):
    rows, skipped, missing = [], 0, 0
    size = int(td["texture_size"])
    for job in jobs:
        shells, absent = shells_with_seeds(job.mesh, job.seeds)
        missing += absent
        data, skip = texel.measure_shells(job.mesh, shells, size, td["units"])
        skipped += skip
        rows.extend((job, faces, density) for faces, density in data)
    if not rows:
        raise MayaToolError("Selected islands have no valid UVs or surface area")
    return rows, skipped, missing


def get_td(targets=None, td=None):
    td = td or state.settings.td_values()
    rows, skipped, missing = _measure(make_jobs(targets, strict=False), td)
    average = sum(r[2] for r in rows) / len(rows)
    state.settings.set("density", average)
    return Result(f"Measured {len(rows)} UV island(s): {average:.2f} px/{td['units'].lower()}"
                  + _suffix(skipped, missing), "warning" if skipped or missing else "info")


def set_td(targets=None, td=None):
    td = td or state.settings.td_values()
    rows, skipped, missing = _measure(make_jobs(targets, strict=False), td)
    factors = texel.target_factors([r[2] for r in rows], td["density"], td["mode"])
    per_job = {}
    for (job, faces, _), factor in zip(rows, factors):
        per_job.setdefault(id(job), (job, []))[1].append(texel.scale_shell(job.mesh, faces, factor))
    with undo_chunk("TrimSnap Set TD"):
        _commit_all(per_job.values())
    return Result(f"Updated {len(rows)} UV island(s)" + _suffix(skipped, missing),
                  "warning" if skipped or missing else "info")


# ======================================================================= hotspot
def hotspot(behavior, targets=None, options=None, preset=None, trim_index=None):
    """Fit selected UV shells to the preset's trims.

    behavior: HORIZONTAL_TILING / VERTICAL_TILING / FIXED, or ignored when
    `trim_index` names one explicit trim (its own behavior is used).
    """
    key = {"HORIZONTAL_TILING": "HOTSPOT_HORIZONTAL", "VERTICAL_TILING": "HOTSPOT_VERTICAL",
           "FIXED": "HOTSPOT_FIXED"}.get(behavior, "HOTSPOT_FIXED")
    options = dict(options or state.settings.operator_options("HOTSPOT_TRIM" if trim_index is not None else key))
    preset = preset or state.library.trim(state.settings.trim_preset)
    if preset is None:
        raise MayaToolError("Select a trim preset")
    if trim_index is not None:
        if not 0 <= trim_index < len(preset["trims"]):
            raise MayaToolError("Selected trim is unavailable. Reload the preset.")
        trim = preset["trims"][trim_index]
        behavior = trim.get("behavior", "FIXED")
        if behavior not in hs.LABELS or not hs.matching_trims({"trims": [trim]}, behavior):
            raise MayaToolError("Selected trim has invalid bounds or behavior.")
        trims = [trim]
        options["island_scale_multiplier"] = 1.0
    else:
        trims = hs.matching_trims(preset, behavior)
        if not trims:
            raise MayaToolError(f"No valid {hs.LABELS[behavior]} trims in this preset")
    seed = options.get("random_seed", -1)
    if seed < 0:
        seed = secrets.randbelow(2 ** 31 - 1)
    jobs = make_jobs(targets, strict=False)
    per_job, count, skipped, missing = [], 0, 0, 0
    for job in jobs:
        shells, absent = shells_with_seeds(job.mesh, job.seeds)
        missing += absent
        groups = []
        for faces in shells:
            try:
                groups.append(hs.plan_shell(job.mesh, faces, trims, behavior, options, seed))
            except ValueError:
                skipped += 1
        count += len(groups)
        per_job.append((job, groups))
    if not count:
        raise MayaToolError("Select UV islands with nonzero area and an active UV set")
    with undo_chunk("TrimSnap Hotspot"):
        _commit_all(per_job)
    return Result(f"Hotspotted {count} UV island(s)" + _suffix(skipped, missing),
                  "warning" if skipped or missing else "info")


# ======================================================================= unwrap
def _call_unfold():
    try:
        cmds.loadPlugin("Unfold3D", quiet=True)
    except RuntimeError:
        pass
    if not hasattr(cmds, "u3dUnfold"):
        raise MayaToolError("Maya's Unfold3D plug-in is not available")
    cmds.u3dUnfold(ite=1, p=0, bi=1, tf=1, ms=1024, rs=0)


def _restore_selection(previous):
    try:
        if previous:
            cmds.select(previous, replace=True)
        else:
            cmds.select(clear=True)
    except RuntimeError:
        pass


def _unfold(plans):
    components = []
    for plan in plans:
        components.extend(mio.face_components(plan["job"].path, plan["faces"]))
    uvs = cmds.polyListComponentConversion(components, toUV=True) or []
    if not uvs:
        raise MayaToolError("Selected faces have no UVs to unfold")
    previous = cmds.ls(selection=True, long=True)
    try:
        cmds.select(uvs, replace=True)
        _call_unfold()
    finally:
        _restore_selection(previous)


def _unwrap(targets, options, for_trim):
    jobs = make_jobs(targets, strict=True)
    up, flat_up = mio.up_axis()
    plans = []
    for job in jobs:
        faces = sorted(job.seeds)
        protected = (corner_faces_edge_border(job.mesh, faces)
                     if options["respect_existing_seams"] else set())
        _, charts = cuts.plan_cuts(job.mesh, faces, options["angle_threshold"], protected)
        plans.append({"job": job, "faces": faces, "protected": protected, "charts": charts})
    if not any(p["charts"] for p in plans):
        raise MayaToolError("Select mesh faces")

    # 1. Write the cut structure as planar starting UVs (one shell per chart).
    for plan in plans:
        job = plan["job"]
        values = cuts.planar_layout(job.mesh, plan["charts"])
        groups = [{(f, i): values[(f, i)] for f in chart for i in range(len(job.mesh.faces[f]))}
                  for chart in plan["charts"]]
        mio.commit(job.path, job.uv_set, job.mesh, groups, bake=_bake())
    # 2. Maya's Unfold3D flattens every shell.
    _unfold(plans)
    # 3. Re-read the unfolded UVs, orient / stitch, then pack everything together.
    results = []
    for plan in plans:
        job = plan["job"]
        mesh = mio.read_mesh(job.path, job.uv_set)
        values = mesh.uv_values(plan["faces"])
        if len(values) != sum(len(mesh.faces[f]) for f in plan["faces"]):
            raise MayaToolError("Unfold3D did not return UVs for every selected face")
        if for_trim:
            charts = unwrap.finish_trim(mesh, plan["faces"], values, plan["protected"],
                                        options["orientation"], options["stitch_concave_face_pairs"],
                                        up, flat_up, pack_result=False)
        else:
            charts = unwrap.finish_auto(mesh, plan["faces"], values, plan["protected"],
                                        options["prioritize_world_orientation"], up, flat_up,
                                        pack_result=False)
        results.append((job, mesh, charts))
    unwrap.pack([c for _, _, charts in results for c in charts])
    for job, mesh, charts in results:
        mio.commit(job.path, job.uv_set, mesh, charts, bake=_bake())
    total = sum(len(charts) for _, _, charts in results)
    return Result(f"Unwrapped into {total} island(s)")


def auto_unwrap(targets=None, options=None):
    options = options or state.settings.operator_options("AUTO_UNWRAP")
    with undo_chunk("TrimSnap Auto Unwrap"):
        return _unwrap(targets, options, for_trim=False)


def unwrap_for_trim(targets=None, options=None):
    options = options or state.settings.operator_options("UNWRAP_FOR_TRIM")
    with undo_chunk("TrimSnap Unwrap for Trim"):
        return _unwrap(targets, options, for_trim=True)


# ======================================================================= project from view
def project_from_view(targets=None, options=None):
    options = options or state.settings.operator_options("PROJECT_FROM_VIEW")
    jobs = make_jobs(targets, strict=True)
    view = omui.M3dView.active3dView()
    camera = view.getCamera()
    camera_fn = om.MFnCamera(camera)
    inverse = camera.inclusiveMatrixInverse()
    width, height = float(mio.attr(view, "portWidth")), float(mio.attr(view, "portHeight"))
    aspect = width / height if height else 1.0
    is_ortho = bool(mio.attr(camera_fn, "isOrtho"))
    tan_h = math.tan(mio.attr(camera_fn, "horizontalFieldOfView") / 2.0)
    tan_v = math.tan(mio.attr(camera_fn, "verticalFieldOfView") / 2.0)
    half_width = mio.attr(camera_fn, "orthoWidth") / 2.0

    # camera-space coordinates of every vertex that is used
    views = {}
    for job in jobs:
        for f in job.seeds:
            for v in job.mesh.faces[f]:
                if (job.path, v) not in views:
                    p = om.MPoint(*job.mesh.points[v]) * inverse
                    views[(job.path, v)] = (p.x, p.y, -p.z)
    depths = [d for _, _, d in views.values() if d > 1e-6]
    mean_depth = sum(depths) / len(depths) if depths else 1.0

    coords = {}
    for key, (x, y, depth) in views.items():
        if is_ortho:
            nx, ny = x / half_width, y / (half_width / aspect)
        else:
            depth = mean_depth if options["orthographic"] else max(depth, 1e-6)
            nx, ny = x / (depth * tan_h), y / (depth * tan_v)
        if options["camera_bounds"]:
            u, v = 0.5 + nx / 2.0, 0.5 + ny / 2.0
            if options["correct_aspect"]:
                u = 0.5 + (nx * aspect) / 2.0
        else:
            u, v = nx / 2.0 * (aspect if options["correct_aspect"] else 1.0), ny / 2.0
        coords[key] = [u, v]
    if options["scale_to_bounds"] and coords:
        us = [c[0] for c in coords.values()]
        vs = [c[1] for c in coords.values()]
        span = max(max(us) - min(us), max(vs) - min(vs), 1e-12)
        for c in coords.values():
            c[0], c[1] = (c[0] - min(us)) / span, (c[1] - min(vs)) / span
    if options["clip_to_bounds"]:
        for c in coords.values():
            c[0], c[1] = min(1.0, max(0.0, c[0])), min(1.0, max(0.0, c[1]))

    per_job = []
    for job in jobs:
        group = {(f, i): tuple(coords[(job.path, v)])
                 for f in job.seeds for i, v in enumerate(job.mesh.faces[f])}
        per_job.append((job, [group]))
    with undo_chunk("TrimSnap Project From View"):
        _commit_all(per_job)
    return Result(f"Projected {sum(len(j.seeds) for j in jobs)} face(s) from the current view")


# ======================================================================= seams
def _edges_from_selection(for_cut):
    edges = cmds.filterExpand(selectionMask=32, expand=True) or []
    if edges:
        return edges
    selection = cmds.ls(selection=True) or []
    if not selection:
        return []
    components = [s for s in selection if "." in s]
    if components:
        flags = {"border": True} if for_cut else {"internal": True}
        converted = cmds.polyListComponentConversion(components, toEdge=True, **flags) or []
        return cmds.filterExpand(converted, selectionMask=32, expand=True) or []
    out = []
    for target in mio.selected_targets():
        out.append(target.path + ".e[*]")
    return out


def mark_seam(cut=True, targets=None):
    """Cut (Mark) or sew (Unmark) the selected edges: in Maya a seam is a UV border."""
    if targets is not None:
        edges = [t.path + ".e[*]" for t in targets]
    else:
        edges = _edges_from_selection(cut)
    if not edges:
        raise MayaToolError("Select edges (or faces) to " + ("mark" if cut else "unmark") + " as seams")
    with undo_chunk("TrimSnap Mark Seam" if cut else "TrimSnap Unmark Seam"):
        (cmds.polyMapCut if cut else cmds.polyMapSew)(edges)
    return Result(("Marked" if cut else "Unmarked") + " seams on the selection")


# ======================================================================= trim presets
def capture_selected_plane():
    """Trim sheet capture from the selected plane mesh (see core.trimpreset)."""
    targets = mio.selected_targets()
    if not targets:
        raise MayaToolError("Select a plane mesh to create a trim preset")
    path = targets[0].path
    dag = mio.dag_path(path)
    fn = om.MFnMesh(dag)
    points = [(p.x, p.y, p.z) for p in fn.getPoints(om.MSpace.kObject)]
    counts, vids = fn.getVertices()
    counts, vids = list(counts), list(vids)
    faces, pos = [], 0
    for c in counts:
        faces.append(tuple(vids[pos:pos + c]))
        pos += c
    matrix = dag.inclusiveMatrix()

    def to_world(direction):
        v = om.MVector(*direction) * matrix
        return (v.x, v.y, v.z)

    parent = cmds.listRelatives(path, parent=True) or [path]
    return trimpreset.capture_plane(parent[0], points, faces, to_world)


def create_trim_preset(name, tiles_horizontally, capture):
    data = trimpreset.save_new(state.trim_dir(), name, tiles_horizontally, capture)
    state.library.reload()
    state.settings.set("trim_preset", data["id"])
    state.settings.set("trim_selected", [0])
    return data
