"""Play an automation preset on the selected meshes.

Order: UV blocks top to bottom, then steps top to bottom.  Each block makes
its UV set current (creating it from the mesh's active set when missing) and
every action then runs on all faces of the selected meshes.
"""
import maya.cmds as cmds

from . import maya_io as mio, ops, state, uvsets, visualize
from .core import automation as auto

BEHAVIOR = {"HOTSPOT_HORIZONTAL": "HORIZONTAL_TILING", "HOTSPOT_VERTICAL": "VERTICAL_TILING",
            "HOTSPOT_FIXED": "FIXED"}


class RunError(RuntimeError):
    def __init__(self, message, partial=False):
        super().__init__(message)
        self.partial = partial


def _resolve_all(paths, requested):
    """Make `requested` exist on every mesh (name mapped per mesh) and current."""
    for path in paths:
        name = uvsets.resolve_name(uvsets.names_of(path), requested)
        if name not in uvsets.names_of(path):
            uvsets.create_copy(path, name)
        uvsets.activate(path, name)


def preflight(data, paths):
    auto.validate(data)
    if not paths:
        raise ValueError("Select at least one mesh object")
    active = state.settings.trim_preset
    for b_index, block in enumerate(data["uv_blocks"], 1):
        for s_index, step in enumerate(block["steps"], 1):
            key = step["action"]
            where = f"Block {b_index} ({block['uv_map']}), step {s_index} ({auto.ACTIONS[key]})"
            values = auto.normalize_settings(key, step.get("settings", {}), block["uv_map"])
            try:
                if key == "SELECT_TRIM_PRESET":
                    _require_trim(values["trim_preset"])
                    active = values["trim_preset"]
                elif key.startswith("HOTSPOT_"):
                    preset = _require_trim(active if values["use_active_trim_preset"]
                                           else values["trim_preset"])
                    if key == "HOTSPOT_TRIM" and values["trim_number"] > len(preset["trims"]):
                        raise ValueError("Trim number exceeds the preset trim count")
                elif key == "CUSTOM_DEBUG" and not values["custom_debug_path"]:
                    raise ValueError("Custom debug image is missing")
            except ValueError as exc:
                raise ValueError(f"{where}: {exc}") from exc


def _require_trim(preset_id):
    preset = state.library.trim(preset_id)
    if preset is None:
        raise ValueError("A referenced Trim Preset is missing or has not been selected")
    return preset


def execute_step(key, values, paths, context):
    targets = [mio.Target.everything(p) for p in paths]
    if key == "SELECT_TRIM_PRESET":
        context["trim"] = values["trim_preset"]
        state.settings.set("trim_preset", values["trim_preset"])
    elif key == "AUTO_UNWRAP":
        return ops.auto_unwrap(targets, values)
    elif key == "UNWRAP_FOR_TRIM":
        return ops.unwrap_for_trim(targets, values)
    elif key in ("MARK_SEAM", "UNMARK_SEAM"):
        return ops.mark_seam(key == "MARK_SEAM", targets)
    elif key == "PROJECT_FROM_VIEW":
        return ops.project_from_view(targets, values)
    elif key in ("GET_TD", "SET_TD"):
        td = dict(state.settings.td_values(), **values)
        return (ops.get_td if key == "GET_TD" else ops.set_td)(targets, td)
    elif key.startswith("HOTSPOT_"):
        preset_id = context["trim"] if values["use_active_trim_preset"] else values["trim_preset"]
        options = {k: v for k, v in values.items()
                   if k not in ("use_active_trim_preset", "trim_preset", "trim_number")}
        preset = _require_trim(preset_id)
        if key == "HOTSPOT_TRIM":
            return ops.hotspot("FIXED", targets, options, preset, trim_index=values["trim_number"] - 1)
        return ops.hotspot(BEHAVIOR[key], targets, options, preset)
    elif key in ("UV_CHECKER", "CUSTOM_DEBUG"):
        if key == "CUSTOM_DEBUG":
            state.settings.set("custom_debug_path", values["custom_debug_path"])
        visualize.toggle("CHECKER" if key == "UV_CHECKER" else "CUSTOM", paths)
    elif key == "SELECT_UV_SET":
        for path in paths:
            uvsets.activate(path, uvsets.resolve_name(uvsets.names_of(path), values["uv_name"]))
    elif key == "ADD_UV_SET":
        uvsets.add_set(paths)
    elif key == "REMOVE_UV_SET":
        for path in paths:
            name = uvsets.resolve_name(uvsets.names_of(path), values["uv_name"])
            if name in uvsets.names_of(path):
                uvsets.remove_set([path], name)
    elif key == "SYNC_UV_SETS":
        name = uvsets.resolve_name(uvsets.names_of(paths[0]), values["uv_name"])
        uvsets.sync(paths, name, values["scope"])
    return None


def run(data):
    """Run a preset; returns the number of completed steps."""
    paths = mio.selected_mesh_paths()
    state.library.reload()   # pick up preset files added or changed on disk since startup
    try:
        preflight(data, paths)
    except (ValueError, TypeError, KeyError) as exc:
        raise RunError(str(exc)) from exc
    previous = cmds.ls(selection=True, long=True)
    context = {"trim": state.settings.trim_preset}
    position, completed = "Preparing selected meshes", 0
    cmds.undoInfo(openChunk=True, chunkName="TrimSnap Automation: " + data["name"])
    try:
        for b_index, block in enumerate(data["uv_blocks"], 1):
            position = f"Block {b_index} ({block['uv_map']})"
            _resolve_all(paths, block["uv_map"])
            for s_index, step in enumerate(block["steps"], 1):
                key = step["action"]
                position = f"Block {b_index} ({block['uv_map']}), step {s_index} ({auto.ACTIONS[key]})"
                values = auto.normalize_settings(key, step.get("settings", {}), block["uv_map"])
                execute_step(key, values, paths, context)
                completed += 1
    except Exception as exc:
        raise RunError(f"{position}: {exc}", partial=True) from exc
    finally:
        try:
            if previous:
                cmds.select(previous, replace=True)
            else:
                cmds.select(clear=True)
        except RuntimeError:
            pass
        cmds.undoInfo(closeChunk=True)
    return completed
