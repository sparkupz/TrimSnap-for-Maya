"""Trim outlines in the UV Editor.

The overlay is rendered to a transparent PNG (inward outlines + trim numbers)
and put on the UV Editor's image stack, so nothing in the scene is touched.
"""
import colorsys
import os
import tempfile
from pathlib import Path

import maya.cmds as cmds

from . import state
from .core.trimpreset import trim_geometry
from .qt import QtCore, QtGui

OVERLAY_FILE = Path(tempfile.gettempdir()) / "trimsnap_trim_overlay.png"


def trim_color(index):
    """Evenly spread hues (golden ratio) so neighbouring trims differ."""
    r, g, b = colorsys.hsv_to_rgb((0.08 + index * 0.61803398875) % 1, 0.75, 1.0)
    return int(r * 255), int(g * 255), int(b * 255)


def render(preset, size=2048, path=OVERLAY_FILE, stroke=3.0):
    """Write the overlay PNG for a preset; returns its path."""
    image = QtGui.QImage(size, size, QtGui.QImage.Format_ARGB32)
    image.fill(QtGui.QColor(0, 0, 0, 0))
    painter = QtGui.QPainter(image)
    painter.setRenderHint(QtGui.QPainter.Antialiasing, True)
    try:
        for index, trim in enumerate(preset.get("trims", [])):
            try:
                points, center = trim_geometry(trim)
            except (KeyError, TypeError, ValueError, IndexError):
                continue
            red, green, blue = trim_color(index)
            color = QtGui.QColor(red, green, blue, 255)
            polygon = QtGui.QPolygonF([QtCore.QPointF(x * size, (1.0 - y) * size) for x, y in points])
            outline = QtGui.QPainterPath()
            outline.addPolygon(polygon)
            outline.closeSubpath()
            # Stroke twice as wide and clip to the polygon: a clean inward outline.
            painter.save()
            painter.setClipPath(outline)
            pen = QtGui.QPen(color, stroke * 2)
            pen.setJoinStyle(QtCore.Qt.MiterJoin)
            painter.setPen(pen)
            painter.setBrush(QtCore.Qt.NoBrush)
            painter.drawPath(outline)
            painter.restore()
            height_px = (max(p[1] for p in points) - min(p[1] for p in points)) * size
            font = QtGui.QFont()
            font.setPixelSize(int(max(14, min(56, height_px * 0.6))))
            font.setBold(True)
            painter.setFont(font)
            label = str(index + 1)
            cx, cy = center[0] * size, (1.0 - center[1]) * size
            rect = QtCore.QRectF(cx - 80, cy - 40, 160, 80)
            painter.setPen(QtGui.QColor(0, 0, 0, 220))
            painter.drawText(rect.translated(2, 2), QtCore.Qt.AlignCenter, label)
            painter.setPen(color)
            painter.drawText(rect, QtCore.Qt.AlignCenter, label)
    finally:
        painter.end()
    path = Path(path)
    if not image.save(str(path), "PNG"):
        raise RuntimeError(f"Could not write overlay image to {path}")
    return path


def uv_editors():
    return cmds.getPanel(scriptType="polyTexturePlacementPanel") or []


def _our_indices(editor):
    names = cmds.textureWindow(editor, query=True, imageNames=True) or []
    return [i for i, n in enumerate(names) if OVERLAY_FILE.name in os.path.basename(str(n))]


_touched = False   # becomes True only after the user explicitly enabled the overlay


def clear():
    if not _touched:
        return          # never call UV Editor commands unless the overlay was used
    for editor in uv_editors():
        try:
            for index in reversed(_our_indices(editor)):
                cmds.textureWindow(editor, edit=True, removeImage=index)
        except RuntimeError:
            pass


def refresh():
    """Show (or hide) the overlay of the active trim preset; returns a status text."""
    global _touched
    preset = state.library.trim(state.settings.trim_preset)
    if preset is None or not state.settings.overlay_experimental:
        clear()
        return ""
    _touched = True
    if not uv_editors():
        return "Open the UV Editor to see the trim overlay."
    path = render(preset)
    problems = []
    for editor in uv_editors():
        try:
            for index in reversed(_our_indices(editor)):
                cmds.textureWindow(editor, edit=True, removeImage=index)
            cmds.textureWindow(editor, edit=True, loadImage=str(path))
            indices = _our_indices(editor)
            if indices:
                cmds.textureWindow(editor, edit=True, displayImage=indices[-1], imageDisplay=True)
        except RuntimeError as exc:
            problems.append(str(exc))
    if problems:
        return ("Overlay saved to %s - load it from the UV Editor's Image menu (%s)"
                % (path, problems[0]))
    return ""
