"""OpenMaya 2.0 glue: selection, mesh reading and UV committing."""
import maya.api.OpenMaya as om
import maya.cmds as cmds

from . import commands
from .core.meshmodel import Mesh
from .core.uvwrite import build_uv_arrays


class MayaToolError(Exception):
    """A user-facing problem (bad selection, missing plug-in...)."""


def attr(obj, name):
    """OpenMaya 2.0 exposes some getters as properties and some as methods."""
    value = getattr(obj, name)
    return value() if callable(value) else value


# ---------------------------------------------------------------- dag helpers
def dag_path(path):
    sel = om.MSelectionList()
    sel.add(path)
    return sel.getDagPath(0)


def mesh_shape(dag):
    """MDagPath of the (non-intermediate) mesh shape below/at `dag`, else None."""
    d = om.MDagPath(dag)
    try:
        if d.apiType() != om.MFn.kMesh:
            d.extendToShape()
    except RuntimeError:
        return None
    if d.apiType() != om.MFn.kMesh or attr(om.MFnDagNode(d), "isIntermediateObject"):
        return None
    return d


def up_axis():
    """(world up, up used for horizontal surfaces) for the scene's up axis."""
    if cmds.upAxis(q=True, axis=True) == "z":
        return (0.0, 0.0, 1.0), (0.0, 1.0, 0.0)
    return (0.0, 1.0, 0.0), (0.0, 0.0, -1.0)


# ---------------------------------------------------------------- selection
def _is_complete(fn):
    try:
        return bool(attr(fn, "isComplete"))
    except AttributeError:
        return False


class Target:
    """One mesh and what part of it is selected."""

    def __init__(self, path, whole=False):
        self.path = path
        self.whole = whole
        self.faces, self.edges, self.verts, self.uvs = set(), set(), set(), set()

    @classmethod
    def everything(cls, path):
        return cls(path, whole=True)

    def add_component(self, comp):
        api = comp.apiType()
        if api == om.MFn.kMeshVtxFaceComponent:
            self.faces.update(om.MFnDoubleIndexedComponent(comp).getElements()[1])
            return
        kinds = {om.MFn.kMeshPolygonComponent: self.faces, om.MFn.kMeshEdgeComponent: self.edges,
                 om.MFn.kMeshVertComponent: self.verts, om.MFn.kMeshMapComponent: self.uvs}
        bucket = kinds.get(api)
        if bucket is None:
            return
        fn = om.MFnSingleIndexedComponent(comp)
        if _is_complete(fn):
            self.whole = True
        else:
            bucket.update(fn.getElements())

    def has_components(self):
        return bool(self.faces or self.edges or self.verts or self.uvs)

    def seed_faces(self, mesh, strict=True):
        """Faces to operate on.

        strict: faces fully covered by the selection (vertices/edges/UVs must
        all be selected); falls back to any-touching when nothing is covered.
        loose: faces touched by any selected element (shell-level tools).
        """
        if self.whole:
            return set(range(len(mesh.faces)))
        faces = set(self.faces)
        verts = set(self.verts)
        if self.edges:
            fn = om.MFnMesh(dag_path(self.path))
            for edge in self.edges:
                verts.update(fn.getEdgeVertices(edge))
        loose = set(faces)
        strict_set = set(faces)
        if verts:
            for f, fv in enumerate(mesh.faces):
                hits = sum(1 for v in fv if v in verts)
                if hits:
                    loose.add(f)
                    if hits == len(fv):
                        strict_set.add(f)
        if self.uvs:
            for f, ids in enumerate(mesh.corner_uv):
                hits = sum(1 for i in ids if i in self.uvs)
                if hits:
                    loose.add(f)
                    if hits == len(ids):
                        strict_set.add(f)
        if strict:
            return strict_set or loose
        return loose


def selected_targets():
    """Mesh targets from the active selection (object or component level)."""
    sel = om.MGlobal.getActiveSelectionList()
    targets = {}
    for i in range(sel.length()):
        try:
            dag, comp = sel.getComponent(i)
        except Exception:
            continue
        shape = mesh_shape(dag)
        if shape is None:
            continue
        path = shape.fullPathName()
        target = targets.setdefault(path, Target(path))
        if comp.isNull():
            target.whole = True
        else:
            target.add_component(comp)
    return list(targets.values())


def selected_mesh_paths():
    return [t.path for t in selected_targets()]


# ---------------------------------------------------------------- reading
def current_uv_set(path):
    return om.MFnMesh(dag_path(path)).currentUVSetName()


def read_mesh(path, uv_set=None):
    """Snapshot a mesh (world-space points, topology and a UV set) as core.Mesh."""
    fn = om.MFnMesh(dag_path(path))
    uv_set = uv_set or fn.currentUVSetName()
    points = [(p.x, p.y, p.z) for p in fn.getPoints(om.MSpace.kWorld)]
    counts, vids = fn.getVertices()
    counts, vids = list(counts), list(vids)
    faces, pos = [], 0
    for c in counts:
        faces.append(tuple(vids[pos:pos + c]))
        pos += c
    try:
        u, v = fn.getUVs(uv_set)
        ucounts, uids = fn.getAssignedUVs(uv_set)
        u, v, ucounts, uids = list(u), list(v), list(ucounts), list(uids)
    except RuntimeError:
        u, v, ucounts, uids = [], [], [0] * len(faces), []
    corner_uv, pos = [], 0
    for f, c in enumerate(counts):
        n = ucounts[f] if f < len(ucounts) else 0
        if n == c:
            corner_uv.append(uids[pos:pos + n])
        else:
            corner_uv.append([-1] * c)
        pos += n
    return Mesh(path, points, faces, u, v, corner_uv)


# ---------------------------------------------------------------- writing
def editable_path(path, bake=True):
    """Shape node whose UV data can be edited directly without being overwritten.

    Direct API edits are recomputed away when construction history sits above
    the shape, so non-deformer history is baked first.  Deformed meshes are
    edited on their original (intermediate) shape.
    """
    if bake:
        try:
            cmds.bakePartialHistory(path, prePostDeformers=True)
        except RuntimeError:
            pass
    if not cmds.listConnections(path + ".inMesh", source=True, destination=False):
        return path
    try:
        original = cmds.deformableShape(path, originalGeometry=True) or []
    except RuntimeError:
        original = []
    if original:
        found = cmds.ls(original[0].split(".")[0], long=True)
        if found:
            return found[0]
    return path


def commit(path, uv_set, mesh, groups, bake=True):
    """Write `groups` ({corner: (u, v)} dicts) into the mesh's UV set (undoable)."""
    u, v, counts, ids = build_uv_arrays(mesh, groups)
    commands.write_uvs(editable_path(path, bake), uv_set, u, v, counts, ids)


# ---------------------------------------------------------------- components
def face_components(path, faces):
    """Compressed ``path.f[a:b]`` strings for a set of face indices."""
    faces = sorted(faces)
    if not faces:
        return []
    out, start, prev = [], faces[0], faces[0]

    def fmt(a, b):
        return f"{path}.f[{a}]" if a == b else f"{path}.f[{a}:{b}]"

    for f in faces[1:]:
        if f == prev + 1:
            prev = f
            continue
        out.append(fmt(start, prev))
        start = prev = f
    out.append(fmt(start, prev))
    return out
