"""Paths, persistent settings and the preset library (no Maya needed to import)."""
import json
import os
import shutil
from pathlib import Path

from .core import automation, specs, trimpreset

PACKAGE_DIR = Path(__file__).resolve().parent
SHIPPED_PRESETS = PACKAGE_DIR / "Presets"
TEXTURE_DIR = PACKAGE_DIR / "Textures"
CHECKER_TEXTURE = TEXTURE_DIR / "TrimSnap_UV_Checker_1024.png"

BASE_DEFAULTS = {
    "density": 1024.0, "units": "M", "mode": "AVERAGE", "texture_size": "1024",
    "trim_preset": "NONE", "trim_selected": [0], "overlay_experimental": False,
    "automation_preset": "NONE", "custom_debug_path": "",
    "bake_history": True,
}


def user_dir():
    """Per-user writable folder (inside Maya's app dir) for presets and settings."""
    override = os.environ.get("TRIMSNAP_USER_DIR")
    if override:
        base = Path(override)
    else:
        try:
            import maya.cmds as cmds
            base = Path(cmds.internalVar(userAppDir=True)) / "trimsnap"
        except Exception:
            base = Path.home() / ".trimsnap"
    base.mkdir(parents=True, exist_ok=True)
    return base


def trim_dir():
    path = user_dir() / "Presets" / "TrimPresets"
    path.mkdir(parents=True, exist_ok=True)
    return path


def automation_dir():
    path = user_dir() / "Presets" / "AutomationPresets"
    path.mkdir(parents=True, exist_ok=True)
    return path


def install_default_presets():
    """Copy shipped presets into the user folder the first time (never overwrite)."""
    for sub, target in (("TrimPresets", trim_dir()), ("AutomationPresets", automation_dir())):
        source = SHIPPED_PRESETS / sub
        if not source.is_dir():
            continue
        marker = target / ".defaults_installed"
        if marker.exists():
            continue
        for path in source.glob("*.json"):
            if not (target / path.name).exists():
                shutil.copy2(path, target / path.name)
        marker.write_text("1")


class Settings:
    """Plain persistent settings; operator options are stored per action key."""

    def __init__(self):
        self.values = json.loads(json.dumps(BASE_DEFAULTS))
        self.options = {}

    @property
    def path(self):
        return user_dir() / "settings.json"

    def load(self):
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        for key, default in BASE_DEFAULTS.items():
            value = data.get("values", {}).get(key, default)
            if type(value) is type(default):
                self.values[key] = value
        for name in ("density", "units", "mode", "texture_size"):
            self.values[name] = specs.coerce(name, self.values[name])
        saved = data.get("options", {})
        if isinstance(saved, dict):
            self.options = {k: v for k, v in saved.items() if isinstance(v, dict)}

    def save(self):
        try:
            self.path.write_text(json.dumps({"values": self.values, "options": self.options},
                                            indent=2), encoding="utf-8")
        except OSError:
            pass

    def __getattr__(self, name):
        if name in ("values", "options"):
            raise AttributeError(name)
        try:
            return self.values[name]
        except KeyError:
            raise AttributeError(name)

    def set(self, name, value):
        self.values[name] = value
        self.save()

    def operator_options(self, key):
        """Validated options for an action, falling back to defaults per field."""
        names = specs.OPERATOR_FIELDS.get(key, ())
        saved = self.options.get(key, {})
        return {n: (saved[n] if n in saved and specs.check_value(n, saved[n])
                    else specs.FIELDS[n]["default"]) for n in names}

    def set_operator_options(self, key, values):
        self.options[key] = {n: values[n] for n in specs.OPERATOR_FIELDS.get(key, ()) if n in values}
        self.save()

    def td_values(self):
        return {n: self.values[n] for n in specs.TD_FIELDS}


class Library:
    """In-memory view of the trim and automation preset folders."""

    def __init__(self):
        self.trims, self.trim_paths, self.trim_errors = [], {}, []
        self.autos, self.auto_paths, self.auto_errors = [], {}, []

    def reload(self):
        install_default_presets()
        self.trims, self.trim_paths, self.trim_errors = trimpreset.load_all(trim_dir())
        self.autos, self.auto_paths, self.auto_errors = automation.load_all(automation_dir())

    def trim(self, preset_id):
        return next((p for p in self.trims if p["id"] == preset_id), None)

    def auto(self, preset_id):
        return next((p for p in self.autos if p["id"] == preset_id), None)


settings = Settings()
library = Library()


def startup():
    settings.load()
    library.reload()
    if library.trim(settings.trim_preset) is None:
        settings.values["trim_preset"] = "NONE"
    if library.auto(settings.automation_preset) is None:
        settings.values["automation_preset"] = "NONE"
