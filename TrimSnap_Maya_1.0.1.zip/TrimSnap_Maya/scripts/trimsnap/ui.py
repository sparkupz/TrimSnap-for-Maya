"""TrimSnap window (PySide2 / PySide6, dockable in Maya)."""
import copy
import math
import traceback

import maya.api.OpenMaya as om
import maya.cmds as cmds
from maya.app.general.mayaMixin import MayaQWidgetDockableMixin

from . import maya_io as mio, ops, overlay, runner, state, uvsets, visualize
from .core import automation as auto, specs, texel, trimpreset
from .core.hotspot import LABELS
from .qt import QtCore, QtGui, QtWidgets, exec_dialog, maya_main_window

WINDOW_NAME = "TrimSnapWindow"
BEHAVIOR_ITEMS = [("HORIZONTAL_TILING", "Horizontal Tiling"), ("VERTICAL_TILING", "Vertical Tiling"),
                  ("FIXED", "Fixed")]


# ======================================================================= generic widgets
class Section(QtWidgets.QWidget):
    """Collapsible panel like the Blender sidebar panels."""

    def __init__(self, title, expanded=True, parent=None):
        super().__init__(parent)
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(2)
        self.header = QtWidgets.QToolButton()
        self.header.setText(title)
        self.header.setCheckable(True)
        self.header.setChecked(expanded)
        self.header.setToolButtonStyle(QtCore.Qt.ToolButtonTextBesideIcon)
        self.header.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.header.setStyleSheet("QToolButton { font-weight: bold; text-align: left; padding: 3px; }")
        self.body = QtWidgets.QFrame()
        self.body_layout = QtWidgets.QVBoxLayout(self.body)
        self.body_layout.setContentsMargins(6, 4, 6, 6)
        self.body_layout.setSpacing(4)
        outer.addWidget(self.header)
        outer.addWidget(self.body)
        self.header.toggled.connect(self._toggle)
        self._toggle(expanded)

    def _toggle(self, expanded):
        self.header.setArrowType(QtCore.Qt.DownArrow if expanded else QtCore.Qt.RightArrow)
        self.body.setVisible(expanded)

    def add(self, widget_or_layout):
        if isinstance(widget_or_layout, QtWidgets.QLayout):
            self.body_layout.addLayout(widget_or_layout)
        else:
            self.body_layout.addWidget(widget_or_layout)
        return widget_or_layout


def hbox(*widgets):
    layout = QtWidgets.QHBoxLayout()
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(3)
    for widget in widgets:
        layout.addWidget(widget)
    return layout


def option_button(callback, tip="Options"):
    button = QtWidgets.QToolButton()
    button.setText("...")
    button.setToolTip(tip)
    button.clicked.connect(lambda *_: callback())
    return button


def block_signals(*widgets):
    class _Guard:
        def __enter__(self_inner):
            self_inner.before = [w.blockSignals(True) for w in widgets]

        def __exit__(self_inner, *exc):
            for w, was in zip(widgets, self_inner.before):
                w.blockSignals(was)
    return _Guard()


class FieldForm(QtWidgets.QWidget):
    """Edits settings described by ``core.specs`` (checkboxes, spinners, combos...)."""
    changed = QtCore.Signal()

    def __init__(self, names, values, parent=None):
        super().__init__(parent)
        self.names = list(names)
        self.widgets = {}
        form = QtWidgets.QFormLayout(self)
        form.setContentsMargins(0, 0, 0, 0)
        for name in self.names:
            spec = specs.FIELDS[name]
            widget = self._make(spec, values.get(name, spec["default"]))
            self.widgets[name] = widget
            form.addRow(spec["label"] or name, widget)

    def _make(self, spec, value):
        kind = spec["type"]
        if kind == "bool":
            widget = QtWidgets.QCheckBox()
            widget.setChecked(bool(value))
            widget.toggled.connect(lambda *_: self.changed.emit())
        elif kind == "int":
            widget = QtWidgets.QSpinBox()
            widget.setRange(int(max(spec["min"], -2 ** 31 + 1)), int(min(spec["max"], 2 ** 31 - 1)))
            widget.setValue(int(value))
            widget.valueChanged.connect(lambda *_: self.changed.emit())
        elif kind == "float":
            widget = QtWidgets.QDoubleSpinBox()
            if spec["angle"]:
                widget.setRange(math.degrees(spec["min"]), math.degrees(spec["max"]))
                widget.setDecimals(1)
                widget.setSuffix(" deg")
                widget.setValue(math.degrees(value))
            else:
                widget.setDecimals(spec["decimals"])
                widget.setRange(max(spec["min"], -1e9), min(spec["max"], 1e9))
                widget.setSingleStep(spec["step"])
                widget.setValue(value)
            widget.valueChanged.connect(lambda *_: self.changed.emit())
        elif kind == "enum":
            widget = QtWidgets.QComboBox()
            for ident, label in spec["items"]:
                widget.addItem(label, ident)
            widget.setCurrentIndex(max(0, widget.findData(value)))
            widget.currentIndexChanged.connect(lambda *_: self.changed.emit())
        elif spec.get("kind") == "trim_preset":
            widget = QtWidgets.QComboBox()
            widget.addItem("(choose a trim preset)", "NONE")
            for preset in state.library.trims:
                widget.addItem(preset["name"], preset["id"])
            widget.setCurrentIndex(max(0, widget.findData(value)))
            widget.currentIndexChanged.connect(lambda *_: self.changed.emit())
        else:
            widget = QtWidgets.QLineEdit(str(value))
            widget.editingFinished.connect(lambda: self.changed.emit())
            if spec.get("kind") == "file":
                holder = QtWidgets.QWidget()
                row = QtWidgets.QHBoxLayout(holder)
                row.setContentsMargins(0, 0, 0, 0)
                browse = QtWidgets.QToolButton()
                browse.setText("...")

                def pick(line=widget):
                    path, _ = QtWidgets.QFileDialog.getOpenFileName(
                        self, "Choose an image", "", "Images (*.png *.jpg *.jpeg *.tif *.tiff *.tga *.bmp)")
                    if path:
                        line.setText(path)
                        self.changed.emit()
                browse.clicked.connect(lambda *_: pick())
                row.addWidget(widget)
                row.addWidget(browse)
                holder.line = widget
                return holder
        return widget

    def values(self):
        out = {}
        for name, widget in self.widgets.items():
            spec = specs.FIELDS[name]
            kind = spec["type"]
            if kind == "bool":
                out[name] = widget.isChecked()
            elif kind == "int":
                out[name] = int(widget.value())
            elif kind == "float":
                out[name] = math.radians(widget.value()) if spec["angle"] else float(widget.value())
                if spec["angle"]:
                    out[name] = min(max(out[name], spec["min"]), spec["max"])
            elif kind == "enum" or spec.get("kind") == "trim_preset":
                out[name] = widget.currentData()
            else:
                line = getattr(widget, "line", widget)
                out[name] = line.text()
        return out


class OptionsDialog(QtWidgets.QDialog):
    def __init__(self, title, names, values, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(360)
        layout = QtWidgets.QVBoxLayout(self)
        self.form = FieldForm(names, values)
        layout.addWidget(self.form)
        buttons = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.Ok | QtWidgets.QDialogButtonBox.Cancel
            | QtWidgets.QDialogButtonBox.RestoreDefaults)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        buttons.button(QtWidgets.QDialogButtonBox.RestoreDefaults).clicked.connect(self._defaults)
        layout.addWidget(buttons)
        self._names = names

    def _defaults(self):
        for name in self._names:
            widget = self.form.widgets[name]
            default = specs.FIELDS[name]["default"]
            spec = specs.FIELDS[name]
            if spec["type"] == "bool":
                widget.setChecked(default)
            elif spec["type"] in ("int", "float"):
                widget.setValue(math.degrees(default) if spec.get("angle") else default)
            elif spec["type"] == "enum":
                widget.setCurrentIndex(max(0, widget.findData(default)))


def edit_operator_options(key, title, parent):
    dialog = OptionsDialog(title + " Options", specs.OPERATOR_FIELDS[key],
                           state.settings.operator_options(key), parent)
    if exec_dialog(dialog):
        state.settings.set_operator_options(key, dialog.form.values())


# ======================================================================= dialogs
class CreateTrimDialog(QtWidgets.QDialog):
    def __init__(self, capture, parent=None):
        super().__init__(parent)
        self.capture = capture
        self.setWindowTitle("Create Trim Template")
        self.setMinimumWidth(620)
        layout = QtWidgets.QVBoxLayout(self)
        form = QtWidgets.QFormLayout()
        self.name = QtWidgets.QLineEdit()
        self.tiles = QtWidgets.QCheckBox("Tiles horizontally")
        form.addRow("Trim Preset Name", self.name)
        form.addRow("", self.tiles)
        layout.addLayout(form)
        layout.addWidget(QtWidgets.QLabel(
            f"{capture['source_object']}: {len(capture['trims'])} trims (faces). "
            "Mesh geometry mapped to 0-1; ordered top to bottom, left to right."))
        table = QtWidgets.QTableWidget(len(capture["trims"]), 4)
        table.setHorizontalHeaderLabels(["Trim", "Position (U, V)", "Size (UV)", "Size (cm)"])
        table.setEditTriggers(QtWidgets.QAbstractItemView.NoEditTriggers)
        table.horizontalHeader().setStretchLastSection(True)
        for row, trim in enumerate(capture["trims"]):
            cells = [str(row + 1), ", ".join(f"{v:.4f}" for v in trim["position"]),
                     " x ".join(f"{v:.4f}" for v in trim["scale"]),
                     " x ".join(f"{v:.4f}" for v in trim["dimensions"])]
            for col, text in enumerate(cells):
                table.setItem(row, col, QtWidgets.QTableWidgetItem(text))
        layout.addWidget(table)
        self.error = QtWidgets.QLabel()
        self.error.setStyleSheet("color: #e6a23c;")
        layout.addWidget(self.error)
        self.buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Ok
                                                  | QtWidgets.QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        self.name.textChanged.connect(self._validate)
        self._validate()

    def _validate(self):
        message = trimpreset.name_error(self.name.text(), [p["name"] for p in state.library.trims],
                                        state.trim_dir())
        self.error.setText(message)
        self.buttons.button(QtWidgets.QDialogButtonBox.Ok).setEnabled(not message)


class AutomationBuilder(QtWidgets.QDialog):
    """Compose UV blocks and ordered steps, then save them as a preset file."""

    def __init__(self, existing=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Automation Preset Builder")
        self.setMinimumSize(820, 520)
        self.existing_id = existing["id"] if existing else None
        self.blocks = auto.to_blocks(existing) if existing else []
        self.saved = None
        self._form = None

        root = QtWidgets.QVBoxLayout(self)
        top = QtWidgets.QFormLayout()
        self.name = QtWidgets.QLineEdit(existing["name"] if existing else "")
        top.addRow("Preset Name", self.name)
        root.addLayout(top)
        columns = QtWidgets.QHBoxLayout()
        root.addLayout(columns, 1)

        # UV blocks
        left = QtWidgets.QVBoxLayout()
        left.addWidget(QtWidgets.QLabel("UV sets to affect (processed top to bottom)"))
        self.block_list = QtWidgets.QListWidget()
        left.addWidget(self.block_list, 1)
        left.addLayout(self._buttons(("Add UV Set", self._add_block), ("Up", lambda: self._move_block(-1)),
                                     ("Down", lambda: self._move_block(1)), ("Delete", self._delete_block)))
        columns.addLayout(left, 1)

        # steps
        middle = QtWidgets.QVBoxLayout()
        middle.addWidget(QtWidgets.QLabel("Steps (run top to bottom)"))
        self.step_list = QtWidgets.QListWidget()
        middle.addWidget(self.step_list, 1)
        self.add_step = QtWidgets.QToolButton()
        self.add_step.setText("Add Step")
        self.add_step.setPopupMode(QtWidgets.QToolButton.InstantPopup)
        menu = QtWidgets.QMenu(self.add_step)
        for group, keys in auto.ACTION_GROUPS:
            sub = menu.addMenu(group)
            for key in keys:
                sub.addAction(auto.ACTIONS[key], lambda k=key: self._add_step(k))
        self.add_step.setMenu(menu)
        row = QtWidgets.QHBoxLayout()
        row.addWidget(self.add_step)
        for text, callback in (("Up", lambda: self._move_step(-1)), ("Down", lambda: self._move_step(1)),
                               ("Delete", self._delete_step)):
            button = QtWidgets.QPushButton(text)
            button.clicked.connect(lambda *_, cb=callback: cb())
            row.addWidget(button)
        middle.addLayout(row)
        columns.addLayout(middle, 1)

        # settings
        right = QtWidgets.QVBoxLayout()
        self.settings_title = QtWidgets.QLabel("Action Settings")
        self.settings_title.setStyleSheet("font-weight: bold;")
        right.addWidget(self.settings_title)
        self.settings_holder = QtWidgets.QVBoxLayout()
        right.addLayout(self.settings_holder)
        right.addStretch(1)
        columns.addLayout(right, 1)

        self.error = QtWidgets.QLabel()
        self.error.setStyleSheet("color: #e6a23c;")
        self.error.setWordWrap(True)
        root.addWidget(self.error)
        root.addWidget(QtWidgets.QLabel("Adding steps does not run them or change your scene."))
        buttons = QtWidgets.QDialogButtonBox(QtWidgets.QDialogButtonBox.Save | QtWidgets.QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._save)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        self.block_list.currentRowChanged.connect(self._block_changed)
        self.block_list.itemChanged.connect(self._block_renamed)
        self.step_list.currentRowChanged.connect(self._step_changed)
        self._fill_blocks(0)

    @staticmethod
    def _buttons(*items):
        row = QtWidgets.QHBoxLayout()
        for text, callback in items:
            button = QtWidgets.QPushButton(text)
            button.clicked.connect(lambda *_, cb=callback: cb())
            row.addWidget(button)
        return row

    # ---- blocks
    def _fill_blocks(self, select):
        with block_signals(self.block_list):
            self.block_list.clear()
            for index, block in enumerate(self.blocks, 1):
                item = QtWidgets.QListWidgetItem(block["uv_map"])
                item.setFlags(item.flags() | QtCore.Qt.ItemIsEditable)
                self.block_list.addItem(item)
        if self.blocks:
            self.block_list.setCurrentRow(max(0, min(select, len(self.blocks) - 1)))
        self._block_changed(self.block_list.currentRow())

    def _current_block(self):
        row = self.block_list.currentRow()
        return self.blocks[row] if 0 <= row < len(self.blocks) else None

    def _add_block(self):
        used = {b["uv_map"] for b in self.blocks}
        index = 1
        while f"map{index}" in used:
            index += 1
        self.blocks.append({"uv_map": f"map{index}", "steps": []})
        self._fill_blocks(len(self.blocks) - 1)

    def _move_block(self, direction):
        row = self.block_list.currentRow()
        target = row + direction
        if 0 <= row < len(self.blocks) and 0 <= target < len(self.blocks):
            self.blocks[row], self.blocks[target] = self.blocks[target], self.blocks[row]
            self._fill_blocks(target)

    def _delete_block(self):
        row = self.block_list.currentRow()
        if 0 <= row < len(self.blocks):
            del self.blocks[row]
            self._fill_blocks(row)

    def _block_renamed(self, item):
        row = self.block_list.row(item)
        if 0 <= row < len(self.blocks):
            self.blocks[row]["uv_map"] = item.text().strip() or self.blocks[row]["uv_map"]

    def _block_changed(self, _row):
        self._fill_steps(0)

    # ---- steps
    def _fill_steps(self, select):
        block = self._current_block()
        with block_signals(self.step_list):
            self.step_list.clear()
            for index, step in enumerate(block["steps"] if block else [], 1):
                self.step_list.addItem(f"{index}.  {auto.ACTIONS[step['action']]}")
        if block and block["steps"]:
            self.step_list.setCurrentRow(max(0, min(select, len(block["steps"]) - 1)))
        self._step_changed(self.step_list.currentRow())

    def _current_step(self):
        block = self._current_block()
        row = self.step_list.currentRow()
        return block["steps"][row] if block and 0 <= row < len(block["steps"]) else None

    def _add_step(self, key):
        block = self._current_block()
        if block is None:
            self.error.setText("Add a UV set first.")
            return
        self.error.setText("")
        block["steps"].append({"action": key, "settings": auto.default_settings(key, block["uv_map"])})
        self._fill_steps(len(block["steps"]) - 1)

    def _move_step(self, direction):
        block, row = self._current_block(), self.step_list.currentRow()
        if block and 0 <= row < len(block["steps"]) and 0 <= row + direction < len(block["steps"]):
            steps = block["steps"]
            steps[row], steps[row + direction] = steps[row + direction], steps[row]
            self._fill_steps(row + direction)

    def _delete_step(self):
        block, row = self._current_block(), self.step_list.currentRow()
        if block and 0 <= row < len(block["steps"]):
            del block["steps"][row]
            self._fill_steps(row)

    def _step_changed(self, _row):
        while self.settings_holder.count():
            item = self.settings_holder.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._form = None
        step = self._current_step()
        if step is None:
            self.settings_title.setText("Action Settings")
            return
        self.settings_title.setText("Action Settings: " + auto.ACTIONS[step["action"]])
        names = auto.setting_fields(step["action"])
        if not names:
            self.settings_holder.addWidget(QtWidgets.QLabel("This action has no configurable settings."))
            return
        self._form = FieldForm(names, step["settings"])
        self._form.changed.connect(self._store_settings)
        self.settings_holder.addWidget(self._form)

    def _store_settings(self):
        step = self._current_step()
        if step is not None and self._form is not None:
            step["settings"].update(self._form.values())

    # ---- save
    def _save(self):
        self._store_settings()
        try:
            self.saved = auto.save(state.automation_dir(), self.name.text(), self.blocks,
                                   self.existing_id, state.library.trims)
        except (OSError, ValueError, TypeError, KeyError) as exc:
            self.error.setText(f"Could not save preset: {exc}")
            return
        self.accept()



class RunPresetDialog(QtWidgets.QDialog):
    """Per-step settings of a preset run, replayed from the original state.

    Same idea as Blender's "Run Automation Preset" adjustment panel: the preset
    runs once with its saved settings; changing a value and pressing Replay
    undoes that run and runs again with the new values.  The saved preset file
    is never modified.
    """

    def __init__(self, preset, run_callback, parent=None):
        super().__init__(parent)
        self.preset = preset
        self.run_callback = run_callback
        self._ran = False
        self._forms = []     # (block index, step index, FieldForm)
        self.setWindowTitle("Run Automation Preset on Selected")
        self.setMinimumWidth(380)
        self.resize(400, 680)
        layout = QtWidgets.QVBoxLayout(self)
        title = QtWidgets.QLabel("<b>%s</b>" % preset["name"])
        layout.addWidget(title)
        note = QtWidgets.QLabel("Changes replay the run from its original state (the previous run is "
                                "undone first). These adjustments do not change the saved preset.")
        note.setWordWrap(True)
        layout.addWidget(note)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        body = QtWidgets.QWidget()
        column = QtWidgets.QVBoxLayout(body)
        for b_index, block in enumerate(preset["uv_blocks"]):
            heading = QtWidgets.QLabel("<b>%d. %s</b>" % (b_index + 1, block["uv_map"]))
            column.addWidget(heading)
            for s_index, step in enumerate(block["steps"]):
                key = step["action"]
                column.addWidget(QtWidgets.QLabel("%d.%d  %s" % (b_index + 1, s_index + 1, auto.ACTIONS[key])))
                frame = QtWidgets.QFrame()
                frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
                inner = QtWidgets.QVBoxLayout(frame)
                names = auto.setting_fields(key)
                if not names:
                    inner.addWidget(QtWidgets.QLabel("This action has no configurable settings."))
                else:
                    values = auto.normalize_settings(key, step.get("settings", {}), block["uv_map"])
                    form = FieldForm(names, values)
                    form.changed.connect(self._mark_dirty)
                    inner.addWidget(form)
                    self._forms.append((b_index, s_index, form))
                column.addWidget(frame)
        column.addStretch(1)
        scroll.setWidget(body)
        layout.addWidget(scroll, 1)
        self.status = QtWidgets.QLabel("")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        row = QtWidgets.QHBoxLayout()
        self.replay_button = QtWidgets.QPushButton("Replay with Changes")
        self.replay_button.setEnabled(False)
        self.replay_button.clicked.connect(self.replay)
        close = QtWidgets.QPushButton("Close")
        close.clicked.connect(self.close)
        row.addWidget(self.replay_button)
        row.addWidget(close)
        layout.addLayout(row)

    def _mark_dirty(self):
        self.replay_button.setEnabled(True)
        self.status.setText("")

    def build_data(self):
        """The preset with the dialog's values in every step (a copy)."""
        data = copy.deepcopy(self.preset)
        for b_index, s_index, form in self._forms:
            data["uv_blocks"][b_index]["steps"][s_index]["settings"] = form.values()
        return data

    def first_run(self):
        self._ran = bool(self.run_callback(self.build_data()))
        self.replay_button.setEnabled(False)

    def replay(self):
        if self._ran:
            name = cmds.undoInfo(query=True, undoName=True) or ""
            if not name.startswith("TrimSnap Automation"):
                self.status.setText("Cannot replay: something else was done after the run. "
                                    "Undo it first, or close this window and run again.")
                return
            cmds.undo()
        self._ran = bool(self.run_callback(self.build_data()))
        self.replay_button.setEnabled(False)


# ======================================================================= main window
class TrimSnapWindow(MayaQWidgetDockableMixin, QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent=parent)
        self.setObjectName(WINDOW_NAME)
        self.setWindowTitle("TrimSnap")
        self._jobs = []
        self._busy = False
        self._build()
        self.refresh_all()
        self._jobs.append(cmds.scriptJob(event=["SelectionChanged", self._on_selection]))
        self._jobs.append(cmds.scriptJob(event=["SceneOpened", self._on_scene_change]))
        self._jobs.append(cmds.scriptJob(event=["NewSceneOpened", self._on_scene_change]))

    # ------------------------------------------------------------- lifetime
    def _kill_jobs(self):
        for job in self._jobs:
            if cmds.scriptJob(exists=job):
                cmds.scriptJob(kill=job, force=True)
        self._jobs = []

    def closeEvent(self, event):
        self._kill_jobs()
        super().closeEvent(event)

    def dockCloseEventTriggered(self):
        self._kill_jobs()

    def _alive(self):
        try:
            self.objectName()
            return True
        except RuntimeError:
            self._kill_jobs()
            return False

    def _on_selection(self):
        if self._alive() and not self._busy:
            self.refresh_uv_sets()
            self.refresh_visualize()

    def _on_scene_change(self):
        if self._alive():
            self.refresh_all()

    # ------------------------------------------------------------- build
    def _build(self):
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        container = QtWidgets.QWidget()
        self.column = QtWidgets.QVBoxLayout(container)
        self.column.setContentsMargins(4, 4, 4, 4)
        self.column.setSpacing(6)
        scroll.setWidget(container)
        outer.addWidget(scroll, 1)

        self._build_uv_sets()
        self._build_unwrap()
        self._build_texel()
        self._build_trim()
        self._build_visualize()
        self._build_automation()
        self.column.addStretch(1)
        self.status = QtWidgets.QLabel("")
        self.status.setWordWrap(True)
        self.status.setContentsMargins(6, 2, 6, 4)
        outer.addWidget(self.status)

    def _section(self, title, expanded=True):
        section = Section(title, expanded)
        self.column.addWidget(section)
        return section

    # ---- UV sets
    def _build_uv_sets(self):
        sec = self._section("UV Sets")
        self.uv_list = QtWidgets.QListWidget()
        self.uv_list.setMaximumHeight(96)
        self.uv_list.itemClicked.connect(self._uv_clicked)
        add = QtWidgets.QToolButton()
        add.setText("+")
        add.setToolTip("Add a UV set (copy of the active one) to the selected meshes")
        add.clicked.connect(lambda *_: self.run(self._add_uv_set))
        remove = QtWidgets.QToolButton()
        remove.setText("-")
        remove.setToolTip("Remove the active UV set from the selected meshes")
        remove.clicked.connect(lambda *_: self.run(self._remove_uv_set))
        sync = QtWidgets.QToolButton()
        sync.setText("Sync")
        sync.setToolTip("Add the active UV set to meshes that miss it")
        sync.clicked.connect(lambda *_: self.run(self._sync_uv_set))
        side = QtWidgets.QVBoxLayout()
        side.addWidget(add)
        side.addWidget(remove)
        side.addWidget(sync)
        side.addStretch(1)
        row = QtWidgets.QHBoxLayout()
        row.addWidget(self.uv_list, 1)
        row.addLayout(side)
        sec.add(row)

    def _paths(self):
        paths = mio.selected_mesh_paths()
        if not paths:
            raise mio.MayaToolError("Select a mesh object")
        return paths

    def _uv_clicked(self, item):
        self.run(self._activate_uv, item.data(QtCore.Qt.UserRole))

    def _activate_uv(self, name):
        for path in self._paths():
            uvsets.activate(path, name)

    def _add_uv_set(self):
        with ops.undo_chunk("TrimSnap Add UV Set"):
            name = uvsets.add_set(self._paths())
        return ops.Result(f"Added UV set {name}")

    def _remove_uv_set(self):
        paths = self._paths()
        name = uvsets.current_name(paths)
        with ops.undo_chunk("TrimSnap Remove UV Set"):
            uvsets.remove_set(paths, name)
        return ops.Result(f"Removed UV set {name}")

    def _sync_uv_set(self):
        paths = self._paths()
        with ops.undo_chunk("TrimSnap Sync UV Sets"):
            uvsets.sync(paths, uvsets.current_name(paths), "SET")
        return ops.Result("Synchronized UV sets")

    def refresh_uv_sets(self):
        try:
            paths = mio.selected_mesh_paths()
            names = uvsets.names_for(paths) if paths else []
            current = uvsets.current_name(paths) if paths else ""
            counts = {n: uvsets.count_with(paths, n) for n in names}
        except Exception:
            return
        with block_signals(self.uv_list):
            self.uv_list.clear()
            if not paths:
                self.uv_list.addItem("Select a mesh object")
                self.uv_list.item(0).setFlags(QtCore.Qt.NoItemFlags)
                return
            for name in names:
                label = name if counts[name] == len(paths) else f"{name}   ({counts[name]}/{len(paths)} meshes)"
                item = QtWidgets.QListWidgetItem(label)
                item.setData(QtCore.Qt.UserRole, name)
                self.uv_list.addItem(item)
                if name == current:
                    self.uv_list.setCurrentItem(item)

    # ---- unwrap
    def _build_unwrap(self):
        sec = self._section("Unwrap")
        mark = QtWidgets.QPushButton("Mark Seam")
        mark.setToolTip("Cut the selected edges (a seam is a UV border in Maya)")
        mark.clicked.connect(lambda *_: self.run(ops.mark_seam, True))
        unmark = QtWidgets.QPushButton("Unmark Seam")
        unmark.setToolTip("Sew the selected edges")
        unmark.clicked.connect(lambda *_: self.run(ops.mark_seam, False))
        sec.add(hbox(mark, unmark))
        for text, func, key, tip in (
                ("Project From View", ops.project_from_view, "PROJECT_FROM_VIEW",
                 "Project the selected faces through the active viewport camera"),
                ("Auto Unwrap", ops.auto_unwrap, "AUTO_UNWRAP",
                 "Angle-based cuts, Unfold3D, stitch compatible islands, then pack"),
                ("Unwrap for Trim", ops.unwrap_for_trim, "UNWRAP_FOR_TRIM",
                 "Unwrap with angle cuts and orient islands for trim sheets")):
            button = QtWidgets.QPushButton(text)
            button.setToolTip(tip)
            button.clicked.connect(lambda *_, f=func: self.run(f))
            sec.add(hbox(button, option_button(lambda k=key, t=text: edit_operator_options(k, t, self))))

    # ---- texel density
    def _build_texel(self):
        sec = self._section("Texel Density")
        s = state.settings
        self.density = QtWidgets.QDoubleSpinBox()
        self.density.setDecimals(2)
        self.density.setRange(0.000001, 1e9)
        self.density.setValue(s.density)
        self.density.valueChanged.connect(lambda v: state.settings.set("density", v))
        self.units = QtWidgets.QComboBox()
        for ident, label in texel.UNIT_LABELS:
            self.units.addItem(label, ident)
        self.units.currentIndexChanged.connect(lambda *_: state.settings.set("units", self.units.currentData()))
        sec.add(hbox(self.density, self.units))
        get = QtWidgets.QPushButton("Get TD")
        get.setToolTip("Read the average texel density of the selected UV islands")
        get.clicked.connect(lambda *_: self.run(ops.get_td))
        set_ = QtWidgets.QPushButton("Set TD")
        set_.setToolTip("Scale the selected UV islands to the target density (each stays centered)")
        set_.clicked.connect(lambda *_: self.run(ops.set_td))
        sec.add(hbox(get, set_))
        form = QtWidgets.QFormLayout()
        self.mode = QtWidgets.QComboBox()
        for ident, label in texel.MODES:
            self.mode.addItem(label, ident)
        self.mode.currentIndexChanged.connect(lambda *_: state.settings.set("mode", self.mode.currentData()))
        self.texture_size = QtWidgets.QComboBox()
        for size in texel.TEXTURE_SIZES:
            self.texture_size.addItem(size, size)
        self.texture_size.currentIndexChanged.connect(
            lambda *_: state.settings.set("texture_size", self.texture_size.currentData()))
        form.addRow("Overall Mode", self.mode)
        form.addRow("Texture Size", self.texture_size)
        sec.add(form)

    def refresh_texel(self):
        s = state.settings
        with block_signals(self.density, self.units, self.mode, self.texture_size):
            self.density.setValue(s.density)
            self.units.setCurrentIndex(max(0, self.units.findData(s.units)))
            self.mode.setCurrentIndex(max(0, self.mode.findData(s.mode)))
            self.texture_size.setCurrentIndex(max(0, self.texture_size.findData(s.texture_size)))

    # ---- trim
    def _build_trim(self):
        sec = self._section("Trim")
        self.preset_combo = QtWidgets.QComboBox()
        self.preset_combo.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.preset_combo.currentIndexChanged.connect(self._preset_changed)
        row = [self.preset_combo]
        for text, tip, callback in (("+", "Create a trim preset from the selected plane", self.create_preset),
                                    ("x", "Delete the selected trim preset file", self.delete_preset),
                                    ("Dir", "Open the trim preset folder", self.open_trim_folder),
                                    ("R", "Reload presets from disk", self.reload_presets)):
            button = QtWidgets.QToolButton()
            button.setText(text)
            button.setToolTip(tip)
            button.clicked.connect(lambda *_, cb=callback: cb())
            row.append(button)
        self.overlay_button = QtWidgets.QToolButton()
        self.overlay_button.setText("Overlay (exp.)")
        self.overlay_button.setCheckable(True)
        self.overlay_button.setToolTip("EXPERIMENTAL: show trim outlines in the UV Editor (may be unstable in some Maya versions)")
        self.overlay_button.toggled.connect(self._overlay_toggled)
        row.append(self.overlay_button)
        sec.add(hbox(*row))

        sec.add(QtWidgets.QLabel("Trim List"))
        self.trim_list = QtWidgets.QListWidget()
        self.trim_list.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.trim_list.setMaximumHeight(140)
        self.trim_list.itemSelectionChanged.connect(self._trim_selection_changed)
        sec.add(self.trim_list)

        sec.add(QtWidgets.QLabel("Trim Settings"))
        self.trim_info = QtWidgets.QLabel("")
        sec.add(self.trim_info)
        self.trim_fields = {}
        grid = QtWidgets.QGridLayout()
        for index, (label, field, axis) in enumerate((("U", "position", 0), ("V", "position", 1),
                                                      ("Width", "scale", 0), ("Height", "scale", 1))):
            edit = QtWidgets.QLineEdit()
            edit.setToolTip("Type a number; '*' means the selected trims differ")
            edit.editingFinished.connect(lambda f=field, a=axis, e=edit: self._bulk_edit(f, a, e.text()))
            self.trim_fields[(field, axis)] = edit
            grid.addWidget(QtWidgets.QLabel(label), index // 2, (index % 2) * 2)
            grid.addWidget(edit, index // 2, (index % 2) * 2 + 1)
        sec.add(grid)
        self.behavior = QtWidgets.QComboBox()
        self.behavior.addItem("*", "MIXED")
        for ident, label in BEHAVIOR_ITEMS:
            self.behavior.addItem(label, ident)
        self.behavior.activated.connect(self._behavior_edit)
        form = QtWidgets.QFormLayout()
        form.addRow("Trim Behavior", self.behavior)
        sec.add(form)

        for text, tip, behavior in (
                ("Hotspot Selected: Horizontal", "Match by height, scale uniformly to a horizontal trim",
                 "HORIZONTAL_TILING"),
                ("Hotspot Selected: Vertical", "Match by width, scale uniformly to a vertical trim",
                 "VERTICAL_TILING"),
                ("Hotspot Selected: Fixed", "Match by aspect ratio then size and stretch to fill", "FIXED")):
            button = QtWidgets.QPushButton(text)
            button.setToolTip(tip)
            button.clicked.connect(lambda *_, b=behavior: self.run(ops.hotspot, b))
            key = {"HORIZONTAL_TILING": "HOTSPOT_HORIZONTAL", "VERTICAL_TILING": "HOTSPOT_VERTICAL",
                   "FIXED": "HOTSPOT_FIXED"}[behavior]
            sec.add(hbox(button, option_button(lambda k=key, t=text: edit_operator_options(k, t, self))))
        trim_button = QtWidgets.QPushButton("Hotspot Selected: Trim Selection")
        trim_button.setToolTip("Map the selected UV islands to exactly one selected trim")
        trim_button.clicked.connect(lambda *_: self.run(self._hotspot_trim))
        sec.add(hbox(trim_button, option_button(
            lambda: edit_operator_options("HOTSPOT_TRIM", "Hotspot Selected: Trim Selection", self))))

    def selected_trim_indices(self):
        return sorted(self.trim_list.row(item) for item in self.trim_list.selectedItems())

    def _hotspot_trim(self):
        indices = self.selected_trim_indices()
        if not indices:
            raise mio.MayaToolError("No trim selected. Select one trim in the Trim List.")
        if len(indices) > 1:
            raise mio.MayaToolError("Multiple trims selected. Select only one trim in the Trim List.")
        return ops.hotspot("FIXED", trim_index=indices[0])

    def refresh_trims(self, keep_selection=True):
        s, lib = state.settings, state.library
        with block_signals(self.preset_combo):
            self.preset_combo.clear()
            self.preset_combo.addItem("(no trim preset)", "NONE")
            for preset in lib.trims:
                self.preset_combo.addItem(preset["name"], preset["id"])
            self.preset_combo.setCurrentIndex(max(0, self.preset_combo.findData(s.trim_preset)))
        with block_signals(self.overlay_button):
            self.overlay_button.setChecked(s.overlay_experimental)
        preset = lib.trim(s.trim_preset)
        wanted = list(s.trim_selected) if keep_selection else [0]
        with block_signals(self.trim_list):
            self.trim_list.clear()
            if preset:
                for index, trim in enumerate(preset["trims"]):
                    self.trim_list.addItem(f"Trim {index + 1}   [{LABELS.get(trim.get('behavior', 'FIXED'), '?')}]")
                for index in wanted or [0]:
                    if 0 <= index < self.trim_list.count():
                        self.trim_list.item(index).setSelected(True)
                if not self.trim_list.selectedItems() and self.trim_list.count():
                    self.trim_list.item(0).setSelected(True)
        self.refresh_trim_settings()

    def refresh_trim_settings(self):
        preset = state.library.trim(state.settings.trim_preset)
        indices = self.selected_trim_indices() if preset else []
        for edit in self.trim_fields.values():
            edit.setEnabled(bool(indices))
        self.behavior.setEnabled(bool(indices))
        if not indices:
            self.trim_info.setText("Select a preset to view its trims." if not preset
                                   else "Select a trim to edit its settings.")
            for edit in self.trim_fields.values():
                edit.setText("")
            return
        self.trim_info.setText(f"{len(indices)} trims selected" if len(indices) > 1 else "")
        trims = [preset["trims"][i] for i in indices if i < len(preset["trims"])]
        for (field, axis), edit in self.trim_fields.items():
            values = [t[field][axis] for t in trims]
            same = all(abs(v - values[0]) <= 1e-7 for v in values)
            edit.setText(format(values[0], ".7g") if same else "*")
        behaviors = {t.get("behavior", "FIXED") for t in trims}
        with block_signals(self.behavior):
            self.behavior.setCurrentIndex(self.behavior.findData(behaviors.pop() if len(behaviors) == 1 else "MIXED"))

    def _preset_changed(self, *_):
        state.settings.set("trim_preset", self.preset_combo.currentData())
        state.settings.set("trim_selected", [0])
        self.refresh_trims(keep_selection=False)
        self._update_overlay()

    def _trim_selection_changed(self):
        state.settings.set("trim_selected", self.selected_trim_indices())
        self.refresh_trim_settings()

    def _overlay_toggled(self, checked):
        state.settings.set("overlay_experimental", bool(checked))
        self._update_overlay()

    def _update_overlay(self):
        try:
            note = overlay.refresh()
        except Exception as exc:
            note = f"Trim overlay failed: {exc}"
        if note:
            self.status.setText(note)

    def _apply_trim_changes(self, builder):
        preset = state.library.trim(state.settings.trim_preset)
        indices = self.selected_trim_indices()
        if preset is None or not indices:
            return
        try:
            changes = {}
            for index in indices:
                trim = preset["trims"][index]
                position, scale = list(trim["position"]), list(trim["scale"])
                behavior = trim.get("behavior", "FIXED")
                position, scale, behavior = builder(position, scale, behavior)
                changes[index] = (position, scale, behavior)
            trimpreset.update_trims(state.trim_dir(), preset["id"], changes)
        except (OSError, ValueError, TypeError, KeyError, IndexError) as exc:
            self.status.setText(f"Could not save trim: {exc}")
        else:
            state.library.reload()
            self.status.setText("")
        self.refresh_trims()
        self._update_overlay()

    def _bulk_edit(self, field, axis, text):
        if text.strip() == "*":
            return

        def build(position, scale, behavior):
            value = float(text)
            (position if field == "position" else scale)[axis] = value
            return position, scale, behavior
        self._apply_trim_changes(build)

    def _behavior_edit(self, _index):
        value = self.behavior.currentData()
        if value == "MIXED":
            return
        self._apply_trim_changes(lambda p, s, b: (p, s, value))

    def create_preset(self):
        try:
            capture = ops.capture_selected_plane()
        except (mio.MayaToolError, ValueError) as exc:
            self.status.setText(str(exc))
            return
        dialog = CreateTrimDialog(capture, self)
        if exec_dialog(dialog):
            try:
                data = ops.create_trim_preset(dialog.name.text(), dialog.tiles.isChecked(), capture)
            except (OSError, ValueError) as exc:
                self.status.setText(str(exc))
                return
            self.status.setText(f"Created {data['name']} with {len(data['trims'])} trims")
            self.refresh_trims(keep_selection=False)
            self._update_overlay()

    def delete_preset(self):
        preset = state.library.trim(state.settings.trim_preset)
        if preset is None:
            return
        answer = QtWidgets.QMessageBox.question(
            self, "Delete Trim Preset", f"Delete the preset '{preset['name']}' from disk?")
        if answer != QtWidgets.QMessageBox.Yes:
            return
        try:
            trimpreset.delete(state.trim_dir(), preset["id"])
        except (OSError, ValueError) as exc:
            self.status.setText(f"Could not delete preset: {exc}")
            return
        state.library.reload()
        state.settings.set("trim_preset", "NONE")
        self.refresh_trims(keep_selection=False)
        self._update_overlay()

    def open_trim_folder(self):
        QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(state.trim_dir())))

    def reload_presets(self):
        state.library.reload()
        self.refresh_trims()
        self.refresh_automation()
        self._update_overlay()

    # ---- visualize
    def _build_visualize(self):
        sec = self._section("Visualize")
        self.debug_path = QtWidgets.QLineEdit(state.settings.custom_debug_path)
        self.debug_path.setPlaceholderText("Custom debug image")
        self.debug_path.editingFinished.connect(
            lambda: state.settings.set("custom_debug_path", self.debug_path.text()))
        browse = QtWidgets.QToolButton()
        browse.setText("...")

        def pick():
            path, _ = QtWidgets.QFileDialog.getOpenFileName(
                self, "Choose a debug image", "", "Images (*.png *.jpg *.jpeg *.tif *.tiff *.tga *.bmp)")
            if path:
                self.debug_path.setText(path)
                state.settings.set("custom_debug_path", path)
        browse.clicked.connect(lambda *_: pick())
        sec.add(hbox(self.debug_path, browse))
        self.custom_button = QtWidgets.QPushButton("Custom Debug Texture")
        self.custom_button.setCheckable(True)
        self.custom_button.clicked.connect(lambda *_: self.run(self._toggle_visual, "CUSTOM"))
        self.checker_button = QtWidgets.QPushButton("UV Checkers Texture")
        self.checker_button.setCheckable(True)
        self.checker_button.clicked.connect(lambda *_: self.run(self._toggle_visual, "CHECKER"))
        sec.add(self.custom_button)
        sec.add(self.checker_button)

    def _toggle_visual(self, mode):
        state.settings.set("custom_debug_path", self.debug_path.text())
        on = visualize.toggle(mode)
        return ops.Result(f"{visualize.MODES[mode][1]} {'on' if on else 'off'}")

    def refresh_visualize(self):
        try:
            custom, checker = visualize.is_active("CUSTOM"), visualize.is_active("CHECKER")
        except Exception:
            custom = checker = False
        with block_signals(self.custom_button, self.checker_button):
            self.custom_button.setChecked(custom)
            self.checker_button.setChecked(checker)

    # ---- automation
    def _build_automation(self):
        sec = self._section("Automation", expanded=False)
        self.auto_combo = QtWidgets.QComboBox()
        self.auto_combo.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Fixed)
        self.auto_combo.currentIndexChanged.connect(
            lambda *_: state.settings.set("automation_preset", self.auto_combo.currentData()))
        row = [self.auto_combo]
        for text, tip, callback in (("+", "New automation preset", lambda: self.edit_automation(False)),
                                    ("Edit", "Edit the selected preset", lambda: self.edit_automation(True)),
                                    ("x", "Delete the selected preset", self.delete_automation),
                                    ("R", "Reload presets", self.reload_presets),
                                    ("Dir", "Open the automation preset folder", self.open_auto_folder)):
            button = QtWidgets.QToolButton()
            button.setText(text)
            button.setToolTip(tip)
            button.clicked.connect(lambda *_, cb=callback: cb())
            row.append(button)
        sec.add(hbox(*row))
        run = QtWidgets.QPushButton("Run Automation Preset on Selected")
        run.setToolTip("Run each UV block and its steps in order on all faces of the selected meshes")
        run.clicked.connect(lambda *_: self.run_automation())
        sec.add(run)

    def refresh_automation(self):
        with block_signals(self.auto_combo):
            self.auto_combo.clear()
            self.auto_combo.addItem("Select Automation Preset", "NONE")
            for preset in state.library.autos:
                steps = sum(len(b["steps"]) for b in preset["uv_blocks"])
                self.auto_combo.addItem(f"{preset['name']}  ({steps} steps)", preset["id"])
            self.auto_combo.setCurrentIndex(max(0, self.auto_combo.findData(state.settings.automation_preset)))

    def edit_automation(self, existing):
        preset = state.library.auto(self.auto_combo.currentData()) if existing else None
        if existing and preset is None:
            self.status.setText("Select an automation preset to edit.")
            return
        dialog = AutomationBuilder(preset, self)
        if exec_dialog(dialog) and dialog.saved:
            state.library.reload()
            state.settings.set("automation_preset", dialog.saved["id"])
            self.refresh_automation()
            self.status.setText(f"Saved automation preset: {dialog.saved['name']}")

    def delete_automation(self):
        preset = state.library.auto(self.auto_combo.currentData())
        if preset is None:
            return
        answer = QtWidgets.QMessageBox.question(
            self, "Delete Automation Preset", f"Delete '{preset['name']}' from disk?")
        if answer == QtWidgets.QMessageBox.Yes:
            try:
                auto.delete(state.automation_dir(), preset["id"])
            except (OSError, ValueError) as exc:
                self.status.setText(str(exc))
                return
            state.library.reload()
            state.settings.set("automation_preset", "NONE")
            self.refresh_automation()

    def open_auto_folder(self):
        QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(state.automation_dir())))

    def run_automation(self):
        preset = state.library.auto(self.auto_combo.currentData())
        if preset is None:
            self.status.setText("Select an available automation preset.")
            return
        old = getattr(self, "_run_dialog", None)
        if old is not None:
            try:
                old.close()
                old.deleteLater()
            except RuntimeError:
                pass
        dialog = RunPresetDialog(preset, self.run_automation_data, maya_main_window())
        self._run_dialog = dialog
        dialog.show()
        dialog.first_run()

    def run_automation_data(self, data):
        """Run preset data on the selection; True when anything may have changed (undoable)."""
        ran = True
        self._busy = True
        try:
            count = runner.run(data)
        except runner.RunError as exc:
            ran = exc.partial
            level = "warning" if exc.partial else "error"
            text = f"Stopped: {exc}. Completed changes remain; use Undo to revert." if exc.partial else str(exc)
            self.report(ops.Result(text, level, False))
        except Exception as exc:
            traceback.print_exc()
            self.report(ops.Result(f"{type(exc).__name__}: {exc}", "error", False))
        else:
            self.report(ops.Result(f"Ran {count} steps from {data['name']} on selected meshes"))
        finally:
            self._busy = False
            self.refresh_all()
        return ran

    # ------------------------------------------------------------- shared
    def report(self, result):
        text = "TrimSnap: " + result.message
        self.status.setText(result.message)
        if result.level == "error":
            om.MGlobal.displayError(text)
        elif result.level == "warning":
            om.MGlobal.displayWarning(text)
        else:
            om.MGlobal.displayInfo(text)

    def run(self, func, *args, **kwargs):
        """Run an operator, report its Result and refresh the panels."""
        self._busy = True
        try:
            result = func(*args, **kwargs)
        except mio.MayaToolError as exc:
            self.report(ops.Result(str(exc), "warning", False))
        except Exception as exc:
            traceback.print_exc()
            self.report(ops.Result(f"{type(exc).__name__}: {exc}", "error", False))
        else:
            if result is not None:
                self.report(result)
        finally:
            self._busy = False
        self.refresh_texel()
        self.refresh_uv_sets()
        self.refresh_visualize()

    def refresh_all(self):
        self.refresh_texel()
        self.refresh_uv_sets()
        self.refresh_trims()
        self.refresh_visualize()
        self.refresh_automation()


_window = None


def show():
    """Open (or raise) the dockable TrimSnap window."""
    global _window
    state.startup()
    if _window is not None:
        try:
            _window.close()
            _window.deleteLater()
        except RuntimeError:
            pass
    if cmds.workspaceControl(WINDOW_NAME + "WorkspaceControl", exists=True):
        cmds.deleteUI(WINDOW_NAME + "WorkspaceControl")
    _window = TrimSnapWindow(parent=maya_main_window())
    _window.show(dockable=True, floating=True, area="right", width=340, height=720)
    try:
        _window._update_overlay()
    except Exception:
        pass
    return _window
