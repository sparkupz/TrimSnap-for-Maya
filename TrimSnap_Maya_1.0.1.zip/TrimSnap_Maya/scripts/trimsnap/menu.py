"""The TrimSnap entry in Maya's main menu bar."""
import maya.cmds as cmds
import maya.mel as mel

MENU_NAME = "TrimSnapMainMenu"


def create():
    remove()
    main_window = mel.eval("$tmp = $gMainWindow")
    cmds.menu(MENU_NAME, label="TrimSnap", parent=main_window, tearOff=True)
    cmds.menuItem(label="Open TrimSnap", parent=MENU_NAME,
                  annotation="Open the TrimSnap window",
                  command="import trimsnap.ui as _ts_ui; _ts_ui.show()")
    cmds.menuItem(divider=True, parent=MENU_NAME)
    cmds.menuItem(label="Reload Presets", parent=MENU_NAME,
                  command="import trimsnap.state as _ts_state; _ts_state.startup()")
    cmds.menuItem(label="Open Preset Folder", parent=MENU_NAME,
                  command="import trimsnap.state as _ts_state, maya.cmds as _c; "
                          "_c.launch(directory=str(_ts_state.user_dir()))")


def remove():
    if cmds.menu(MENU_NAME, exists=True):
        cmds.deleteUI(MENU_NAME)
