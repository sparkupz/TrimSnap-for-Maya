"""Automation presets: versioned JSON recipes made of UV blocks and ordered steps.

The file format is data only (never code) and is compatible with the Blender
edition of TrimSnap, so presets can be shared between both.
"""
import json
import os
import tempfile
import uuid
from pathlib import Path

from . import specs

# action key -> label.  Matches the sidebar order of the tool panels.
ACTIONS = {
    "SELECT_TRIM_PRESET": "Select Trim Preset",
    "AUTO_UNWRAP": "Auto Unwrap",
    "UNWRAP_FOR_TRIM": "Unwrap for Trim",
    "MARK_SEAM": "Mark Seam",
    "UNMARK_SEAM": "Unmark Seam",
    "PROJECT_FROM_VIEW": "Project From View",
    "GET_TD": "Get TD",
    "SET_TD": "Set TD",
    "HOTSPOT_HORIZONTAL": "Hotspot Selected: Horizontal",
    "HOTSPOT_VERTICAL": "Hotspot Selected: Vertical",
    "HOTSPOT_FIXED": "Hotspot Selected: Fixed",
    "HOTSPOT_TRIM": "Hotspot Selected: Trim Selection",
    "UV_CHECKER": "UV Checkers Texture",
    "CUSTOM_DEBUG": "Custom Debug Texture",
    "SELECT_UV_SET": "Select UV Set",
    "ADD_UV_SET": "Add UV Set",
    "REMOVE_UV_SET": "Remove UV Set",
    "SYNC_UV_SETS": "Sync UV Sets",
}
ACTION_GROUPS = (
    ("UV Sets", ("SELECT_UV_SET", "ADD_UV_SET", "REMOVE_UV_SET", "SYNC_UV_SETS")),
    ("Unwrap", ("MARK_SEAM", "UNMARK_SEAM", "PROJECT_FROM_VIEW", "AUTO_UNWRAP", "UNWRAP_FOR_TRIM")),
    ("Texel Density", ("GET_TD", "SET_TD")),
    ("Trim", ("SELECT_TRIM_PRESET", "HOTSPOT_HORIZONTAL", "HOTSPOT_VERTICAL",
              "HOTSPOT_FIXED", "HOTSPOT_TRIM")),
    ("Visualize", ("CUSTOM_DEBUG", "UV_CHECKER")),
)
EXECUTION = {"scope": "selected_mesh_objects", "geometry": "all_visible_faces",
             "missing_uv_maps": "create_from_active",
             "order": "uv_blocks_top_to_bottom_then_steps_top_to_bottom",
             "on_error": "stop"}
FORBIDDEN_NAME_CHARS = '<>:"/\\|?*'
RESERVED = {"CON", "PRN", "AUX", "NUL", "CONIN$", "CONOUT$",
            *(f"{p}{n}" for p in ("COM", "LPT") for n in "123456789")}


def setting_fields(key):
    fields = list(specs.OPERATOR_FIELDS.get(key, ()))
    if key == "SELECT_TRIM_PRESET":
        fields.append("trim_preset")
    elif key == "SET_TD":
        fields += list(specs.TD_FIELDS)
    elif key == "GET_TD":
        fields += ["units", "texture_size"]
    elif key == "CUSTOM_DEBUG":
        fields.append("custom_debug_path")
    elif key.startswith("HOTSPOT_"):
        fields += ["use_active_trim_preset", "trim_preset"]
        if key == "HOTSPOT_TRIM":
            fields.append("trim_number")
    return fields


def default_settings(key, uv_map="map1"):
    result = {}
    for name in setting_fields(key):
        result[name] = uv_map if name == "uv_name" else specs.FIELDS[name]["default"]
    return result


def uv_name_error(name):
    return (not isinstance(name, str) or not name.strip()
            or len(name.encode("utf-8")) > 63 or "\x00" in name)


def normalize_settings(key, values, uv_map):
    """Validated settings for a step with defaults filled in."""
    if not isinstance(values, dict):
        raise ValueError("Step settings must be a JSON object")
    allowed = setting_fields(key)
    unknown = set(values) - set(allowed)
    if unknown:
        raise ValueError(f"Unknown settings for {key}: {', '.join(sorted(unknown))}")
    result = {}
    for name in allowed:
        value = values.get(name, uv_map if name == "uv_name" else specs.FIELDS[name]["default"])
        if name == "trim_preset" and isinstance(value, dict):
            if set(value) - {"id", "name"} or not isinstance(value.get("name", ""), str):
                raise ValueError("Invalid trim preset reference")
            value = value.get("id")
        if not specs.check_value(name, value):
            raise ValueError(f"Invalid {name} for {key}: {value!r}")
        if name == "uv_name" and uv_name_error(value):
            raise ValueError("UV set names must contain 1-63 UTF-8 bytes")
        result[name] = value
    return result


def validate(data):
    if not isinstance(data, dict) or data.get("schema_version") != 1:
        raise ValueError("Unsupported automation preset schema")
    if not isinstance(data.get("id"), str) or not data["id"] or data["id"] == "NONE":
        raise ValueError("Invalid preset ID")
    if type(data.get("enum_id")) is not int or not 0 < data["enum_id"] < 2 ** 31:
        raise ValueError("Invalid preset menu ID")
    if not isinstance(data.get("name"), str) or not data["name"].strip():
        raise ValueError("Preset name is required")
    if data.get("execution") != EXECUTION:
        raise ValueError("Unsupported execution rules")
    blocks = data.get("uv_blocks")
    if not isinstance(blocks, list) or not blocks:
        raise ValueError("Add at least one UV block")
    total = 0
    for block in blocks:
        if not isinstance(block, dict) or uv_name_error(block.get("uv_map")):
            raise ValueError("Invalid UV block name")
        if not isinstance(block.get("steps"), list):
            raise ValueError("UV block steps must be a list")
        for step in block["steps"]:
            if not isinstance(step, dict) or step.get("action") not in ACTIONS:
                raise ValueError("Unknown automation action")
            if set(step) - {"action", "label", "settings"}:
                raise ValueError("Unknown step fields; code is not accepted in presets")
            normalize_settings(step["action"], step.get("settings", {}), block["uv_map"])
            total += 1
    if not total:
        raise ValueError("Add at least one automation step")
    return data


def trim_reference(preset_id, trim_presets):
    name = next((p["name"] for p in trim_presets if p["id"] == preset_id), "")
    return {"id": preset_id, "name": name}


def build(name, blocks, preset_id, enum_id, trim_presets=()):
    """Serializable preset from editor blocks: [{'uv_map', 'steps': [{'action','settings'}]}]."""
    data = {"schema_version": 1, "id": preset_id, "enum_id": enum_id, "name": name,
            "execution": dict(EXECUTION), "uv_blocks": []}
    for block in blocks:
        out = {"uv_map": block["uv_map"], "steps": []}
        for step in block["steps"]:
            key = step["action"]
            values = normalize_settings(key, step["settings"], block["uv_map"])
            if values.get("use_active_trim_preset"):
                values.pop("trim_preset", None)
            if "trim_preset" in values:
                values["trim_preset"] = trim_reference(values["trim_preset"], trim_presets)
            out["steps"].append({"action": key, "label": ACTIONS[key], "settings": values})
        data["uv_blocks"].append(out)
    return validate(data)


def to_blocks(data):
    """Editor-friendly copy of a preset (settings normalized, trim ref collapsed to id)."""
    validate(data)
    return [{"uv_map": b["uv_map"],
             "steps": [{"action": s["action"],
                        "settings": normalize_settings(s["action"], s.get("settings", {}), b["uv_map"])}
                       for s in b["steps"]]}
            for b in data["uv_blocks"]]


# ------------------------------------------------------------------ storage
def name_error(name):
    if not name.strip():
        return "Enter a preset name"
    if name != name.strip() or name.endswith(".") or len((name + ".json").encode("utf-16-le")) > 510:
        return "Invalid preset filename"
    if any(c in FORBIDDEN_NAME_CHARS or ord(c) < 32 for c in name):
        return "Preset names cannot contain filename punctuation or control characters"
    if name.split(".")[0].upper() in RESERVED:
        return "This name is reserved by Windows"
    return ""


def read_file(path):
    def no_constant(value):
        raise ValueError(f"Non-finite JSON number: {value}")
    return validate(json.loads(Path(path).read_text(encoding="utf-8"), parse_constant=no_constant))


def load_all(directory):
    """(presets, paths) loaded from a directory; broken files are skipped with a note."""
    directory = Path(directory)
    loaded, paths, ids, numbers, errors = [], {}, set(), set(), []
    for path in sorted(directory.glob("*.json")) if directory.is_dir() else []:
        try:
            data = read_file(path)
            if data["id"] in ids:
                raise ValueError("Duplicate automation preset ID")
            loaded.append(data)
            paths[data["id"]] = path
            ids.add(data["id"])
            numbers.add(data["enum_id"])
        except (OSError, ValueError, TypeError, KeyError) as exc:
            errors.append(f"{path.name}: {exc}")
    loaded.sort(key=lambda p: p["name"].casefold())
    return loaded, paths, errors


def _atomic_write(path, data, exclusive):
    path = Path(path)
    tmp = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent,
                                         suffix=".tmp", delete=False) as handle:
            tmp = Path(handle.name)
            json.dump(data, handle, indent=2, ensure_ascii=False, allow_nan=False)
            handle.write("\n")
        if exclusive:
            if path.exists():
                raise ValueError("A file with this preset name already exists")
            os.rename(tmp, path)
        else:
            os.replace(tmp, path)
        tmp = None
    finally:
        if tmp is not None and Path(tmp).exists():
            Path(tmp).unlink()


def save(directory, name, blocks, existing_id=None, trim_presets=()):
    """Create or update a preset file; returns the saved data."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    error = name_error(name)
    if error:
        raise ValueError(error)
    presets, paths, _ = load_all(directory)
    if any(p["name"].casefold() == name.casefold() and p["id"] != existing_id for p in presets):
        raise ValueError("An automation preset with this name already exists")
    old = next((p for p in presets if p["id"] == existing_id), None) if existing_id else None
    if old:
        preset_id, enum_id = old["id"], old["enum_id"]
        data = build(name, blocks, preset_id, enum_id, trim_presets)
        target = paths[preset_id]
        if target.stem != name:
            new_path = directory / (name + ".json")
            _atomic_write(new_path, data, exclusive=True)
            target.unlink()
        else:
            _atomic_write(target, data, exclusive=False)
    else:
        preset_id = uuid.uuid4().hex
        enum_id = int(preset_id[:8], 16) % (2 ** 31 - 1) + 1
        taken = {p["enum_id"] for p in presets}
        while enum_id in taken:
            enum_id = enum_id % (2 ** 31 - 1) + 1
        data = build(name, blocks, preset_id, enum_id, trim_presets)
        _atomic_write(directory / (name + ".json"), data, exclusive=True)
    return data


def delete(directory, preset_id):
    _, paths, _ = load_all(directory)
    path = paths.get(preset_id)
    if path is None:
        raise ValueError("Select an available automation preset")
    path.unlink()
