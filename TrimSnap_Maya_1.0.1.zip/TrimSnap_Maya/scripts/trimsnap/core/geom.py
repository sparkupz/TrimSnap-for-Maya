"""Tiny tuple-based vector helpers (no Maya, no numpy)."""
import math

EPS = 1e-6


def sub3(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def add3(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def mul3(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def dot3(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross3(a, b):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def len3(a):
    return math.sqrt(dot3(a, a))


def norm3(a):
    n = len3(a)
    return (0.0, 0.0, 0.0) if n < 1e-30 else (a[0] / n, a[1] / n, a[2] / n)


def sub2(a, b):
    return (a[0] - b[0], a[1] - b[1])


def add2(a, b):
    return (a[0] + b[0], a[1] + b[1])


def mul2(a, s):
    return (a[0] * s, a[1] * s)


def dot2(a, b):
    return a[0] * b[0] + a[1] * b[1]


def cross2(a, b):
    return a[0] * b[1] - a[1] * b[0]


def len2(a):
    return math.hypot(a[0], a[1])


def rotate2(p, center, cos_a, sin_a):
    """Rotate p about center by the angle whose cosine/sine are given."""
    x, y = p[0] - center[0], p[1] - center[1]
    return (center[0] + cos_a * x - sin_a * y, center[1] + sin_a * x + cos_a * y)


def centroid2(points):
    points = list(points)
    n = len(points)
    return (sum(p[0] for p in points) / n, sum(p[1] for p in points) / n)


def bounds2(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return (min(xs), min(ys)), (max(xs), max(ys))


def triangles_overlap(a, b, eps=EPS):
    """Strict interior intersection of two 2D triangles (touching is allowed)."""
    for tri in (a, b):
        for k in range(3):
            p, q = tri[k], tri[(k + 1) % 3]
            ex, ey = q[0] - p[0], q[1] - p[1]
            axis = (-ey, ex)
            length = math.hypot(*axis)
            if length == 0:
                continue
            axis = (axis[0] / length, axis[1] / length)
            pa = [dot2(v, axis) for v in a]
            pb = [dot2(v, axis) for v in b]
            if min(max(pa), max(pb)) - max(min(pa), min(pb)) <= eps:
                return False
    return True
