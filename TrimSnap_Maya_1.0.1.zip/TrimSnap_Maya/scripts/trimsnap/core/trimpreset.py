"""Trim presets: capture from a planar mesh, JSON storage and trim editing."""
import copy
import json
import math
import os
import tempfile
import uuid
from pathlib import Path

from .geom import cross3, dot3, len3, norm3, sub3
from .automation import FORBIDDEN_NAME_CHARS, RESERVED

BEHAVIORS = ("HORIZONTAL_TILING", "VERTICAL_TILING", "FIXED")


def named_trims(trims):
    """Number trims in list order; mesh provenance is kept as source_face_index."""
    result = []
    for index, trim in enumerate(trims, 1):
        entry = {"name": f"Trim {index}", "trim_index": index}
        entry.update({k: v for k, v in trim.items()
                      if k not in {"name", "trim_index", "face_index", "source_face_index"}})
        source = trim.get("source_face_index", trim.get("face_index"))
        if source is not None:
            entry["source_face_index"] = source
        result.append(entry)
    return result


def capture_plane(name, points, faces, transform_dir=lambda v: v):
    """Normalise a flat polygon mesh to a 0-1 trim sheet.

    `points` are object-space, `faces` lists of vertex ids, and `transform_dir`
    maps an object-space direction to world space (for real-size dimensions).
    Trims are ordered top-to-bottom, then left-to-right.
    """
    if not faces:
        raise ValueError("The selected mesh has no faces")
    verts = sorted({v for f in faces for v in f})
    origin = points[faces[0][0]]
    extent = max(len3(sub3(points[v], origin)) for v in verts)

    def area_vector(face):
        p0 = points[face[0]]
        total = (0.0, 0.0, 0.0)
        for k in range(1, len(face) - 1):
            c = cross3(sub3(points[face[k]], p0), sub3(points[face[k + 1]], p0))
            total = (total[0] + c[0], total[1] + c[1], total[2] + c[2])
        return total

    areas = [len3(area_vector(f)) * 0.5 for f in faces]
    if extent <= 1e-12 or any(a <= extent * extent * 1e-12 for a in areas):
        raise ValueError("The plane contains zero-area faces")
    normal = norm3(area_vector(faces[areas.index(max(areas))]))
    if any(abs(dot3(sub3(points[v], origin), normal)) > extent * 1e-6 for v in verts):
        raise ValueError("Select a flat plane; this mesh is not planar")
    dominant = max(range(3), key=lambda i: abs(normal[i]))
    if normal[dominant] < 0:
        normal = (-normal[0], -normal[1], -normal[2])
    ref = (1.0, 0.0, 0.0) if abs(normal[0]) < 0.9 else (0.0, 1.0, 0.0)
    d = dot3(ref, normal)
    axis_u = norm3(sub3(ref, (normal[0] * d, normal[1] * d, normal[2] * d)))
    axis_v = norm3(cross3(normal, axis_u))
    coords = {v: (dot3(sub3(points[v], origin), axis_u), dot3(sub3(points[v], origin), axis_v))
              for v in verts}
    lo = [min(c[i] for c in coords.values()) for i in range(2)]
    span = [max(c[i] for c in coords.values()) - lo[i] for i in range(2)]
    if min(span) <= extent * 1e-9:
        raise ValueError("The plane must have nonzero width and height")
    wu, wv = transform_dir(axis_u), transform_dir(axis_v)
    if len3(cross3(wu, wv)) <= 1e-12:
        raise ValueError("The plane has zero scale")
    dimensions = [len3(wu) * span[0], len3(wv) * span[1]]
    trims = []
    for index, face in enumerate(faces):
        uv = [[min(1.0, max(0.0, (coords[v][i] - lo[i]) / span[i])) for i in range(2)] for v in face]
        position = [min(p[i] for p in uv) for i in range(2)]
        scale = [max(p[i] for p in uv) - position[i] for i in range(2)]
        face_span = [max(coords[v][i] for v in face) - min(coords[v][i] for v in face) for i in range(2)]
        trims.append({"face_index": index, "position": position, "scale": scale,
                      "behavior": "FIXED", "vertices": uv,
                      "dimensions": [face_span[i] / span[i] * dimensions[i] for i in range(2)]})
    trims.sort(key=lambda t: (-round(t["position"][1] + t["scale"][1], 6),
                              round(t["position"][0], 6), t["face_index"]))
    return {"source_object": name, "plane_dimensions": dimensions,
            "coordinate_space": "normalized_plane", "position_origin": "lower_left",
            "trims": named_trims(trims)}


# ------------------------------------------------------------------ storage
def name_error(name, existing_names=(), directory=None):
    if not name.strip():
        return "Enter a Trim Preset Name"
    if name != name.strip() or name.endswith("."):
        return "Preset names cannot start/end with whitespace or end with a period"
    if any(c in FORBIDDEN_NAME_CHARS or ord(c) < 32 for c in name):
        return 'Preset names cannot contain filename characters: < > : " / \\ | ? *'
    if name.split(".")[0].rstrip().upper() in RESERVED:
        return "This preset name is reserved by Windows; choose another name"
    if len((name + ".json").encode("utf-16-le")) // 2 > 255:
        return "The preset name is too long for a filename"
    if any(n.casefold() == name.casefold() for n in existing_names):
        return "A preset with this name already exists"
    if directory is not None and Path(directory).is_dir() and any(
            p.name.casefold() == (name + ".json").casefold() for p in Path(directory).iterdir()):
        return "A file with this preset name already exists"
    return ""


def valid_preset(data):
    return (isinstance(data, dict) and data.get("schema_version") == 1
            and isinstance(data.get("name"), str) and data["name"].strip()
            and isinstance(data.get("id"), str)
            and isinstance(data.get("enum_id"), int) and 0 < data["enum_id"] < 2 ** 31
            and isinstance(data.get("trims"), list))


def load_all(directory):
    """(presets, paths, errors) from a directory of preset JSON files."""
    directory = Path(directory)
    loaded, paths, errors = [], {}, []
    for path in sorted(directory.glob("*.json")) if directory.is_dir() else []:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not valid_preset(data):
                raise ValueError("Invalid preset metadata")
            if any(p["id"] == data["id"] for p in loaded):   # menu ids may repeat across files
                raise ValueError("Duplicate preset ID")
            loaded.append(data)
            paths[data["id"]] = path
        except (OSError, ValueError, KeyError, TypeError) as exc:
            errors.append(f"{path.name}: {exc}")
    loaded.sort(key=lambda p: p["name"].casefold())
    return loaded, paths, errors


def _write_json(path, data, exclusive):
    path = Path(path)
    tmp = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent,
                                         suffix=".tmp", delete=False) as handle:
            tmp = Path(handle.name)
            json.dump(data, handle, indent=2, allow_nan=False)
            handle.write("\n")
        if exclusive:
            if path.exists():
                raise ValueError("A file with this preset name already exists")
            os.rename(tmp, path)
        else:
            os.replace(tmp, path)
        tmp = None
    finally:
        if tmp is not None and Path(tmp).exists():
            Path(tmp).unlink()


def save_new(directory, name, tiles_horizontally, capture):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    presets, _, _ = load_all(directory)
    error = name_error(name, [p["name"] for p in presets], directory)
    if error:
        raise ValueError(error)
    data = dict(capture, schema_version=1, id=uuid.uuid4().hex,
                enum_id=max((p["enum_id"] for p in presets), default=0) + 1,
                name=name, tiles_horizontally=bool(tiles_horizontally))
    data["trims"] = named_trims(data["trims"])
    _write_json(directory / (name + ".json"), data, exclusive=True)
    return data


def delete(directory, preset_id):
    _, paths, _ = load_all(directory)
    path = paths.get(preset_id)
    if path is None:
        raise ValueError("This preset is no longer available")
    path.unlink()


def update_trims(directory, preset_id, changes):
    """Save new bounds/behavior for trims: changes = {index: (position, scale, behavior|None)}.

    The saved polygon is remapped to the new bounds.  Returns the updated preset.
    """
    presets, paths, _ = load_all(directory)
    preset = next((p for p in presets if p["id"] == preset_id), None)
    if preset is None or any(not 0 <= i < len(preset["trims"]) for i in changes):
        raise ValueError("The selected preset is no longer available")
    updated = copy.deepcopy(preset)
    for index, (position, scale, behavior) in changes.items():
        position, scale = list(position), list(scale)
        if not all(math.isfinite(v) for v in position + scale):
            raise ValueError("Values must be finite")
        if any(p < 0 or s <= 0 or p + s > 1.000001 for p, s in zip(position, scale)):
            raise ValueError("Position + size must fit within 0-1")
        trim = updated["trims"][index]
        behavior = behavior or trim.get("behavior", "FIXED")
        if behavior not in BEHAVIORS:
            raise ValueError("Invalid trim behavior")
        trim["behavior"] = behavior
        old_p, old_s = trim["position"], trim["scale"]
        if any(v <= 0 for v in old_s):
            raise ValueError("Cannot resize a zero-size trim")
        if "vertices" in trim:
            trim["vertices"] = [[position[i] + (vert[i] - old_p[i]) * scale[i] / old_s[i]
                                 for i in range(2)] for vert in trim["vertices"]]
        if "dimensions" in trim:
            trim["dimensions"] = [trim["dimensions"][i] * scale[i] / old_s[i] for i in range(2)]
        trim["position"], trim["scale"] = position, scale
    updated["trims"] = named_trims(updated["trims"])
    _write_json(paths[preset_id], updated, exclusive=False)
    return updated


def trim_geometry(trim):
    """(polygon points, centroid) of a trim; older bounds-only records still work."""
    points = trim.get("vertices")
    if points is None:
        u, v = trim["position"]
        w, h = trim["scale"]
        points = [(u, v), (u + w, v), (u + w, v + h), (u, v + h)]
    points = [(float(p[0]), float(p[1])) for p in points]
    if len(points) < 3 or not all(math.isfinite(v) for p in points for v in p):
        raise ValueError("Invalid trim polygon")
    pairs = list(zip(points, points[1:] + points[:1]))
    cross = [a[0] * b[1] - b[0] * a[1] for a, b in pairs]
    area2 = sum(cross)
    if abs(area2) > 1e-12:
        center = tuple(sum((a[i] + b[i]) * c for (a, b), c in zip(pairs, cross)) / (3 * area2)
                       for i in range(2))
    else:
        center = tuple((min(p[i] for p in points) + max(p[i] for p in points)) / 2 for i in range(2))
    return points, center
