"""Setting schemas shared by operators, option dialogs and automation presets.

Angles are stored in radians so preset files stay compatible with the Blender
edition of the tool.  Everything here is plain data.
"""
import math

INT_MAX = 2 ** 31 - 1


def Float(default, lo=-math.inf, hi=math.inf, label="", angle=False, step=0.01, decimals=4):
    return dict(type="float", default=default, min=lo, max=hi, label=label,
                angle=angle, step=step, decimals=decimals)


def Int(default, lo=-INT_MAX, hi=INT_MAX, label=""):
    return dict(type="int", default=default, min=lo, max=hi, label=label)


def Bool(default, label=""):
    return dict(type="bool", default=default, label=label)


def Enum(default, items, label=""):
    return dict(type="enum", default=default, items=list(items), label=label)


def Str(default="", label="", kind="text"):
    return dict(type="string", default=default, label=label, kind=kind)


ORIENTATIONS = [("WORLD", "Orient to World"),
                ("LONGEST_HORIZONTAL", "Orient Longest Edge Horizontally"),
                ("LONGEST_VERTICAL", "Orient Longest Edge Vertically")]

FIELDS = {
    # unwrap
    "angle_threshold": Float(math.radians(60), 0.0, math.pi, "Angle Threshold", angle=True),
    "respect_existing_seams": Bool(True, "Respect Existing Seams"),
    "mark_resulting_seams": Bool(True, "Mark Resulting Seams"),
    "prioritize_world_orientation": Bool(False, "Prioritize World Orientation"),
    "orientation": Enum("WORLD", ORIENTATIONS, "Orientation"),
    "stitch_concave_face_pairs": Bool(False, "Stitch Concave Face Pairs"),
    # project from view
    "orthographic": Bool(False, "Orthographic"),
    "camera_bounds": Bool(True, "Camera Bounds"),
    "correct_aspect": Bool(True, "Correct Aspect"),
    "clip_to_bounds": Bool(False, "Clip to Bounds"),
    "scale_to_bounds": Bool(False, "Scale to Bounds"),
    # hotspot
    "island_scale_multiplier": Float(1.0, 0.0001, 1e6, "Trim Matching Multiplier", decimals=3),
    "island_offset": Float(0.0, -1e6, 1e6, "Island Inset", decimals=4, step=0.001),
    "allow_horizontal_flip": Bool(False, "Allow Horizontal Flip"),
    "allow_vertical_flip": Bool(False, "Allow Vertical Flip"),
    "random_seed": Int(-1, -1, INT_MAX, "Random Seed (-1 = new each run)"),
    "axis_offset_randomization": Float(0.0, 0.0, 1e6, "Axis Offset Randomization", decimals=4),
    "use_active_trim_preset": Bool(True, "Use Active Trim Preset"),
    "trim_preset": Str("NONE", "Trim Preset", kind="trim_preset"),
    "trim_number": Int(1, 1, INT_MAX, "Trim Number"),
    # texel density
    "density": Float(1024.0, 1e-6, 1e9, "Texel Density", decimals=2),
    "units": Enum("M", [("M", "px / m"), ("CM", "px / cm"), ("IN", "px / in"), ("FT", "px / ft")], "Units"),
    "mode": Enum("AVERAGE", [("AVERAGE", "Average"), ("INDIVIDUAL", "Individual")], "Overall Mode"),
    "texture_size": Enum("1024", [(str(n), str(n)) for n in (64, 128, 256, 512, 1024, 2048, 4096, 8192)],
                         "Texture Size"),
    # uv sets / visualize
    "uv_name": Str("map1", "UV Set"),
    "scope": Enum("SET", [("SET", "This UV Set"), ("ALL", "All UV Sets")], "Sync"),
    "custom_debug_path": Str("", "Debug Image", kind="file"),
}

HOTSPOT_FIELDS = ("island_scale_multiplier", "island_offset", "allow_horizontal_flip",
                  "allow_vertical_flip", "random_seed")

# Operator options (shown in each tool's options dialog and stored in automation steps).
OPERATOR_FIELDS = {
    "AUTO_UNWRAP": ("angle_threshold", "prioritize_world_orientation",
                    "respect_existing_seams", "mark_resulting_seams"),
    "UNWRAP_FOR_TRIM": ("angle_threshold", "orientation", "stitch_concave_face_pairs",
                        "respect_existing_seams"),
    "PROJECT_FROM_VIEW": ("orthographic", "camera_bounds", "correct_aspect",
                          "clip_to_bounds", "scale_to_bounds"),
    "HOTSPOT_HORIZONTAL": HOTSPOT_FIELDS + ("axis_offset_randomization",),
    "HOTSPOT_VERTICAL": HOTSPOT_FIELDS + ("axis_offset_randomization",),
    "HOTSPOT_FIXED": HOTSPOT_FIELDS,
    "HOTSPOT_TRIM": HOTSPOT_FIELDS[1:],
    "SELECT_UV_SET": ("uv_name",),
    "REMOVE_UV_SET": ("uv_name",),
    "SYNC_UV_SETS": ("uv_name", "scope"),
}
TD_FIELDS = ("density", "units", "mode", "texture_size")


def default_values(names):
    return {n: FIELDS[n]["default"] for n in names}


def check_value(name, value):
    """True when `value` is valid for field `name` (strict about bool/int/float)."""
    spec = FIELDS[name]
    kind = spec["type"]
    if kind == "bool":
        return type(value) is bool
    if kind == "int":
        return type(value) is int and spec["min"] <= value <= spec["max"]
    if kind == "float":
        return (type(value) in (int, float) and math.isfinite(value)
                and spec["min"] <= value <= spec["max"])
    if kind == "string":
        return isinstance(value, str) and "\x00" not in value
    if kind == "enum":
        return isinstance(value, str) and value in [i[0] for i in spec["items"]]
    return False


def coerce(name, value):
    """Best-effort conversion for UI input; falls back to the default."""
    spec = FIELDS[name]
    try:
        if spec["type"] == "bool":
            value = bool(value)
        elif spec["type"] == "int":
            value = int(value)
        elif spec["type"] == "float":
            value = float(value)
        elif spec["type"] == "string":
            value = str(value)
    except (TypeError, ValueError):
        return spec["default"]
    return value if check_value(name, value) else spec["default"]
