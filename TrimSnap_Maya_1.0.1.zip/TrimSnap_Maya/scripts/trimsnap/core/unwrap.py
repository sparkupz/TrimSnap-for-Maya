"""Post-processing of unfolded charts: orientation, stitching and packing.

A *chart* is a ``{corner: (u, v)}`` dict covering the corners of one UV island.
All functions are pure; Maya only supplies the mesh and the unfolded values.
"""
import math

from .geom import (EPS, bounds2, centroid2, cross2, cross3, dot3, len2, len3,
                   rotate2, sub2, sub3, triangles_overlap)


# ---------------------------------------------------------------- chart building
def result_charts(mesh, faces, values, tol=1e-6):
    """Split `faces` into charts joined by edges whose UVs coincide at both ends."""
    pending = set(faces)
    charts = []
    while pending:
        stack = [pending.pop()]
        chart = {}
        while stack:
            f = stack.pop()
            for i in range(len(mesh.faces[f])):
                chart[(f, i)] = values[(f, i)]
            for key in mesh.face_edge_keys(f):
                pair = mesh.manifold_pair(key)
                if pair is None:
                    continue
                mine = pair[0] if pair[0][0] == f else pair[1]
                theirs = pair[1] if mine is pair[0] else pair[0]
                g = theirs[0]
                if g not in pending:
                    continue
                if all(len2(sub2(values[mesh.corner_at(mine, v)],
                                 values[mesh.corner_at(theirs, v)])) <= tol
                       for v in key):
                    pending.discard(g)
                    stack.append(g)
        charts.append(chart)
    return charts


def signed_uv_area(mesh, chart):
    total = 0.0
    for f in {c[0] for c in chart}:
        for a, b, c in mesh.fan(f):
            p, q, r = chart[(f, a)], chart[(f, b)], chart[(f, c)]
            total += cross2(sub2(q, p), sub2(r, p)) * 0.5
    return total


def fix_winding(mesh, charts):
    """Mirror charts that came back flipped so UV winding matches the mesh."""
    for chart in charts:
        if signed_uv_area(mesh, chart) < 0:
            (lo, _), (hi, _) = bounds2(chart.values())
            axis = lo + hi
            for k, (u, v) in chart.items():
                chart[k] = (axis - u, v)


def world_rescale(mesh, charts):
    """Scale each chart so UV area is proportional to world area (uniform density)."""
    for chart in charts:
        uv_area = abs(signed_uv_area(mesh, chart))
        world = mesh.world_area({c[0] for c in chart})
        if uv_area <= 1e-20 or world <= 0:
            continue
        factor = math.sqrt(world / uv_area)
        center = centroid2(chart.values())
        for k, (u, v) in chart.items():
            chart[k] = (center[0] + (u - center[0]) * factor,
                        center[1] + (v - center[1]) * factor)


def _rotate_chart(chart, angle):
    cos_a, sin_a = math.cos(angle), math.sin(angle)
    center = centroid2(chart.values())
    for k, p in chart.items():
        chart[k] = rotate2(p, center, cos_a, sin_a)


# ---------------------------------------------------------------- orientation
def orient_world(mesh, charts, up=(0.0, 1.0, 0.0), flat_up=(0.0, 0.0, -1.0)):
    """Rotate charts so world `up` points to +V (`flat_up` for floors/ceilings).

    The height gradient of every triangle is measured in UV space and the
    area-weighted mean is rotated onto +V, so curved charts get a best fit.
    """
    for chart in charts:
        faces = {c[0] for c in chart}
        normal = (0.0, 0.0, 0.0)
        for f in faces:
            a = mesh.face_vector_area(f)
            normal = (normal[0] + a[0], normal[1] + a[1], normal[2] + a[2])
        n_len = len3(normal)
        if n_len < 1e-20:
            continue
        reference = flat_up if abs(dot3(normal, up)) / n_len > 0.999 else up
        total = (0.0, 0.0)
        fallback, largest = None, 0.0
        for f in faces:
            verts = mesh.faces[f]
            for a, b, c in mesh.fan(f):
                pa, pb, pc = (mesh.points[verts[k]] for k in (a, b, c))
                e1, e2 = sub3(pb, pa), sub3(pc, pa)
                weight = len3(cross3(e1, e2))
                if weight < 1e-20:
                    continue
                d1 = sub2(chart[(f, b)], chart[(f, a)])
                d2 = sub2(chart[(f, c)], chart[(f, a)])
                det = cross2(d1, d2)
                if abs(det) < 1e-20:
                    continue
                h1, h2 = dot3(e1, reference), dot3(e2, reference)
                gx = (h1 * d2[1] - h2 * d1[1]) / det
                gy = (d1[0] * h2 - d2[0] * h1) / det
                glen = math.hypot(gx, gy)
                if glen * glen < 1e-20:
                    continue
                unit = (gx / glen, gy / glen)
                total = (total[0] + unit[0] * weight, total[1] + unit[1] * weight)
                if weight > largest:
                    fallback, largest = unit, weight
        gradient = total if math.hypot(*total) >= largest * 1e-6 else fallback
        if gradient is None:
            continue
        _rotate_chart(chart, math.atan2(gradient[0], gradient[1]))


def orient_longest_edge(mesh, charts, vertical=False):
    """Rotate each chart (rigidly, no flips) so its longest edge is horizontal/vertical."""
    target = math.pi / 2 if vertical else 0.0
    for chart in charts:
        best, best_len = None, 0.0
        for (f, i) in sorted(chart):
            nxt = chart[(f, (i + 1) % len(mesh.faces[f]))]
            delta = sub2(nxt, chart[(f, i)])
            length = delta[0] * delta[0] + delta[1] * delta[1]
            if length > best_len:
                best, best_len = delta, length
        if best is None or best_len < 1e-20:
            continue
        # An axis has no direction: take the smallest rotation that aligns it.
        angle = (target - math.atan2(best[1], best[0]) + math.pi / 2) % math.pi - math.pi / 2
        _rotate_chart(chart, angle)


# ---------------------------------------------------------------- stitching
def signed_dihedral(mesh, key):
    """Signed angle between the two face normals: >0 convex, <0 concave, None if unknown."""
    pair = mesh.manifold_pair(key)
    if pair is None:
        return None
    ea, eb = pair
    if mesh.vertex(ea) == mesh.vertex(eb):
        return None  # inconsistent winding
    na, nb = mesh.face_normal(ea[0]), mesh.face_normal(eb[0])
    direction = sub3(mesh.points[mesh.vertex(mesh.next_corner(ea))], mesh.points[mesh.vertex(ea)])
    length = len3(direction)
    if length == 0:
        return None
    sine = dot3(cross3(na, nb), direction) / length
    return math.atan2(sine, dot3(na, nb))


def _tri_bounds(chart, tris):
    out = []
    for tri in tris:
        pts = [chart[c] for c in tri]
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        out.append((pts, min(xs), max(xs), min(ys), max(ys)))
    return out


def stitch(mesh, charts, protected=(), translation_only=False, concave_only=False):
    """Rigidly join compatible charts across shared mesh edges.

    A join is accepted only when the two edge copies have equal length, the
    moved chart does not overlap the target, and (optionally) the edge is a
    concave crease or needs no rotation.  Nothing is ever stretched.
    """
    if len(charts) < 2:
        return charts
    owners = {}
    for idx, chart in enumerate(charts):
        for (f, _) in chart:
            owners[f] = idx
    tris = {idx: [] for idx in range(len(charts))}
    for idx, chart in enumerate(charts):
        for f in {c[0] for c in chart}:
            for a, b, c in mesh.fan(f):
                tris[idx].append(((f, a), (f, b), (f, c)))
    live = dict(enumerate(charts))

    candidates = []
    for key in {k for f in owners for k in mesh.face_edge_keys(f)}:
        pair = mesh.manifold_pair(key)
        if pair is None or key in protected:
            continue
        if pair[0][0] not in owners or pair[1][0] not in owners:
            continue
        if mesh.vertex(pair[0]) == mesh.vertex(pair[1]):
            continue
        if concave_only:
            angle = signed_dihedral(mesh, key)
            if angle is None or not angle < -EPS:
                continue
        candidates.append((key, pair))
    candidates.sort(key=lambda item: -len3(sub3(mesh.points[item[0][0]], mesh.points[item[0][1]])))

    for key, (a, b) in candidates:
        left, right = owners[a[0]], owners[b[0]]
        if left == right:
            continue
        if len(live[left]) < len(live[right]):
            left, right, a, b = right, left, b, a
        target, source = live[left], live[right]
        p, q = target[a], target[mesh.next_corner(a)]
        r, s = source[mesh.next_corner(b)], source[b]
        u, v = sub2(s, r), sub2(q, p)
        lu, lv = len2(u), len2(v)
        if min(lu, lv) < 1e-10 or abs(lu - lv) > max(lu, lv) * 1e-5:
            continue
        angle = math.atan2(cross2(u, v), u[0] * v[0] + u[1] * v[1])
        if translation_only:
            if abs(angle) > 1e-6:
                continue
            angle = 0.0
        cos_a, sin_a = math.cos(angle), math.sin(angle)
        moved = {}
        for corner, uv in source.items():
            off = sub2(uv, r)
            moved[corner] = (p[0] + cos_a * off[0] - sin_a * off[1],
                             p[1] + sin_a * off[0] + cos_a * off[1])
        if (len2(sub2(moved[b], q)) > 1e-6 or len2(sub2(moved[mesh.next_corner(b)], p)) > 1e-6):
            continue
        t_tris = _tri_bounds(target, tris[left])
        s_tris = _tri_bounds(moved, tris[right])
        clash = False
        for t in t_tris:
            for s_ in s_tris:
                if (t[2] <= s_[1] or s_[2] <= t[1] or t[4] <= s_[3] or s_[4] <= t[3]):
                    continue
                if triangles_overlap(t[0], s_[0]):
                    clash = True
                    break
            if clash:
                break
        if clash:
            continue
        target.update(moved)
        tris[left].extend(tris.pop(right))
        for (f, _) in source:
            owners[f] = left
        del live[right]
    return list(live.values())


# ---------------------------------------------------------------- packing
def pack(charts, margin_ratio=0.01, border=0.01):
    """Shelf-pack charts into the 0-1 square with one common scale (no rotation)."""
    boxes = []
    for chart in charts:
        (lo_u, lo_v), (hi_u, hi_v) = bounds2(chart.values())
        boxes.append((chart, (lo_u, lo_v), (hi_u - lo_u, hi_v - lo_v)))
    if not boxes:
        return
    boxes.sort(key=lambda item: -item[2][1])
    area = sum(s[0] * s[1] for _, _, s in boxes)
    width = max(math.sqrt(area), max(s[0] for _, _, s in boxes), 1e-9)
    margin = width * margin_ratio
    x = y = row_h = used = 0.0
    for chart, low, size in boxes:
        if x and x + size[0] > width:
            x, y, row_h = 0.0, y + row_h + margin, 0.0
        for k, (u, v) in chart.items():
            chart[k] = (u - low[0] + x, v - low[1] + y)
        used = max(used, x + size[0])
        x += size[0] + margin
        row_h = max(row_h, size[1])
    extent = max(used, y + row_h, 1e-12)
    scale = (1.0 - 2 * border) / extent
    for chart in charts:
        for k, (u, v) in chart.items():
            chart[k] = (u * scale + border, v * scale + border)


def flatten(charts):
    out = {}
    for chart in charts:
        out.update(chart)
    return out


# ---------------------------------------------------------------- pipelines
def finish_auto(mesh, faces, values, protected, prioritize_world, up, flat_up, pack_result=True):
    """Auto Unwrap post-process.  `values` is the raw unfold output.

    Pass ``pack_result=False`` to pack several meshes together afterwards.
    """
    charts = result_charts(mesh, faces, values)
    fix_winding(mesh, charts)
    world_rescale(mesh, charts)
    if prioritize_world:
        orient_world(mesh, charts, up, flat_up)
    charts = stitch(mesh, charts, protected, translation_only=prioritize_world)
    if pack_result:
        pack(charts)
    return charts


def finish_trim(mesh, faces, values, protected, orientation, stitch_concave, up, flat_up,
                pack_result=True):
    """Unwrap-for-Trim post-process: optional concave stitch, orient, pack."""
    charts = result_charts(mesh, faces, values)
    fix_winding(mesh, charts)
    world_rescale(mesh, charts)
    if stitch_concave:
        charts = stitch(mesh, charts, protected, concave_only=True)
    if orientation == "WORLD":
        orient_world(mesh, charts, up, flat_up)
    else:
        orient_longest_edge(mesh, charts, vertical=orientation == "LONGEST_VERTICAL")
    if pack_result:
        pack(charts)
    return charts
