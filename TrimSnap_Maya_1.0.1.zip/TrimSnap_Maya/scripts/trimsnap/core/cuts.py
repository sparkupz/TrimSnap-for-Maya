"""Seam generation: angle cuts, chart splitting and disk-topology repair.

Maya's Unfold3D flattens each UV shell, so every shell must be a topological
disk.  ``plan_cuts`` returns the set of mesh edges to cut so that:

1. edges sharper than the angle threshold are cut,
2. existing UV borders are kept (optionally),
3. each resulting chart is a disk (tree/co-tree cut graph, pruned).
"""
import math

from .geom import dot3, sub3, len3, cross3, norm3


def angle_cut_edges(mesh, faces, angle_threshold):
    """Interior manifold edges whose face normals differ by more than the threshold."""
    fs = set(faces)
    limit = math.cos(angle_threshold) - 1e-7
    cuts = set()
    for key in {k for f in fs for k in mesh.face_edge_keys(f)}:
        pair = mesh.manifold_pair(key)
        if pair is None:
            continue
        fa, fb = pair[0][0], pair[1][0]
        if fa in fs and fb in fs and dot3(mesh.face_normal(fa), mesh.face_normal(fb)) < limit:
            cuts.add(key)
    return cuts


def split_charts(mesh, faces, cut_edges):
    """Faces grouped by connectivity across uncut, manifold, selected edges."""
    fs = set(faces)
    seen, charts = set(), []
    for start in faces:
        if start in seen:
            continue
        seen.add(start)
        chart, stack = [start], [start]
        while stack:
            f = stack.pop()
            for key in mesh.face_edge_keys(f):
                if key in cut_edges:
                    continue
                pair = mesh.manifold_pair(key)
                if pair is None:
                    continue
                other = pair[1][0] if pair[0][0] == f else pair[0][0]
                if other in fs and other not in seen:
                    seen.add(other)
                    chart.append(other)
                    stack.append(other)
        charts.append(chart)
    return charts


class _DisjointSet:
    def __init__(self):
        self.parent = {}

    def find(self, x):
        parent = self.parent
        parent.setdefault(x, x)
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != root:
            parent[x], x = root, parent[x]
        return root

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return False
        self.parent[rb] = ra
        return True


def chart_topology(mesh, faces, cut_edges):
    """Euler characteristic, boundary loop count and genus of a chart once cut."""
    fs = set(faces)
    interior = _interior_edges(mesh, fs, cut_edges)
    corners = _DisjointSet()
    for key in interior:
        ea, eb = mesh.edge_map()[key]
        for vertex in key:
            corners.union(mesh.corner_at(ea, vertex), mesh.corner_at(eb, vertex))
    verts = set()
    boundary = []
    for f in fs:
        n = len(mesh.faces[f])
        for i in range(n):
            verts.add(corners.find((f, i)))
            if mesh.face_edge_keys(f)[i] not in interior:
                boundary.append((corners.find((f, i)), corners.find((f, (i + 1) % n))))
    edges = len(interior) + len(boundary)
    chi = len(verts) - edges + len(fs)
    loops = _DisjointSet()
    for a, b in boundary:
        loops.union(a, b)
    loop_count = len({loops.find(v) for e in boundary for v in e})
    genus = (2 - loop_count - chi) // 2
    return chi, loop_count, genus


def _interior_edges(mesh, fs, cut_edges):
    interior = set()
    for f in fs:
        for key in mesh.face_edge_keys(f):
            if key in cut_edges or key in interior:
                continue
            pair = mesh.manifold_pair(key)
            if pair is not None and pair[0][0] in fs and pair[1][0] in fs:
                interior.add(key)
    return interior


def disk_cuts(mesh, faces, cut_edges):
    """Extra edges to cut so the chart `faces` becomes a single topological disk."""
    fs = set(faces)
    edge_map = mesh.edge_map()
    interior = _interior_edges(mesh, fs, cut_edges)
    corners = _DisjointSet()
    for key in interior:
        ea, eb = edge_map[key]
        for vertex in key:
            corners.union(mesh.corner_at(ea, vertex), mesh.corner_at(eb, vertex))

    def chart_vertex(entry, vertex):
        return corners.find(mesh.corner_at(entry, vertex))

    boundary = []
    verts = set()
    for f in fs:
        n = len(mesh.faces[f])
        keys = mesh.face_edge_keys(f)
        for i in range(n):
            a, b = corners.find((f, i)), corners.find((f, (i + 1) % n))
            verts.update((a, b))
            if keys[i] not in interior:
                boundary.append((a, b))
    chi = len(verts) - (len(interior) + len(boundary)) + len(fs)
    loops = _DisjointSet()
    for a, b in boundary:
        loops.union(a, b)
    boundary_verts = {v for e in boundary for v in e}
    loop_count = len({loops.find(v) for v in boundary_verts})
    if loop_count == 1 and chi == 1:
        return set()

    # Contract every boundary loop into one root vertex.
    def node(v):
        return ("loop", loops.find(v)) if v in boundary_verts else ("v", v)

    roots = {("loop", loops.find(v)) for v in boundary_verts}

    ends = {}
    sharp = {}
    length = {}
    for key in interior:
        ea, eb = edge_map[key]
        ends[key] = (node(chart_vertex(ea, key[0])), node(chart_vertex(ea, key[1])))
        n1, n2 = mesh.face_normal(ea[0]), mesh.face_normal(eb[0])
        sharp[key] = math.acos(max(-1.0, min(1.0, dot3(n1, n2)))) / math.pi
        length[key] = len3(sub3(mesh.points[key[0]], mesh.points[key[1]]))

    # Primal spanning tree: cheap along sharp edges so seams hide in creases.
    order = sorted(interior, key=lambda k: (length[k] * (1.0 - 0.75 * sharp[k]), k))
    primal = _DisjointSet()
    tree = set()
    for key in order:
        a, b = ends[key]
        if a != b and primal.union(a, b):
            tree.add(key)

    # Dual spanning tree over the remaining edges, joining flat edges first.
    dual = _DisjointSet()
    leftover = set()
    for key in sorted(interior - tree, key=lambda k: (sharp[k], k)):
        ea, eb = edge_map[key]
        if not dual.union(("f", ea[0]), ("f", eb[0])):
            leftover.add(key)

    cut = set(tree) | leftover

    # Prune dangling branches (leaves that are not boundary roots).
    degree = {}
    incident = {}
    for key in cut:
        for end in ends[key]:
            degree[end] = degree.get(end, 0) + 1
            incident.setdefault(end, set()).add(key)
    stack = [v for v, d in degree.items() if d == 1 and v not in roots]
    while stack:
        v = stack.pop()
        if degree.get(v, 0) != 1 or v in roots:
            continue
        key = next(iter(incident[v] & cut))
        cut.discard(key)
        for end in ends[key]:
            degree[end] -= 1
            incident[end].discard(key)
            if degree[end] == 1 and end not in roots:
                stack.append(end)

    if not cut and loop_count == 0:
        cut = _longest_tree_path(tree, ends, length)
    return cut


def _longest_tree_path(tree, ends, length):
    """A closed sphere needs one slit: use the longest path through the tree."""
    adjacency = {}
    for key in tree:
        a, b = ends[key]
        adjacency.setdefault(a, []).append((b, key))
        adjacency.setdefault(b, []).append((a, key))
    if not adjacency:
        return set()

    def farthest(start):
        dist, prev = {start: 0.0}, {}
        stack = [start]
        while stack:
            v = stack.pop()
            for w, key in adjacency[v]:
                if w not in dist:
                    dist[w] = dist[v] + length[key]
                    prev[w] = (v, key)
                    stack.append(w)
        return max(dist, key=lambda x: (dist[x], str(x))), prev

    first, _ = farthest(next(iter(adjacency)))
    last, prev = farthest(first)
    path, v = set(), last
    while v != first:
        v, key = prev[v]
        path.add(key)
    return path


def plan_cuts(mesh, faces, angle_threshold, existing_borders=None):
    """All edges to cut for `faces`; returns (cut_edge_keys, charts)."""
    cuts = set(angle_cut_edges(mesh, faces, angle_threshold))
    if existing_borders:
        cuts |= set(existing_borders)
    for chart in split_charts(mesh, faces, cuts):
        cuts |= disk_cuts(mesh, chart, cuts)
    return cuts, split_charts(mesh, faces, cuts)


def planar_layout(mesh, charts):
    """Initial per-chart planar UVs, spread out along U.

    Unfold3D only needs the shell structure; this gives it a sane starting
    layout (and non-overlapping charts if the unfold step is skipped).
    """
    values = {}
    cursor = 0.0
    for chart in charts:
        normal = (0.0, 0.0, 0.0)
        for f in chart:
            a = mesh.face_vector_area(f)
            normal = (normal[0] + a[0], normal[1] + a[1], normal[2] + a[2])
        normal = norm3(normal)
        if normal == (0.0, 0.0, 0.0):
            normal = (0.0, 1.0, 0.0)
        ref = (1.0, 0.0, 0.0) if abs(normal[0]) < 0.9 else (0.0, 1.0, 0.0)
        axis_u = norm3(sub3(ref, tuple(normal[i] * dot3(ref, normal) for i in range(3))))
        axis_v = norm3(cross3(normal, axis_u))
        origin = mesh.points[mesh.faces[chart[0]][0]]
        coords = {}
        for f in chart:
            for i, v in enumerate(mesh.faces[f]):
                d = sub3(mesh.points[v], origin)
                coords[(f, i)] = (dot3(d, axis_u), dot3(d, axis_v))
        us = [c[0] for c in coords.values()]
        vs = [c[1] for c in coords.values()]
        low_u, low_v = min(us), min(vs)
        span = max(max(us) - low_u, max(vs) - low_v, 1e-9)
        for k, (u, v) in coords.items():
            values[k] = ((u - low_u) / span + cursor, (v - low_v) / span)
        cursor += (max(us) - low_u) / span + 0.1
    return values
