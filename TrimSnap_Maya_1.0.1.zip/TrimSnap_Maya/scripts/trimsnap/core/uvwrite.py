"""Turn per-corner UV values into Maya's (uArray, vArray, counts, ids) layout."""

TOL = 2e-6


def build_uv_arrays(mesh, groups, tol=TOL):
    """Rebuild a mesh's whole UV set, applying `groups` of new corner values.

    ``groups`` is a list of ``{corner: (u, v)}`` dicts (one per shell/chart).
    Corners inside one group that sit on the same mesh vertex and the same
    position share a UV index (so edges stay connected); different groups never
    merge.  Corners outside every group keep their existing UV index, so
    untouched shells stay exactly as they were.

    Returns ``(u, v, counts, ids)`` for ``MFnMesh.setUVs``/``assignUVs``.
    Faces missing any UV get a count of 0 (Maya requires all-or-none per face).
    """
    owner = {}
    for gi, group in enumerate(groups):
        for corner in group:
            owner[corner] = gi
    u_out, v_out = [], []
    counts, ids = [], []
    merged = {}          # (group, vertex) -> [(u, v, new_id)]
    kept = {}            # old uv id -> new id
    for f, verts in enumerate(mesh.faces):
        row = []
        for i, vertex in enumerate(verts):
            corner = (f, i)
            gi = owner.get(corner)
            if gi is not None:
                u, v = groups[gi][corner]
                bucket = merged.setdefault((gi, vertex), [])
                new_id = None
                for cu, cv, cid in bucket:
                    if abs(cu - u) <= tol and abs(cv - v) <= tol:
                        new_id = cid
                        break
                if new_id is None:
                    new_id = len(u_out)
                    u_out.append(u)
                    v_out.append(v)
                    bucket.append((u, v, new_id))
            else:
                old = mesh.corner_uv[f][i]
                if old < 0:
                    new_id = -1
                else:
                    new_id = kept.get(old)
                    if new_id is None:
                        new_id = kept[old] = len(u_out)
                        u_out.append(mesh.uv_u[old])
                        v_out.append(mesh.uv_v[old])
            row.append(new_id)
        if not row or any(x < 0 for x in row):
            counts.append(0)
        else:
            counts.append(len(row))
            ids.extend(row)
    return u_out, v_out, counts, ids
