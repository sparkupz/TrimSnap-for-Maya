"""Fit UV shells into trim rectangles ("hotspotting"). Pure Python.

A trim is a dict with ``position`` (lower-left UV), ``scale`` (width, height)
and ``behavior`` (HORIZONTAL_TILING, VERTICAL_TILING or FIXED).
"""
import hashlib
import math

LABELS = {"HORIZONTAL_TILING": "Horizontal Tiling",
          "VERTICAL_TILING": "Vertical Tiling",
          "FIXED": "Fixed"}
BEHAVIORS = tuple(LABELS)


def matching_trims(preset, behavior):
    """Valid trims of a preset that use `behavior`, in list order."""
    result = []
    for trim in preset.get("trims", []):
        if trim.get("behavior", "FIXED") != behavior:
            continue
        try:
            position, scale = trim["position"], trim["scale"]
            ok = (len(position) == len(scale) == 2
                  and all(math.isfinite(v) for v in (*position, *scale))
                  and min(scale) > 0)
        except (KeyError, TypeError, ValueError):
            ok = False
        if ok:
            result.append(trim)
    return result


def choose_trim(size, trims, behavior, multiplier=1.0):
    """Pick the best trim for a shell with bounding-box `size` (w, h)."""
    match = (size[0] * multiplier, size[1] * multiplier)

    def score(trim):
        w, h = trim["scale"]
        if behavior == "HORIZONTAL_TILING":
            return abs(match[1] - h)
        if behavior == "VERTICAL_TILING":
            return abs(match[0] - w)
        # Fixed: aspect ratio first (log ratio is symmetric), then size.
        distortion = abs(math.log(w) - math.log(h) - math.log(size[0]) + math.log(size[1]))
        return (round(distortion, 10), abs(match[0] - w) + abs(match[1] - h))

    return min(trims, key=score)


def transform(coords, trims, behavior, multiplier=1.0, inset=0.0):
    """Return fitted coordinates for one shell (list of (u, v))."""
    if not coords or not all(math.isfinite(v) for uv in coords for v in uv):
        raise ValueError("Invalid UV coordinates")
    low = [min(uv[i] for uv in coords) for i in range(2)]
    high = [max(uv[i] for uv in coords) for i in range(2)]
    size = [high[i] - low[i] for i in range(2)]
    if min(size) <= 1e-12:
        raise ValueError("Zero-size UV island")
    if not math.isfinite(multiplier) or multiplier <= 0:
        raise ValueError("Island scale multiplier must be positive and finite")
    if not math.isfinite(inset):
        raise ValueError("Island offset must be finite")
    trim = choose_trim(size, trims, behavior, multiplier)
    fitted = list(trim["scale"])
    if behavior == "FIXED":
        # Inset shrinks every side but never lets an axis collapse or flip.
        offset = max(inset, -min(fitted) * 0.499999)
        fitted = [v + 2 * offset for v in fitted]
    else:
        axis = 1 if behavior == "HORIZONTAL_TILING" else 0
        offset = max(inset, -fitted[axis] * 0.499999)
        fitted[axis] += 2 * offset
    factors = [fitted[i] / size[i] for i in range(2)]
    if behavior == "HORIZONTAL_TILING":
        factors[0] = factors[1]
    elif behavior == "VERTICAL_TILING":
        factors[1] = factors[0]
    center = [(low[i] + high[i]) / 2 for i in range(2)]
    target = [trim["position"][i] + trim["scale"][i] / 2 for i in range(2)]
    result = [tuple(target[i] + (uv[i] - center[i]) * factors[i] for i in range(2))
              for uv in coords]
    if not all(math.isfinite(v) and abs(v) < 3e38 for uv in result for v in uv):
        raise ValueError("UV transform is out of range")
    return result


def random_flip(coords, seed, key, horizontal=False, vertical=False):
    """Stable, independent 50% mirror decisions about the shell's bounds centre."""
    bits = hashlib.sha256(f"{seed}:{key}".encode("utf-8")).digest()[0]
    flip_u = horizontal and bool(bits & 1)
    flip_v = vertical and bool(bits & 2)
    if not (flip_u or flip_v):
        return coords
    sums = [min(uv[i] for uv in coords) + max(uv[i] for uv in coords) for i in range(2)]
    return [(sums[0] - u if flip_u else u, sums[1] - v if flip_v else v) for u, v in coords]


def random_axis_offset(coords, seed, key, behavior, amount):
    """Slide a tiling shell randomly (+-amount UV) along its tiling axis."""
    if not amount or behavior not in ("HORIZONTAL_TILING", "VERTICAL_TILING"):
        return coords
    digest = hashlib.sha256(f"axis-offset:{seed}:{key}".encode("utf-8")).digest()
    fraction = int.from_bytes(digest[:8], "big") / (2 ** 64 - 1)
    offset = (2 * fraction - 1) * amount
    if behavior == "HORIZONTAL_TILING":
        return [(u + offset, v) for u, v in coords]
    return [(u, v + offset) for u, v in coords]


def plan_shell(mesh, faces, trims, behavior, options, seed):
    """New corner UVs for one shell, or ValueError when it cannot be fitted."""
    corners = mesh.uv_values(faces)
    keys = list(corners)
    coords = [corners[k] for k in keys]
    fitted = transform(coords, trims, behavior,
                       options.get("island_scale_multiplier", 1.0),
                       options.get("island_offset", 0.0))
    key = repr((mesh.name, tuple(sorted(faces))))
    fitted = random_flip(fitted, seed, key,
                         options.get("allow_horizontal_flip", False),
                         options.get("allow_vertical_flip", False))
    fitted = random_axis_offset(fitted, seed, key, behavior,
                                options.get("axis_offset_randomization", 0.0))
    return dict(zip(keys, fitted))
