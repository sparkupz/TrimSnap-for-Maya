"""Texel density measurement and scaling (pure Python)."""
import math

# Maya's internal linear unit is the centimetre; values below are cm per unit.
CM_PER_UNIT = {"M": 100.0, "CM": 1.0, "IN": 2.54, "FT": 30.48}
UNIT_LABELS = (("M", "px / m"), ("CM", "px / cm"), ("IN", "px / in"), ("FT", "px / ft"))
MODES = (("AVERAGE", "Average"), ("INDIVIDUAL", "Individual"))
TEXTURE_SIZES = tuple(str(n) for n in (64, 128, 256, 512, 1024, 2048, 4096, 8192))


def density(world_area_cm2, uv_area, texture_size, units):
    """Pixels per `units` for a shell with the given world (cm^2) and UV areas."""
    return texture_size * math.sqrt(uv_area / world_area_cm2) * CM_PER_UNIT[units]


def valid_measure(world_area, uv_area):
    return (world_area > 0.0 and uv_area > 0.0
            and math.isfinite(world_area) and math.isfinite(uv_area))


def measure_shells(mesh, shells, texture_size, units):
    """[(faces, density)] for measurable shells, plus the count that were skipped."""
    result, skipped = [], 0
    for faces in shells:
        w, a = mesh.world_area(faces), mesh.uv_area(faces)
        if not valid_measure(w, a):
            skipped += 1
            continue
        result.append((faces, density(w, a, texture_size, units)))
    return result, skipped


def scale_shell(mesh, faces, factor):
    """New corner UVs for a shell scaled about its own UV bounding-box centre."""
    coords = mesh.uv_values(faces)
    us = [c[0] for c in coords.values()]
    vs = [c[1] for c in coords.values()]
    cu, cv = (min(us) + max(us)) / 2, (min(vs) + max(vs)) / 2
    return {k: (cu + (u - cu) * factor, cv + (v - cv) * factor)
            for k, (u, v) in coords.items()}


def target_factors(densities, target, mode):
    """Scale factor per shell: Individual hits `target` each, Average shares one factor."""
    if mode == "INDIVIDUAL":
        return [target / d for d in densities]
    average = sum(densities) / len(densities)
    return [target / average] * len(densities)
