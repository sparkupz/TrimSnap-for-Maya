"""Maya-independent algorithms used by TrimSnap."""
