"""Maya-independent polygon mesh model.

A corner is the tuple ``(face, index)`` and identifies one face-vertex, which
is also where Maya stores a UV assignment.  Points are expected in world space
(Maya's internal unit is the centimetre).
"""
from .geom import cross3, len3, add3, sub3, norm3


class Mesh:
    def __init__(self, name, points, faces, uv_u=(), uv_v=(), corner_uv=None):
        self.name = name
        self.points = [tuple(p) for p in points]
        self.faces = [tuple(f) for f in faces]
        self.uv_u = list(uv_u)
        self.uv_v = list(uv_v)
        if corner_uv is None:
            corner_uv = [[-1] * len(f) for f in self.faces]
        self.corner_uv = [list(c) for c in corner_uv]
        self._edge_map = None
        self._normals = None

    # ------------------------------------------------------------------ topology
    def edge_map(self):
        """{(a, b): [(face, corner), ...]} with a < b; corner starts the edge."""
        if self._edge_map is None:
            edges = {}
            for f, verts in enumerate(self.faces):
                n = len(verts)
                for i in range(n):
                    a, b = verts[i], verts[(i + 1) % n]
                    edges.setdefault((a, b) if a < b else (b, a), []).append((f, i))
            self._edge_map = edges
        return self._edge_map

    def face_edge_keys(self, f):
        verts = self.faces[f]
        n = len(verts)
        keys = []
        for i in range(n):
            a, b = verts[i], verts[(i + 1) % n]
            keys.append((a, b) if a < b else (b, a))
        return keys

    def manifold_pair(self, key):
        """The two corners of an interior manifold edge, else None."""
        entries = self.edge_map().get(key)
        if entries is None or len(entries) != 2 or entries[0][0] == entries[1][0]:
            return None
        return entries

    def vertex(self, corner):
        return self.faces[corner[0]][corner[1]]

    def next_corner(self, corner):
        f, i = corner
        return (f, (i + 1) % len(self.faces[f]))

    def corner_at(self, entry, vertex):
        """Corner of the entry's face that sits on `vertex` (an end of its edge)."""
        f, i = entry
        verts = self.faces[f]
        return (f, i) if verts[i] == vertex else (f, (i + 1) % len(verts))

    def fan(self, f):
        """Triangle fan of corner indices for face f."""
        n = len(self.faces[f])
        return [(0, k, k + 1) for k in range(1, n - 1)]

    # ------------------------------------------------------------------ geometry
    def face_vector_area(self, f):
        """Newell-style area vector (twice the area, along the normal)."""
        verts = self.faces[f]
        p0 = self.points[verts[0]]
        total = (0.0, 0.0, 0.0)
        for k in range(1, len(verts) - 1):
            e1 = sub3(self.points[verts[k]], p0)
            e2 = sub3(self.points[verts[k + 1]], p0)
            total = add3(total, cross3(e1, e2))
        return total

    def face_area(self, f):
        return len3(self.face_vector_area(f)) * 0.5

    def face_normal(self, f):
        if self._normals is None:
            self._normals = {}
        n = self._normals.get(f)
        if n is None:
            n = self._normals[f] = norm3(self.face_vector_area(f))
        return n

    def world_area(self, faces):
        return sum(self.face_area(f) for f in faces)

    # ------------------------------------------------------------------ UV data
    def uv(self, corner):
        idx = self.corner_uv[corner[0]][corner[1]]
        if idx < 0:
            return None
        return (self.uv_u[idx], self.uv_v[idx])

    def has_uvs(self, f):
        return all(i >= 0 for i in self.corner_uv[f])

    def uv_values(self, faces):
        """{corner: (u, v)} for the given faces (faces without UVs are skipped)."""
        out = {}
        for f in faces:
            if not self.has_uvs(f):
                continue
            for i in range(len(self.faces[f])):
                idx = self.corner_uv[f][i]
                out[(f, i)] = (self.uv_u[idx], self.uv_v[idx])
        return out

    def uv_area(self, faces):
        total = 0.0
        for f in faces:
            if not self.has_uvs(f):
                continue
            pts = [self.uv((f, i)) for i in range(len(self.faces[f]))]
            for a, b, c in self.fan(f):
                p, q, r = pts[a], pts[b], pts[c]
                total += abs((q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])) * 0.5
        return total


def uv_shells(mesh, faces=None):
    """Group faces into UV shells exactly like Maya: faces that share a UV index.

    Returns (shells, invalid) where invalid lists faces with unassigned UVs.
    """
    if faces is None:
        faces = range(len(mesh.faces))
    parent = {}

    def find(x):
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != root:
            parent[x], x = root, parent[x]
        return root

    invalid, valid = [], []
    for f in faces:
        ids = mesh.corner_uv[f]
        if not ids or any(i < 0 for i in ids):
            invalid.append(f)
            continue
        valid.append(f)
        for i in ids:
            parent.setdefault(i, i)
        first = find(ids[0])
        for i in ids[1:]:
            root = find(i)
            if root != first:
                parent[root] = first
    groups = {}
    for f in valid:
        groups.setdefault(find(mesh.corner_uv[f][0]), []).append(f)
    return list(groups.values()), invalid


def shells_with_seeds(mesh, seeds):
    """UV shells that contain at least one seed face, plus count of UV-less seeds."""
    shells, invalid = uv_shells(mesh)
    seeds = set(seeds)
    chosen = [s for s in shells if any(f in seeds for f in s)]
    return chosen, sum(1 for f in invalid if f in seeds)


def corner_faces_edge_border(mesh, faces):
    """Mesh edges between two of `faces` whose UVs are discontinuous (UV borders)."""
    fs = set(faces)
    borders = set()
    for key in {k for f in fs for k in mesh.face_edge_keys(f)}:
        pair = mesh.manifold_pair(key)
        if pair is None:
            continue
        (fa, _), (fb, _) = pair
        if fa not in fs or fb not in fs:
            continue
        for vertex in key:
            ca = mesh.corner_at(pair[0], vertex)
            cb = mesh.corner_at(pair[1], vertex)
            ia, ib = mesh.corner_uv[ca[0]][ca[1]], mesh.corner_uv[cb[0]][cb[1]]
            if ia < 0 or ib < 0:
                break            # faces without UVs have no border to respect
            if ia != ib:
                borders.add(key)
                break
    return borders
