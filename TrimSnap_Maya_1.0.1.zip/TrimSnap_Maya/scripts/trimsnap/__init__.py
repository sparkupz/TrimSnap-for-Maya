"""TrimSnap for Maya - trim sheet UV tools (texel density, unwrap, hotspot)."""
__version__ = "1.0.0"
