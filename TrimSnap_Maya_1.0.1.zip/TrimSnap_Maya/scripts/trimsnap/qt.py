"""Qt binding shim: Maya 2025+ ships PySide6, older versions PySide2."""
try:
    from PySide6 import QtCore, QtGui, QtWidgets
    from shiboken6 import wrapInstance
except ImportError:  # pragma: no cover - depends on the Maya version
    from PySide2 import QtCore, QtGui, QtWidgets
    from shiboken2 import wrapInstance

__all__ = ["QtCore", "QtGui", "QtWidgets", "wrapInstance", "exec_dialog", "maya_main_window"]


def exec_dialog(dialog):
    runner = getattr(dialog, "exec_", None) or getattr(dialog, "exec")
    return runner()


def maya_main_window():
    import maya.OpenMayaUI as omui
    pointer = omui.MQtUtil.mainWindow()
    return wrapInstance(int(pointer), QtWidgets.QWidget) if pointer else None
