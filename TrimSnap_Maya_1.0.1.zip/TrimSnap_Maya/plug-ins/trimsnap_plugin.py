"""TrimSnap for Maya - plug-in entry point (Maya Python API 2.0)."""
import os
import sys

import maya.api.OpenMaya as om

maya_useNewAPI = True


def _ensure_scripts_on_path():
    try:
        scripts = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
    except NameError:
        return
    if os.path.isdir(scripts) and scripts not in sys.path:
        sys.path.append(scripts)


def initializePlugin(plugin):
    _ensure_scripts_on_path()
    plugin_fn = om.MFnPlugin(plugin, "TrimSnap", "1.0.0", "Any")
    from trimsnap import commands, menu, state
    commands.register(plugin_fn)
    state.startup()
    menu.create()


def uninitializePlugin(plugin):
    plugin_fn = om.MFnPlugin(plugin)
    from trimsnap import commands, menu, overlay
    try:
        overlay.clear()
    except Exception:
        pass
    menu.remove()
    commands.deregister(plugin_fn)
