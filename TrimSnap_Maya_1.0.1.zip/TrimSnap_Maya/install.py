"""Drag this file into a Maya viewport to install TrimSnap.

It writes a Maya module file that points at this folder (nothing is copied),
loads the plug-in and marks it for auto-load.  Keep the folder where it is.
"""
import os
import sys

import maya.cmds as cmds
import maya.mel as mel

ROOT = os.path.dirname(os.path.abspath(__file__))
PLUGIN = "trimsnap_plugin.py"


def _module_dir():
    app_dir = os.environ.get("MAYA_APP_DIR") or cmds.internalVar(userAppDir=True)
    version = cmds.about(version=True).split()[0]
    for candidate in (os.path.join(app_dir, version, "modules"), os.path.join(app_dir, "modules")):
        if os.path.isdir(os.path.dirname(candidate)):
            os.makedirs(candidate, exist_ok=True)
            return candidate
    path = os.path.join(app_dir, "modules")
    os.makedirs(path, exist_ok=True)
    return path


def install():
    module_file = os.path.join(_module_dir(), "TrimSnap.mod")
    with open(module_file, "w", encoding="utf-8") as handle:
        handle.write("+ TrimSnap 1.0.0 {}\n".format(ROOT.replace("\\", "/")))
    scripts = os.path.join(ROOT, "scripts")
    plugins = os.path.join(ROOT, "plug-ins")
    if scripts not in sys.path:
        sys.path.append(scripts)
    current = os.environ.get("MAYA_PLUG_IN_PATH", "")
    if plugins not in current.split(os.pathsep):
        os.environ["MAYA_PLUG_IN_PATH"] = plugins + (os.pathsep + current if current else "")
    cmds.loadPlugin(os.path.join(plugins, PLUGIN), quiet=True)
    cmds.pluginInfo(PLUGIN, edit=True, autoload=True)
    cmds.confirmDialog(
        title="TrimSnap", button="OK",
        message="TrimSnap is installed.\n\nUse the new 'TrimSnap' menu > Open TrimSnap.\n"
                "The plug-in will load automatically in new Maya sessions.")


def onMayaDroppedPythonFile(*_args):
    install()


if __name__ == "__main__":
    install()
